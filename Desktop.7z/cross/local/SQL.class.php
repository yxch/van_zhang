<?php
class SQL
{
	//区域表
	const TblRegion = 'tb_points_regions';
	//获取当前可用的注册区域信息
	const GetRegionsFromPointsRegions = '
		SELECT id AS id,named AS name,region AS region,dir AS directory
		FROM tb_points_regions
		WHERE yes=1
		ORDER BY  ctime ';
	//由id获取注册区域名称和目录
	const GetRegionsFromPointsRegionsById = '
		SELECT named AS name,dir AS directory
		FROM tb_points_regions
		WHERE yes=1 AND  id=:id ';
	//计算区域条目总数
	const GetCountsFromPointsRegions = 'SELECT COUNT(*) AS total FROM tb_points_regions';
	//获取区域信息
	const GetRegionFromPOintsRegions = '
		 SELECT  id AS id, region AS region,named AS name,auth AS authority,dir AS directory,yes AS yes,mtime AS mtime,ctime AS ctime
		 FROM tb_points_regions
		 ORDER BY ctime DESC
		 LIMIT :size OFFSET :page ';
	//由搜索选项计算区域总数
	const GetCountsFromPointsRegionsBySearch = '
		SELECT COUNT(*) AS total
		FROM tb_points_regions
		WHERE  named LIKE :search OR dir LIKE :search';
	//获取区域信息
	const GetRegionFromPOintsRegionsBySearch = '
		 SELECT  id AS id, region AS region,named AS name,auth AS authority,dir AS directory,yes AS yes,mtime AS mtime,ctime AS ctime
		 FROM tb_points_regions
		 WHERE named LIKE :search OR dir LIKE :search
		 ORDER BY ctime DESC
		 LIMIT :size OFFSET :page ';
	//新建一个区域
	const NewRegionInPointsRegions = 'INSERT INTO tb_points_regions(named,region,auth,dir)VALUES(:named,:region,:auth,:dir)';
	//是否存在此区域
	const GetCountFromPointsRegionsByRegionAndName = '
		SELECT COUNT(*) AS total 
		FROM tb_points_regions
		WHERE region=:region AND named=:named';
	//是否存在此区域
	const GetCountFromPointsRegionsByIdAndName = '
		SELECT COUNT(*) AS total
		FROM tb_points_regions
		WHERE region = (SELECT region FROM tb_points_regions WHERE id=:id) AND named = :named';
	//删除区域
	const DelRegionsFromPointsRegionsById = 'DELETE FROM tb_points_regions WHERE id=:id	';
	
	//用户表
	const TblUsers = 'tb_points_users';
	//由用户名查询用户信息
	const GetUsersFromPointsUserByUsername = '
		SELECT id AS id, alias AS alias,pwd AS password, tye AS type, yes AS status
		FROM tb_points_users
		WHERE yes = 1 AND usr = :username 	';
	//计算有效用户总数 分页 users.ajx.php
	const GetCountsFromPointsUsers = 'SELECT  COUNT(*) AS total 	FROM tb_points_users';
	//获取有效的用户记录信息
	const GetUsersFromPointsUsers = '
		SELECT id AS id,usr AS username,alias AS alias,email AS email,ppath AS portrait,tye AS type,yes AS status,mtime AS mtime,ctime AS ctime
		FROM tb_points_users
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page';
	//根据搜索条件计算用户总数 分页
	const GetCountsFromPointsUsersBySearch = '
		SELECT COUNT(*) AS  total 
		FROM tb_points_users
		WHERE  usr LIKE :search OR alias LIKE :search OR email LIKE :search';
	//获取符合搜索条件的用户记录
	const GetUsersFromPointsUsersBySearch = '
		SELECT id AS id,usr AS username,alias AS alias,email AS email,ppath AS portrait,tye AS type,yes AS status,mtime AS mtime,ctime AS ctime
		FROM tb_points_users
		WHERE usr LIKE :search OR alias LIKE :search OR email LIKE :search
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page';
	//获取全部有效用户的部分信息
	const GetUsersSomeFromPointsUsers = 'SELECT id AS id,usr As username,alias As alias FROM tb_points_users	WHERE yes > 0 ';
	//确认是否还存在其它相同的用户名 修改
	const GetCountsFromPointsUsersByIdAndUsername = '
		SELECT COUNT(*) AS total 
		FROM tb_points_users
		WHERE usr = :usr AND id !=:id';
	//确认是否还存在其它相同的用户名 修改
	const GetCountsFromPointsUsersByUsername = '	SELECT COUNT(*) AS total FROM tb_points_users	WHERE usr = :usr';
	//新建用户
	const NewUserInPointsUsers = 'INSERT INTO tb_points_users (usr,pwd,alias,email,ppath,tye)VALUES(:usr,:pwd,:alias,:email,:ppath,:tye)';

	//类别表名
	const TblCategory = 'tb_points_category';
	//查找对应区域id的类别条目
	const GetCategoriesFromPointsCategoryByRegionId = '
		SELECT id AS id, title AS title, md5 AS MD5, tid AS templateId
		FROM tb_points_category
		WHERE rid=:regionId AND yes > 0  ';
	//查询系统类别的总数
	const GetSystemCategoriesCountFromPointsCategory = '
		SELECT COUNT(*) AS total 
		FROM tb_points_category
		WHERE md5 IN(:limit)';
	//从类别表中获取数据并分页显示
	const GetPageFromPointsCategory = '
		SELECT id,title AS title, rid AS regionId, murl AS managingURL, tid AS templateId, pos AS position, yes AS status, ctime AS createTime
		FROM tb_points_category
		WHERE yes = 1
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page ';
	//计算符合搜索条件的类别条目总数
	const CountFromPointsCategoryBySearch = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE yes = 1 AND (title LIKE :title OR murl LIKE :murl )';
	//计算有效类别条目的总数，分页处理
	const CountFromPointsCategory = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE yes = 1	';
	//搜索类别SQL
	const GetInformFromPointsCategoryBySearcher = '
		SELECT id,title AS title, rid AS regionId, murl AS managingURL, tid AS templateId, pos AS position, yes AS status, ctime AS createTime
		FROM tb_points_category
		WHERE yes = 1 AND (title LIKE :title OR murl LIKE :murl )
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page ';
	//设置类别条目的状态值 即yes的值
	const SetYesInPointsCategory = '
		UPDATE tb_points_category SET yes = 0
		WHERE id = :id ';
	//由指定categoryid查询信息
	const GetCategoryFromPointsCategoryById = '
		SELECT rid AS regionId,title AS title,murl AS managingURL,tid AS templateId,pos AS position, yes AS status
		FROM tb_points_category
		WHERE id=:id AND yes > 0	';
	//同一murl下同一区域id只存在一个模板id  修改
	const GetCategoryExistFromPointsCategory = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE id != :id AND md5 = :md5 AND rid = :rid AND tid = :tid	';
	//同一murl下同一区域id只存在一个模板id 新增
	const GetAddCategoryExistFromPointsCategory = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE  md5 = :md5 AND rid = :rid AND tid = :tid ';
	//新增一个类别条目
	const NewCategoryInPointsCategory = '
		INSERT  INTO tb_points_category
		(md5,title,rid,murl,tid,pos)
		VALUES(:md5,:title,:rid,:murl,:tid,:pos)	';
	//获取类别（但不包括系统类别）的部分信息
	const GetCategoriesFromPointsCategory = '
		SELECT  id AS id, title AS title 
		FROM tb_points_category
		WHERE md5 NOT IN(:limit)	';
	
	//权限表
	const TblPowers = 'tb_points_powers';
	//由uid获取此uid的权限列表
	const GetPowerListFromPointsPowersByUID = '
		SELECT cid AS categoryId, auth AS authority
		FROM tb_points_powers
		WHERE uid = :uid AND  yes = 1	';
	//计算全部权限条目数
	const GetCountsFromPointsPowers = 'SELECT COUNT(*) AS total FROM tb_points_powers	';
	//获取权限信息
	const GetPowersFromPointsPowers = '
		SELECT id AS id, uid AS uid, cid AS cid,ctle AS categoryTitle,auth AS authority,yes AS yes,mtime AS mtime,ctime AS ctime
		FROM tb_points_powers
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page  ';
	//由搜索选项计算权限的总数
	const GetCountsFromPointsPowersBySearch = '
		SELECT COUNT(*) AS total 
		FROM tb_points_powers	
		WHERE uid =  :uid OR cid = :cid OR ctle LIKE :search	';
	//获取权限信息
	const GetPowersFromPointsPowersBySearch = '
		SELECT id AS id, uid AS uid, cid AS cid,ctle AS categoryTitle,auth AS authority,yes AS yes,mtime AS mtime,ctime AS ctime
		FROM tb_points_powers
		WHERE uid =  :uid OR cid = :cid OR ctle LIKE :search
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page  ';

	//模板表
	const TblTemplate = 'tb_pooints_template';
	//获取全部模板文件
	const GetTemplatesFromPointsTemplate = '
		SELECT id AS id,title AS title, path AS path,tag AS tag
		FROM tb_points_template
		WHERE tag > 0	';
	//列出多个模板id的详细信息
	const GetTemplatesFromPointsTemplateByIds = '
		SELECT id AS id,path AS path 
		FROM tb_points_template
		WHERE tag > 0 AND id IN(:limit)		';

	//变量表
	const TblVariable = 'tb_points_variables';
	//计算指定管理标识符的变量条目
	const GetCountsFromPointsVariablesByMd5 = '
		SELECT COUNT(*) AS total
		FROM tb_points_variables
		WHERE pos = :md5		';
	//由id获取变量的字段内容
	const GetVariableFromPointsVariablesById = '
		 SELECT  named AS name,val AS value,url AS url,note AS note,txt AS text,rule AS rule,isuser AS isUsr,yes AS status,tye AS type
		 FROM tb_points_variables
		 WHERE id = :id	';
	//由id获取变量的字段内容
	const GetVarsFromPointsVariablesById = '
		 SELECT  named AS name,pos AS md5,note AS note,isuser AS isUsr,yes AS status
		 FROM tb_points_variables
		 WHERE id = :id	';
	//向变量表中插入变量
	const NewVariablesInPointsVariables = '
		INSERT INTO tb_points_variables
		(named,val,pos,url,note,txt,yes,rule,isuser,tye)
		VALUES(:name,:value,:pos,:url,:note,:text,:yes,:rule,:isUsr,:type)	';
	//计算符合搜索条件的变量总数
	const CountFromPointsVariablesBySearch = '
		SELECT COUNT(*) AS total
		FROM tb_points_variables
		WHERE yes > 0 AND (named LIKE :name OR note LIKE :note  OR url LIKE :url)	';
	//搜索变量的SQL
	const GetInfoFromPointsVariablesBySearcher = '
		SELECT id AS id,named AS name,val AS value,url AS url,note AS note,txt AS text,yes AS status,
		rule AS rule,isuser AS isUsr,tye AS type,mtime AS modifyTime,ctime AS createTime
		FROM tb_points_variables
		WHERE yes > 0 AND (named LIKE :name OR note LIKE :note  OR url LIKE :url)
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page		';
	//计算有效变量的总数
	const CountFromPointsVariable = '
		SELECT COUNT(*) AS total
		FROM tb_points_variables
		WHERE yes > 0 ';
	//分页显示变量的SQL
	const GetPageFromPointsVariable = '
		SELECT id AS id,named AS name,val AS value,url AS url,note AS note,txt AS text,yes AS status,
		rule AS rule,isuser AS isUsr,tye AS type,mtime AS modifyTime,ctime AS createTime
		FROM tb_points_variables
		WHERE yes > 0
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page		';
	//删除变量
	const DelVariableInPointsVariable = 'DELETE FROM tb_points_variables WHERE id=:id	';

	//数据过滤器
	const TblFilter = 'tb_points_filters';
	//新建一个过滤器条目
	const NewFilterInPointsFilters = '
		INSERT INTO  tb_points_filters(named,cid,flds,scher,slt,factor,rst,flag)
		VALUES(:name,:cid,:fields,:searcher,:select,:factor,:rest,:flag) 	';
	//由flag查询过滤器是否已创建
	const GetFilterFromPointsFiltersByFlag = '
		SELECT COUNT(*) AS total 
		FROM tb_points_filters
		WHERE flag = :flag	';
	//由搜索选项计算条目总数
	const CountFiltersFromPointsFilterBySearch = '
		SELECT COUNT(*) AS total 
		FROM tb_points_filters
		WHERE yes  > 0 AND named LIKE :name		';
	//获取过滤器信息由搜索选项
	const GetFilterFromPointsFiltersBySearch = '
		SELECT id AS id,named AS name,cid AS cid,flds AS fields,scher AS search,slt AS statement,
		factor AS factor,rst AS rest,yes AS status,mtime AS mtime, ctime AS ctime
		FROM tb_points_filters
		WHERE  named LIKE :name
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page		';
	//计算有效过滤器的条目总数
	const CountFiltersFromPointsFilter = '
		SELECT COUNT(*) AS total
		FROM tb_points_filters
		WHERE yes > 0	';
	//获取过滤器信息
	const GetFiltersFromPointsFilters = '
		SELECT id AS id,named AS name,cid AS cid,flds AS fields,scher AS search,slt AS statement,
		factor AS factor,rst AS rest,yes AS status,mtime AS mtime, ctime AS ctime
		FROM tb_points_filters
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page		';
	//由id获取过滤器信息
	const GetFitlerFromPointsById = '
		SELECT named AS name,cid AS cid,flds AS fields,scher AS search,slt AS statement,factor AS factor,rst AS rest,yes AS status
		FROM tb_points_filters
		WHERE id = :id 
		ORDER BY ctime DESC		';
	//由id更新过滤器
	const SetFilterInPointsFilterById = '
		UPDATE tb_points_filters SET  
		named = :name,cid = :cid,flds = :fields,scher = :search,slt = :statement,factor = :factor,rst = :rest,flag = :flag,yes = :status,mtime = :mtime
		WHERE id = :id	';
	//由id删除过滤器
	const DelFiltersInPointsFiltersById = 'DELETE FROM tb_points_filters WHERE id=:id';

}
