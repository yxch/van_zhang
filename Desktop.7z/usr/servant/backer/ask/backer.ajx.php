<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $back = array('yes'=>0,'tip'=>'');
    
    if(!isset($_POST['serial']) || !ctype_digit($_POST['serial']))
    {
        $back['tip'] = '提供了无效的值';
        points::jan($back);
    }
    
    //当前用户是否有修改的权限
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];
    if(!points::allowed($auth,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
    
    $var = new vars(array('id'=>$_POST['serial']));
    $vars = $var->get(array('rule'));
    if($var->iTotal() == 0){ $back['tip'] = 'Exception newwork access.'; points::jan($back); }
    
    if(!STR::checkText($_POST['val'],$vars['rule'][0]))
    {
        $back['tip'] = '值的规则校验失败,请提供正确的值';
        points::jan($back);
    }
    if($var->set(array('value'=>$_POST['val'])))
    {
        $back['yes'] = 1;
        $back['tip'] = '更新成功';
    }else{ $back['tip'] = '更新失败'; }
    
    points::jan($back);
    