<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 

	$back = ['status'=>0,'tip'=>''];	

	$position = '';
	if(!isset($_POST['murl']) || empty($_POST['murl'])) //检查管理标识符murl
	{
		$back['tip'] = '没有提供必须的管理标识符murl'; points::jan($back);
	}else
	{
		$murl = points::SURL($_POST['murl'],true);
		if(!$murl['status']){ $back['tip'] = '提供了不正确的管理标识符murl'; points::jan($back); }   
		$position = $murl['md5'];
	}
	//确认此管理标识符murl是否存在变量记录条目
	$murls = DBC::selected(SQL::GetCountsFromPointsVariablesByMd5,[':md5'=>$position],['one'=>TRUE]);
	if($murls['total'] > 0)
	{
		$back['tip'] = '此管理标识符在变量表中已经存在,请转到变量管理页面处理'; points::jan($back);
	}
	//当前用户是否有新增条目的权限
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'add')){ $back['tip'] = '用户权限请求'; points::jan($back); }
	
	$vars = [];
	
	if(isset($_POST['stime']) && !empty($_POST['stime'])) //检查变量标识符stime
	{
		if(!STR::timed($_POST['stime'])){ $back['tip'] = '标准时间变量一[stime]错误'; points::jan($back); }
		$vars[] = 'stime';
	}
	if(isset($_POST['etime']) && !empty($_POST['etime'])) //检查变量标识符etime
	{
		if(!STR::timed($_POST['etime'])){ $back['tip'] = '标准时间变量二[etime]错误'; points::jan($back); }
		$vars[] = 'etime';
	}
	if(isset($_POST['serial']) && !empty($_POST['serial'])) //检查变量标识符serial
	{
		$len = strlen($_POST['serial']);
		for($i=0;$i<$len;$i++)
		{ 
			if(!ctype_digit($_POST['serial'][$i])){ $back['tip'] = '标准类别序列号只能是数字'; points::jan($back); } 
		}
		if($len > 15){ $back['tip'] = '版本值的最大长度为15'; points::jan($back); }
		$vars[] = 'serial';
	}
	if(isset($_POST['psize']) && !empty($_POST['psize'])) //检查变量标识符psize
	{
		if(!ctype_digit($_POST['psize'])){ $back['tip'] = '用户数据分页值只能是数字'; points::jan($back); }
		$vars[] = 'psize';
	}
	if(isset($_POST['cached']) && !empty($_POST['cached'])) //检查变量标识符cached
	{
		if(!ctype_digit($_POST['cached'])){ $back['tip'] = '缓存有效时间值只能是数字'; points::jan($back); }
		$vars[] = 'cached';
	}
	if(isset($_POST['shortid']) && !empty($_POST['shortid'])) //检查变量标识符shortid
	{
		for($j=0,$len=strlen($_POST['shortid']);$j<$len;$j++)
		{
			if(!ctype_alnum($_POST['shortid'][$j])){	$back['tip'] = '类别变量短标识符只能是数字或者字母'; points::jan($back);	}
		}
		if(strlen($_POST['shortid']) > 8){ $back['tip'] = '类别变量短标识符的长度不能大于8个字符'; points::jan($back); }
		$vars[] = 'shortid';
	}
	if(isset($_POST['ssign']) && !empty($_POST['ssign'])) //检查变量标识符ssign
	{ 
		/*待补充验证规则*/
		$vars[] = 'ssign';
	} 
    if(isset($_POST['esign']) && !empty($_POST['esign'])) //检查变量标识符esign
	{
		/*待补充验证规则*/
		$vars[] = 'esign';
	} 
	if(isset($_POST['limited']) && !empty($_POST['limited'])) //检查变量标识符limited
	{
	   if(strpos($_POST['limited'],'-') !== FALSE)
	   {
			$exp = explode('-',$_POST['limited']);
			if(count($exp) != 2){ $back['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($back); }
			if(!ctype_digit($exp[0]) || !ctype_digit($exp[1]) || $exp[0] >= $exp[1])
			{ 
				$back['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($back);
			}
	   }else{ $back['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($back); }
	   $vars[] = 'limited';
	}
	if(isset($_POST['auxiliary']) && !empty($_POST['auxiliary']))  //检查变量标识符auxiliary
	{
		if(!ctype_digit($_POST['auxiliary'])|| $_POST['auxiliary'] > 9){ $back['tip'] = '附加信息标识符只能是一个数字'; points::jan($back); }
		$vars[] = 'auxiliary';
	}
	
	//变量描述映射集
	$desc = array('stime'=>'标准时间变量一',  'etime'=>'标准时间变量二','serial'=>'标准系统序列号', 'psize'=>'用户数据分页值',
				  'cached'=>'缓存有效时间值', 'shortid'=>'类别变量短标识','limited'=>'类别范围变量值','auxiliary'=>'附加信息标识符',
				  'ssign'=>'启用起始标识符',  'esign'=>'启用终止标识符'	);
    //变量的规则集     
	$rules = array('stime'=>'datetime','etime'=>'datetime','serial'=>'digit','psize'=>'digit','cached'=>'digit',
				   'shortid'=>'text','limited'=>'limit','auxiliary'=>'digit','ssign'=>'text','esign'=>'text'      );

	$varsLen = count($vars);	$inserts = [];
	if($varsLen > 0)
	{
		for($k=0;$k<$varsLen;$k++)
		{
			$inserts[$k][':name'] = $vars[$k];
			$inserts[$k][':value'] = $_POST[$vars[$k]];
			$inserts[$k][':pos'] = $position;
            $inserts[$k][':url'] = $_POST['murl'];
            $inserts[$k][':note'] = $desc[$vars[$k]];
            $inserts[$k][':text'] = '';
            $inserts[$k][':yes'] = '2';
            $inserts[$k][':rule'] = $rules[$vars[$k]];
            $inserts[$k][':isUsr'] = 0;
			$inserts[$k][':type'] = 'text';
		}
		if(DBC::modified(SQL::NewVariablesInPointsVariables,$inserts))
		{
			$back['status'] = 1; $back['tip'] = '保存成功！';
		}else{ $back['tip'] = '保存失败，请检查网络！'; }
		points::jan($back);
	}else{ $back['tip'] = '没有可用于保存的信息'; points::jan($back); } 

  