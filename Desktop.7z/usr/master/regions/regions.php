<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>
<!DOCTYPE html>
<html>
<head>
	<?php echo points::head(0); ?>
	<link rel="stylesheet" href="/points/cross/local/css/points.css" />
	<link rel="stylesheet" href="/points/cross/local/css/page-lists.css" />
	<link rel="stylesheet" href="/points/bases/world/paging.css" />
	<script src="/points/cross/local/js/frame.js"></script>
	<style>
		.page-lists li i{width:100px;}
		.clone{ border-right:1px solid #8194AA;padding-right:12px;}
		.clone li{margin-bottom: 8px;}
	</style>
</head>
<body>
	<div id="topic"><h1>区域选项管理</h1><span id="err"></span></div>
	<div id="tip">
		<p>友情提示：顶部的搜索框可以按<strong>区域选项名称</strong>或者<strong>区域目录</strong>的相关内容进行模糊搜索。输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
	</div>
	<div id="ul"></div>
	<div id="paging"><span></span></div>
	<div id="oper">
		<a id="close"><img title="关闭" src="<?php echo IMAGE; ?>close-16px.png" /></a>
		<a id="delete"><img title="删除" src="<?php echo IMAGE; ?>delete-1.png" /></a>
		<a id="add"><img title="增加" src="<?php echo IMAGE; ?>new-1.png" /></a>
		<a id="checked"><img title="选择" src="<?php echo IMAGE; ?>check-1.png" /></a>
		<a id="uncheck"><img title="取消选择" src="<?php echo IMAGE; ?>uncheck-1.png" /></a>
		<a id="isshow"><img title="展开" src="<?php echo IMAGE; ?>expand.png" /></a>
		<a id="showall"><img title="全部展开" src="<?php echo IMAGE; ?>all-expand.png" /></a>
	</div>
	<div id="editable">
		<a id="editor"><img title="编辑" src="<?php echo IMAGE; ?>edit_yellow.png" /></a>
		<a id="writer"><img title="保存" src="<?php echo IMAGE; ?>save_yellow.png" /></a>
	</div>
	<div id="clone">
		<ul class="page-lists clone">
			<li>
				<i>区域</i>
				<span>
					<label><input type="radio" class="radio region" name="region" value="1" />用户数据</label>
					<label><input type="radio" class="radio region" name="region" value="2" />设置中心</label>
					<label><input type="radio" class="radio region" name="region" value="3" />定制</label>
				</span>
			</li>
			<li><i>区域名称</i><span><input class="name" /></span></li>
			<li><i>默认权限</i><span><input class="powers" value="1000000000" /></span></li>
			<div class="selectbox">
				<label><input type="checkbox" class="power" />编辑</label>
				<label><input type="checkbox" class="power" />删除</label>
				<label><input type="checkbox" class="power" />增加</label>
				<label><input type="checkbox" class="power" />权限扩展1</label>
				<label><input type="checkbox" class="power" />权限扩展2</label>
				<label><input type="checkbox" class="power" />权限扩展3</label>
				<label><input type="checkbox" class="power" />导入</label>
				<label><input type="checkbox" class="power" />导出</label>
				<a class="ensure">更改权限</a>
			</div>
			<li><i>区域路径</i><span><input class="directory" /></span></li>
			<h1>
				<i>正在新建区域</i>
				<a class="save"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a>
			</h1>
		</ul>
	</div>
	<script src="/points/bases/world/paging.js"></script>
	<script src="js/regions.js"></script>
</body>
</html>