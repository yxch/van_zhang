<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';    
    
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    $userType = $_SESSION['points']['user']['type'];

	$back = ['status'=>0,'err'=>'','type'=>'error']; //请求的响应
	$editor = false; $details = [];
	if(isset($_POST['id']) && !empty($_POST['id'])) //修改内容
	{
		$editor = true;
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['err'] = '用户权限请求'; points::jan($back); }
		$_arr = explode('_',trim($_POST['id']));
		if(empty($_arr[2]) || !isset($_POST['val']) || !ctype_digit($_arr[1]))
		{
			$back['err'] = '异常的请求！'; 
			points::jan($back);
		}
		$_POST[$_arr[2]] = $_POST['val'];
		$details['mtime'] = date('Y-m-d H:i:s');
		
	}else //新增内容
	{
		//当前用户是否有新建条目的权限
        if(!points::allowed($authority,'add')){ $back['err'] = '用户权限请求'; points::jan($back); }
		//必须设置的一些值
		if(!isset($_POST['username'])){  $back['err'] = '必须提供用户名'; points::jan($back);	}
	}
	
	if(isset($_POST['username'])) //检查用户名
	{
		if(empty($_POST['username']) || mb_strlen($_POST['username']) > 16)
		{
			$back['err'] = '必须提供用户名且长度不超过16个字符！';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['usr'] = trim($_POST['username']);
	}
	
	if(isset($_POST['alias'])) // 检查显示名称
	{
		if(mb_strlen($_POST['alias']) > 30)
		{
			$back['err'] = '显示名太长！';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['alias'] = trim($_POST['alias']);
	}
	
	if(isset($_POST['type'])) //检查用户类型
	{
		if(!in_array($_POST['type'],['1','2','3','9']))
		{
			$back['err'] = '提供了一个无效的用户类型！';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['tye'] = $_POST['type'];
	}
	
	if(isset($_POST['email'])) //检查邮件地址
	{
		if(!empty($_POST['email']) && !STR::email($_POST['email']))
		{
			$back['err'] = '提供了一个格式不正确的电子邮件地址！';
			$back['type'] = 'warning';
			points::jan($back);	
		}
		$details['email'] = trim($_POST['email']);
	}
	
	if(isset($_POST['status'])) //检查用户状态
	{
		if(!in_array($_POST['status'],['0','1']))
		{
			$back['err'] = '提供了一个无效的状态值！';
			$back['type'] = 'warning';
			points::jan($back);	
		}
		$details['yes'] = $_POST['status'];
	}
	
	//是否使用默认的密码
	if(isset($_POST['cipher']) && $_POST['cipher'] == '1')
	{
		//使用默认的密码值 即重置密码
		$details['pwd'] = 'd847f5bbe427010efbf1e27934b8efcb';
	}

	//检查头像地址
	if(isset($_POST['portrait']))
	{
		$details['ppath'] = $_POST['portrait'];
	}
	
	if($editor) //修改记录
	{
		if(isset($details['usr'])) //确认没有别的重名用户
		{
			$exists = DBC::selected(SQL::GetCountsFromPointsUsersByIdAndUsername,
					  [':usr'=>$details['usr'],':id'=>$_arr[1]],['one'=>TRUE]);
			if($exists['total'] > 0)
			{
				$back['err'] = '用户名已存在';
				points::jan($back);
			}
		}
		//更新记录
		$SQL = 'UPDATE ' . SQL::TblUsers . ' SET  ';
		$update = []; $str = '';
		foreach($details AS $k=>$v)
		{
			$str .= $k . '=' . ':' . $k . ',';
			$update[':' . $k] = $v;
		}
		$SQL .= trim($str,',') . ' WHERE id = :id';
		$update[':id'] = $_arr[1];
		$stmt = DBC::PDO()->prepare($SQL);
		if($stmt->execute($update))
		{
			$back['err'] = '修改成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '修改失败，请检查输入是否有误！'; }
		
	}else //新建记录
	{
		$details['pwd'] = 'd847f5bbe427010efbf1e27934b8efcb';
		
		$exist = DBC::selected(SQL::GetCountsFromPointsUsersByUsername,
				  [':usr'=>$details['usr']],['one'=>TRUE]);
		if($exist['total'] > 0)
		{
			$back['err'] = '用户名已存在';
			points::jan($back);
		}
		//新建用户
		$inserts = [];
		foreach($details AS $k=>$v){ $inserts[':' . $k] = $v;	}  
		if(DBC::modified(SQL::NewUserInPointsUsers,$inserts))
		{
			$back['status'] = 1;
			$back['err'] = '增加用户成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '增加用户失败，检查网络和服务器'; }
	}
	points::jan($back);