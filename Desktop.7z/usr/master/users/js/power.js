$(document).ready(function(){
	
	var ask = 'ask/power.ajx.php';
    grid(ask,{"page":1});
	
	//获取显示内容
	function grid(url,json)
    {
        $.post(url,json,function(r){  console.log(r);
            var j = $.parseJSON(r);  //返回的结果
            if (j.tbody)
            {
                $('#ul').html(j.tbody);
				local.page = j.page;
				$('#paging span').html(paging(j).show());
				local.empty = parseInt(j.total) == 0 ? true : false;
            }
        });
    }
	
	//修改内容
	$('#ul').delegate('li .revisable','mouseover',function(){
		var w = $(this).offset().left + $(this).width() + 10;
		var h = $(this).offset().top;
		$('#editable').css({"left":w,"top":h}).fadeIn(); //出现修改和保存按钮
		var id = $(this).closest('ul').attr('id') + '_' + $(this).attr('name');
		$(this).parent().attr('id',id); //为对应的li设置一个id
		$('#editable').attr('_id',id); //为编辑和保存的父标签设置id
	});
	
	//当鼠标移到编辑和保存按钮时显示
	$('#editable').mouseover(function(){ $(this).show(); });
	//编辑按钮的单击事件
	$('#editor').click(function(e){
		e.stopPropagation(); //阻止事件冒泡
		var id = $('#editable').attr('_id');
		//如果没有点击编辑按钮
		if($('#' + id + ' span').children('.in-revisable').length == 0)
		{
			var name = id.split('_')[2],html = '';
			if(name == 'yes')
			{
				html = '<select id="status" class="in-revisable">';
				html += '<option value="1">使用中</option>';
				html += '<option value="0">被锁定</option>';
				html += '</seclect>';
			}else if(name == 'authority')  
			{
				html += '<input class="in-revisable" id="powers"  />';
				var div = '<div id="selectbox">';
					div += '<label><input type="checkbox" class="power" />编辑</label>';
					div += '<label><input type="checkbox" class="power" />删除</label>';
					div += '<label><input type="checkbox" class="power" />增加</label>';
					div += '<label><input type="checkbox" class="power" />权限扩展1</label>';
					div += '<label><input type="checkbox" class="power" />权限扩展2</label>';
					div += '<label><input type="checkbox" class="power" />权限扩展3</label>';
					div += '<label><input type="checkbox" class="power" />导入</label>';
					div += '<label><input type="checkbox" class="power" />导出</label>';
					div += '<a id="ensure">确定</a>';
					div += '</div>';
				$('#' + id).after(div);
			}else{	html = '<input class="in-revisable"  />';}
			$('#' + id + ' span').append(html);
			$('.in-revisable,#selectbox label').click(function(e){  e.stopPropagation();  });
		}
		//移除其它的正在编辑的内容
		$('#' + id).siblings('li').children('span').children('.in-revisable').remove();
		if(name != 'authority'){ $('#ul ul').children('#selectbox').remove();} //移除权限选择
		//移除其它父节点的.in-revisable元素
		$('#' + id).parent().siblings('ul').children('li').children('span').children('.in-revisable').remove();
		$('#' + id).parent().siblings('ul').children('#selectbox').remove();
		$(this).parent().hide(); //隐藏编辑和保存按钮的父元素
	});

	//组合权值注意顺序
	$('#ul').delegate('#selectbox #ensure','click',function(){
		$('#oper').hide();
		var power = '',powers = $('#ul #selectbox .power'); 
		powers.each(function(i,obj){
			var check = $(obj);
			power += check.is(':checked') ? '1' : '0';
		});
		$('#powers').val(power);
	});
	
	//点击保存按钮
	$('#writer').click(function(){
		var id = $('#editable').attr('_id'); 
		var field = id.split('_')[2],v = '';
		if(field == 'yes'){				v = $('#status').val();
		}else{							v = $('#' + id).children('span').children('input').val();	 }
		if(v.empty())
		{ 
			global.tip('没有提供修改内容！','warning');  
			return false;
		}
		//提交数据
		$.post('ask/power.save.ajx.php',{"id":id,"val":v},function(r){ console.log(r);
			var j = $.parseJSON(r);
			global.tip(j.err,j.type);
			if(j.status == 1){	/*grid(ask,{"page":1});*/	}
		});
	});

	$('#add').click(function(){
		global.tip('权限依附于某个类别，要新建权限，请转到类别管理器的操作界面！','warning');
		return false;
	});

	//分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});	

	//搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v,"page":1}); }
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v,"page":1});
    });
	
});
