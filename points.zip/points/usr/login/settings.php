<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    $user = new users(array('id'=>$_SESSION['points']['user']['id']));
    $users = $user->get(array('username','alias','email'));
?>
<!DOCTYPE html>
<html>
    <head>
        <?php echo points::head(false,array('title'=>'更改我的登录设置'));?>
        <link rel="stylesheet" href="/points/usr/login/css/settings.css" />
    </head>
    <body>
        <div id="outset">
            <h1 id="topic">正在更改用户ID:【<?php echo $_SESSION['points']['user']['id']; ?>】的设置</h1>
            <div id="info">
               <i><img src="/points/usr/local/images/warning.png" /></i>
               <span>更改此用户的某些选项，比如:用户名或者密码，可能会导致重新登录。请确保所有工作已成功完成！</span>
            </div>
            <div id="modifying">
                <p>
                    <label>更改登录名为：</label><input id="username" value="<?php echo $users['username'][0]; ?>" />
                    <span class="warning">登录名不能包含中文字符且长度不能超过13个字符.</span>
                </p>
                <p>
                    <label>更改显示名为：</label><input id="alias" value="<?php echo $users['alias'][0]; ?>" />
                    <span class="warning">显示名的长度不能超过13个字符.如果此项设置为空时，显示名即为登录名。</span>
                </p>
                <p>
                    <label>更改登录密码：</label>
                    <input type="password" id="loginpassword" value="" />
                    <span class="warning">密码长度不得少于6个字符，且按强密码要求输入。如果为空则使用原密码。</span>
                </p>
                <p>
                    <label>确认登录密码：</label><input type="password" id="ensurepassword" value="" />
                    <span class="warning">密码长度不得少于6个字符，且按强密码要求输入。</span>
                </p>
                <p>
                    <label>电子邮箱地址：</label><input id="email" value="<?php echo $users['email'][0]; ?>" />
                    <span class="warning">电子邮箱应为有效的符合格式要求的多个字符。</span>
                </p>
            </div>
            <div id="submit">
                <p id="err"></p>
                <p id="oper"><a  id="ensure">更　改　我　的　设　置</a></p>
            </div>
        </div>
        <script src="js/settings.js"></script>
    </body>
</html>
