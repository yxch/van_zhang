/**
 *js分页函数
 *van_zhang 2016-01-23
 *参数 j是一个json对象
 *j.total,j.page,j.size,j.pager
 *j.firstName,j.lastName,j.nextName,j.endName
 *j.firstId,j.lastId,j.nextId,j.endId,j.pageClass,j.pageCurrentClass
 *j.inputId
 */
function paging(j)
{
    var pages = new Object();
    pages.total = parseInt(j.total) || 0;  //总记录数 程序必须提供的值
    pages.page = parseInt(j.page) || 1;    //当前页 程序必须提供的值
    pages.size = parseInt(j.size) || 20;   //分页大小 程序可能提供的值
    pages.pager = parseInt(j.pager) || 8; //显示的分页个数 程序可能提供的值
    
    pages.firstName = j.firstName || '首页'; //首页的显示名称
    pages.firstId = j.firstId || 'first'; //首页的id 如果用户没有提供就用first 单击事件和样式需要
    pages.lastName = j.lastName || '上一页'; //上一页的显示名称
    pages.lastId = j.lastId || 'last';    //上页的id 如果用户没有提供就用last 单击事件和样式需要
    pages.pageCurrentClass = j.pageCurrentClass || 'current'; //用户选择的当前页的类名
    pages.pageClass = j.pageCalss || 'page';    //每页的class 如果用户没有提供就用page 单击事件和样式需要
    pages.nextName = j.nextName || '下一页'; //下一页的显示名称
    pages.nextId = j.nextId || 'next';    //下页的id 如果用户没有提供就用next 单击事件和样式需要
    pages.endName = j.endName || '末页';  //末页的显示名称
    pages.endId = j.endId || 'end';    //末页的id 如果用户没有提供就用end 单击事件和样式需要
    pages.inputId = j.inputId || 'goto'; //跳转输入框的id 单击事件和样式需要
    
    pages.pages = Math.ceil(pages.total / pages.size); //计算页数
    
    pages.html = function(arr)
    {
        var html = '';
        for(var i=0;i<arr.length;i++)
        {
            //显示首页
            if(arr[i] == 'first'){ html += '<a id="' + pages.firstId + '" ' + 'name="1">' + pages.firstName + '</a>'; }
            var last = (pages.page - 1) >= 1 ? pages.page - 1 : 1; //显示上一页
            if(arr[i] == 'last'){ html += '<a id="' + pages.lastId + '" ' + 'name="' + last + '">' + pages.lastName + '</a>'; }
            if(arr[i] == 'page'){ html += pages.all(); } //显示所有页
            var next = (pages.page + 1) <= pages.pages ? pages.page + 1 : pages.pages; //显示下一页
            if(arr[i] == 'next'){ html += '<a id="' + pages.nextId + '" ' + 'name="' + next + '">' + pages.nextName + '</a>'; }
            //显示末页
            if(arr[i] == 'end'){ html += '<a id="' + pages.endId + '" ' + 'name="' + pages.pages + '">' + pages.endName + '</a>'; }
            if (arr[i] == 'goto'){ html += '<input id="' + pages.inputId + '" value="' + pages.page + '"/>'; } //显示跳转到第几页的输入框
        }
        return html;        
    };
    
    pages.all = function()
    {
        var s = 1,e = pages.pager;
        var h = Math.ceil(pages.pager / 2);
        s = pages.page - h < 1 ? 1 : pages.page - h; //设置起始页
        e = pages.page + h > pages.pages ? pages.pages : s + (pages.pager - 1); //设置结束页
        if(e - pages.pager + 1 >= 1){ s = (e - s + 1) < pages.pager ? e - pages.pager + 1 : s;}
        var a = '';
        for(s;s<=e;s++)
        {
           var current = pages.page == s ? pages.pageCurrentClass : ''; 
           a += '<a class="' + pages.pageClass + ' ' + current + '" ' + 'name="' + s + '">' + s + '</a>';
        }
        return a;
    };
    pages.show = function(){ return pages.html(['first','last','page','next','end']);};
    pages.only = function(){ return pages.html(['page']); }
    pages.simple = function(){ return pages.html(['last','page','next']);}
    pages.full = function(){ return pages.html(['first','last','page','next','end','goto']);}
    return pages;
}