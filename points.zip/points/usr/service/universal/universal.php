<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];
?>
<!DOCTYPE html>
<html>
    <head>
        <?php echo points::head(0); ?>
        <link rel="stylesheet" href="css/universal.css" />
    </head>
    <body>
        <div id="grids">            
            <div id="topoper">
                <?php if($auth[3] == '1'){ ?><a id="add">增加</a><?php } ?>
                <select id="products">
                    <option value="">万能险</option>
                </select>
                <span id="month">
                    <select id="years">
                        <option value="">选择年份</option>
                        <option value="2015">2015年</option>
                        <option value="2016">2016年</option>
                        <option value="2017">2017年</option>
                        <option value="2018">2018年</option>
                        <option value="2019">2019年</option>
                        <option value="2020">2020年</option>
                        <option value="2021">2021年</option>
                        <option value="2022">2022年</option>
                        <option value="2023">2023年</option>
                        <option value="2024">2024年</option>
                        <option value="2025">2025年</option>
                    </select>
                    <select id="months">
                        <option value="">选择月份</option>
                        <option value="01">1月</option>
                        <option value="02">2月</option>
                        <option value="03">3月</option>
                        <option value="04">4月</option>
                        <option value="05">5月</option>
                        <option value="06">6月</option>
                        <option value="07">7月</option>
                        <option value="08">8月</option>
                        <option value="09">9月</option>
                        <option value="10">10月</option>
                        <option value="11">11月</option>
                        <option value="12">12月</option>
                    </select>
                </span>
            </div>
            <div id="announce"><span>输入利率时请输入精确值,前端显示结果为精确值除以 100 后并四舍五入 如：623.55显示为 6.24%.利率的最大值为:9999.99999999 </span><span id="tip"></span></div>
            <table id="plaid"></table>
            <div id="loading">正在加载数据，请稍候......</div>
        </div>    
    </body>
    <script type="text/javascript" src="js/universal.js"></script>
</html>