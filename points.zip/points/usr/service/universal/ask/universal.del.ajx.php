<?php
    require $_SERVER['DOCUMENT_ROOT']  . '/points/loader.inc.php';
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($auth,'delete')){ echo points::jen(0,'用户权限请求');exit; }
    
    $data = $_POST['data'];
    $arr = explode(',',$data);
    if(strlen($arr[0]) > 10){ exit;}
    
    $date = $arr[0];
    $id = array();        
    for($i=1,$l=count($arr);$i<$l;$i++)
    {
        $price = explode('-',$arr[$i]);
        if(ctype_digit($price[0]) && $price[1] != '-'){ $id[] = $price[0]; }
    }
    $idstr = implode(',',$id);
    $where = "accountId IN($idstr) AND settleTime = '{$date}'";
    $prices = new prices($where);
    $deleted = $prices->delete();
    if($deleted)
    {
        echo points::jen(1,'删除成功');exit;
        
    }else{ echo points::jen(0,'删除失败');exit; }        
