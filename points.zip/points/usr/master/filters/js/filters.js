$(document).ready(function(){
    var ask = 'ask/filters.ajx.php';
    var page = 1;
    grid(ask,{"page":page});
    
    //通用函数，为表格的行加载单击事件，来动态显示用户是否选中
    $('#grids tbody').delegate('tr','click',f._trClick);
    
    //编辑过滤器
    $('#grids tfoot tr td').delegate('#edit','click',function(){ 
        var tr = $('#grids tbody .checked');
        var err = document.getElementById('err');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        if (tr.length > 1) { err.innerHTML = '一次只能编辑一个条目'; return; }
        err.innerHTML = '';
        var id = tr.find(':first-child').text();
        window.location.href="filters.oper.php?fid=" + id;    
    });
    
    //删除过滤器
    $('#grids tfoot tr td').delegate('#delete','click',function(){
        var tr = $('#grids tbody .checked');
        var err = document.getElementById('err');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        err.innderHTML = '';
        var id = [];
        tr.each(function(i,obj){
            id.push($(obj).find(':first-child').text());        
        });
        if (window.confirm('你确定要删除这些条目吗？'))
        {
            $.post('ask/filters.delete.ajx.php',{"id":id.join('|')},function(r){
                var j = $.parseJSON(r);
                page = j.page;
                if (j.status == 1) { grid(ask,{"page":page}); }
                $('#err').text(j.message);
            });        
        }        
    });
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#fpage').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
    
    function grid(url,json)
    {
        var num = parseInt(json.page) || 1;
        $.post(url,json,function(r){
            var j = $.parseJSON(r);
            var status = parseInt(j.status);
            var empty = '加载数据失败或者没有可用数据,请稍候重试！';
            if (status == 1)
            {
                page = j.page;
                $('tbody').html(j.tbody);
                $('#oper').html(j.operations);
                $('#fpage').html(paging(j).show());
            }
            
            if (status == 2)
            {
                $('#grids tbody #loading td').html(empty);
                $('#oper').html(j.operations);
                $('#fpage').html('&nbsp');
                setTimeout(function(){$('#grids tbody #loading td').html(empty);},6000);
            }
        });
    }
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v});}
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v});
    });    

});
