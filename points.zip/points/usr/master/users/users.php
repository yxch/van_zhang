<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>
<!DOCTYPE html>
<html>
    <head>
       <?php echo points::head(0); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="/points/usr/local/css/grids.css" />
       <link rel="stylesheet" href="css/users.css" />
       <script src="/points/usr/local/js/f.js"></script>
       <script src="/points/usr/local/js/paging.js"></script>
       <script src="js/users.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1>用户管理器</h1><span id="err"></span></div>
            <div id="tip">
                <p class="first">友情提示：顶部的搜索框可以按<strong>用户名</strong><strong>用户显示名</strong><strong>用户e-mail地址</strong>的相关内容进行模糊搜索。输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
            </div>
            <table id="grids">
                <thead>
                    <tr>
                        <td class="width6">编号</td>
                        <td>用户名</td>
                        <td>用户别名</td>
                        <td class="width22">EMAIL地址</td>
                        <td>头像路径</td>
                        <td class="width8">用户类型</td>
                        <td class="width6">状态</td>
                        <td>修改时间</td>
                        <td>创建时间</td>
                    </tr>
                </thead>
                <tbody><tr id="loading"><td colspan="9">loading data！please wait......</td></tr></tbody>
                <tfoot><tr><td colspan="9"><span id="oper">&nbsp</span><span id="fpage">&nbsp</span></td></tr></tfoot>
            </table>
        </div>
        <div id="pop">
            <div id="close"><a id="closed"><img title="关闭" src="/points/usr/local/images/close.png" /></a></div>
            <div class="pop">
                <div id="users">
                    <p id="ischanged"><label>使用原【默认】密码</label><input type="checkbox" id="pwd" /></p>
                    <p><label>用户密码：</label><input type="password" id="pwd1" value="" /></p>
                    <p><label>确认密码：</label><input type="password" id="pwd2" va lue="" /></p>
                    <p id="error"></p>
                </div>                
            </div>
            <div id="oper"><a id="ensure">确定</a></div>
        </div>
        <div id="overlay"></div>
    </body>
</html>