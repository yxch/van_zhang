<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    //当前用户是否有修改条目的权限以防止恶意写入
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'delete')){ echo points::jen(0,'用户权限请求'); exit;}
    
    if(empty($_POST['id'])){ echo points::jen(0,'没有条目选中，异常的请求！'); exit; }
    
    $arr = explode('|',$_POST['id']);
    $len = count($arr);
    //校验用户输入
    for($i=0;$i<$len;$i++){  if(!ctype_digit($arr[$i])){ echo points::jen(0,'包含了异常的请求！'); exit; }   }
    
    //删除条目
    $where = ' id IN(' . implode(',',$arr) . ')';
    $category = new category($where);
    if($category->delete())
    {
        echo points::jen(1,'删除了共 ' . $len . ' 个条目');exit;
        
    }else{ echo points::jen(0,'删除失败');exit; }
