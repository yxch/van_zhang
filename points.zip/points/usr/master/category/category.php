<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>
<!DOCTYPE html>
<html>
    <head>
       <?php echo points::head(0); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="/points/usr/local/css/grids.css" />
       <script src="/points/usr/local/js/f.js"></script>       
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1>类别管理器</h1><span id="err"></span></div>
             <div id="tip">
                <p class="first">提示：顶部的搜索框可以按<strong>类别显示名</strong>,<strong>管理URL</strong>或者<strong>访问URL</strong>的相关内容进行模糊搜索。输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
            </div>
            <table id="grids">
                <thead>
                    <tr>
                        <td class="width6">编号</td>
                        <td class="hidden">类别显示名</td>
                        <td class="width6">区域ID</td>
                        <td class="width22">管理URL</td>
                        <td class="width22">访问URL</td>
                        <td class="width6">显示在</td>
                        <td class="width6">状态</td>
                        <td>创建时间</td>
                    </tr>
                </thead>
                <tbody>
                    <tr id="loading"><td colspan="8">loading data！please wait......</td></tr>
                </tbody>
                <tfoot>
                    <tr><td colspan="8"><span id="oper">&nbsp</span><span id="fpage">&nbsp</span></td></tr>
                </tfoot>
            </table>
        </div>
    </body>
    <script src="/points/usr/local/js/paging.js"></script>
    <script src="js/category.js"></script>
</html>