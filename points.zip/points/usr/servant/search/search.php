<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $title = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['title'];

    //根据categoryid获取全部过滤器的信息
    $filter = new filter(array('categoryId'=>$_SESSION['points']['item']['id']));
    $filters = $filter->get(array('id','name','fieldText','searcher'));
    $len = 0;
    if($filter->iTotal() > 0)
    {
        $arr = array();
        for($i=0;$i<$filter->iTotal();$i++)
        {
            if($i == 0)
            {
                $arr['name'] = $filters['name'][0];
                $arr['fields'] = $filters['fieldText'][0];
                $arr['searcher'] = $filters['searcher'][0];
                $_SESSION['points']['search']['title'] = $filters['name'][0];
            }
            $id = $filters['id'][$i];
            $_SESSION['points']['filters'][$id]['name'] = $filters['name'][$i];
            $_SESSION['points']['filters'][$id]['fields'] = $filters['fieldText'][$i];
            $_SESSION['points']['filters'][$id]['searcher'] = $filters['searcher'][$i];
        }
        
        $fields = points::parseField($arr['fields']);
        $fieldNames = $fields['field'];
        $len = count($fields);
        
        $counts = 0; $err = 0;
        if(!empty($arr['searcher']))
        {
            $search = explode(',',$arr['searcher']);
            $counts = count($search);
            for($k=0;$k<$counts;$k++){if(!isset($fields['field'][$search[$k]])){ $err += 1; }}
        }
        $fields = array_chunk($fieldNames,4,true);
    }    
    $fatal = $len == 0 || $counts == 0 || $err > 0;    
?>
<!DOCTYPE html>
<html>
    <head>
        <?php echo points::head(0); ?>
        <link rel="stylesheet" href="css/search.css" />
        <script src="/points/usr/local/js/f.js"></script>
        <script src="js/search.js"></script>
    </head>
    <body>
        <div id="frm">
            <div id="title"><?php echo $title; ?></div>
            <?php if($fatal){ ?>
            <div id="none">此类别设置的搜索选项可能不可用或者没有设置有效值</div>
            <?php }else{ ?>
            <form id="search" action="searcher.php" method="post">
                <div id="option">
                    <span>请选择类别下的过滤：
                        <select id="filters" name="filter">
                            <?php foreach($_SESSION['points']['filters'] as $k=>$v){ ?>
                                <option value="<?php echo $k;?>"><?php echo $v['name']; ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div id="condition">
                    <select id="searches" name="search">
                        <?php for($k=0;$k<$counts; $k++){?>
                            <option value="<?php echo $search[$k];?>"><?php echo $fieldNames[$search[$k]]; ?></option>
                        <?php } ?>
                    </select>
                    <input type="text" name="searcher" value="" />
                </div>
                <div id="ways">
                    <label id="lb-title">匹配方式：</label>
                    <label><input type="radio" name="type" value="1" checked="checked" />精确</label>
                    <label><input type="radio" name="type" value="2" />模糊</label>
                    <label><input type="radio" name="type" value="3" />大于</label>
                    <label><input type="radio" name="type" value="4" />小于</label>
                    <label><input type="radio" name="type" value="5" />大于或等于</label>
                    <label><input type="radio" name="type" value="6" />小于或等于</label>
                    <label><input type="radio" name="type" value="7" />不等于</label>
                </div>
                
                <div id="fields">
                    <p id="p-title">显示字段：</p>
                    <div id="select">
                        <?php for($i=0,$l=count($fields);$i<$l;$i++){ ?>
                        <p>
                            <?php foreach ($fields[$i] as $key=>$name){ ?>
                                <label class="lb-select"><input type="checkbox" name="fields[]" value="<?php echo $key; ?>" checked="checked"><?php echo $name; ?></label>
                            <?php } ?>
                        </p>
                        <?php } ?>
                    </div>
                </div>
                <p id="err"></p>
                <p id="oper"><input type="submit" value="搜索结果" onclick="return check(this.form); " /></p>
            </form>
           <?php } ?>
        </div>
    </body>
</html>