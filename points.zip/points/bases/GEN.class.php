<?php
class GEN
{
  /**
   *得到数组类型 索引数组 混合数组 关联数组 函数名称由getArrayType 改成 type
   *@param array $arr
   *@return -1 不是一个数组 0空数组 1索引数组 2 关联数组 3 混合数组
   */
  public static function typed($arr)
  {
	if(!is_array($arr)){ return -1;} //如果不是一个数组 返回-1
	if(empty($arr)) { return 0;} //空数组无意义
	$t = count($arr);
	$intersect = array_intersect_key($arr,range(0,$t-1)); //求两个数组的交集
	if(count($intersect) == $t) {  return 1;  }elseif(empty($intersect)) {  return 2; }else { return 3; }
  } 
  
  /**
   *本函数用来在php文件中实现跳转
   *@param string $url
   *@return string 
   *
  public static function JSGO($url)
  {
	$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://';
    $url = preg_match("/^(http:\/\/)|(https:\/\/)|(ftp:\/\/).*$/i",$url) ? $url : $protocol . $url;
    echo "<script language=\"javascript\">document.location=\"$url\"</script>";
	exit();
  }*/
  
  //获取主机地址(包含协议)
  public static function PHOST(){	return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'];  }
  
  //获取url中完整的path部分 如http://www.sample.com/samples/aaa/bbb/
  public static function UPATH()
  {
	$PHPSELF = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	$short = strtr($PHPSELF,array(basename($PHPSELF)=>''));
	return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'] . $short;
  }
  
  //获取url中的路径部分 比如 /samples/aaaa/bbb/
  public static function UDIRS()
  {
	$PHPSELF = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	return strtr($PHPSELF,array(basename($PHPSELF)=>''));
  }
  
  //获取完整的文件路径
  public static function UFILE()
  {
	$PHPSELF = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'] . $PHPSELF;
  }
  
  /**
   * 得到文件的文件名和扩展名
   * @param string $sFilePath
   * @return array
   */
  public static function arFileInfo($sFilePath)
  {
    $ar = array('filename'=>'','fileType'=>'');
    if(!empty($sFilePath))
    {
	  if(strpos($sFilePath,'?') !== false){	$tmp = explode('?',$sFilePath);	$sFilePath = $tmp[0]; }
      $sFullName = basename($sFilePath);
      $arFileInfo = explode('.',$sFilePath);
      $ar['fileType'] = $arFileInfo[count($arFileInfo)-1];
      $arReplace = array($ar['fileType']=>'');
      $ar['filename'] = rtrim(strtr($sFullName,$arReplace),'.');
    }
    return $ar;
  }
        
  /**
   *本函数用来根据文件完整路径输出文件可读的文件大小，（当前仅支持TB级）
   *@param int $filename  文件的完整路径 注意在非GB2312的编码下无法识别，因此文件名最好不要是中文
   *@return string $size 返回文件大小或者假
   */
  public static function fsize($filename)
  {
	if(!file_exists($filename)){ return 0;}
	$size = filesize($filename);
	if($size > pow(2,40))		 	$size = round($size/pow(2,40),2) . 'TB';
	elseif($size >= pow(2,30)) 		$size = round($size/pow(2,30),2) . 'GB';
	elseif($size >= pow(2,20)) 		$size = round($size/pow(2,20),2) . 'MB';
	elseif($size >= pow(2,10)) 		$size = round($size/pow(2,10),2) . 'KB';
	else				     	 	$size = $size . 'byte';
	return $size;
  }
	 
  /**
  * 读取配置段
  * @param string $path 配置文件路径
  * @param string $section 配置段，如果设置了$section 则只返回此配置段的内容 否则返回全部
  */
  public static function CFG($path,$section='')
  {
    $arr = null;    
    if(!(file_exists($path) && is_readable($path))){ return ''; }
	$arr = parse_ini_file($path,true); //读取配置文件
	//如果没有提供配置段返回全部内容否则返回该配置段的内容
	return (isset($section) && !empty($section) && array_key_exists($section, $arr)) ? $arr[$section] : $arr;
  }
}
