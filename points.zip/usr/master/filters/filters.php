<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>  
<!DOCTYPE html>
<html>
    <head>
       <?php echo points::head(0); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="/points/usr/local/css/grids.css" />
       <script src="/points/usr/local/js/f.js"></script>
       <script src="/points/usr/local/js/paging.js"></script>       
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1>数据过滤器列表</h1><span id="err"></span></div>
            <div id="tip">
                <p class="first">友情提示：顶部的搜索框可以按<strong>过滤器名称</strong>模糊搜索输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
            </div>
            <table id="grids">
                <thead>
                    <tr>
                        <td class="width6">编号</td>
                        <td>过滤器名称</td>
                        <td>字段内容</td>
                        <td>搜索选项</td>
                        <td>SELECT</td>
                        <td>FACTOR</td>
                        <td>REST</td>
                        <td class="width6">状态</td>
                        <td class="width14">创建时间</td>
                    </tr>
                </thead>
                <tbody>
                    <tr id="loading"><td colspan="9">loading data！please wait......</td></tr>
                </tbody>
                <tfoot>
                    <tr><td colspan="9"><span id="oper">&nbsp</span><span id="fpage">&nbsp</span></td></tr>
                </tfoot>
            </table>
        </div>
    </body>
    <script src="js/filters.js"></script>
</html>