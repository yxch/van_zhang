//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };
String.prototype.doubled = function(){ var i = parseInt(this); return i < 10 ? '0' + i : i; };

$(document).ready(function(){
    
    //获取表的内容
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
                $('#fields tbody').html('');
                $('#fields tbody').html('<tr><td><input /></td><td><input /></td><td><input /></td><td><input /></td><td><input type="checkbox" class="check" /></td></tr>');  
                return false;
            }
            $('#select').val('FROM ' + v);
            $.post('../category/ask/columns.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
                    $('#fields tbody').html('');
                    $('#fields tbody').html(j.tbody);                    
                }
            });
        }
    });  
    
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
        var trCheck = $('#fields tbody .clone');
        var obj = trCheck.length == 0 ? 'tr:last-child' : '.clone';
        $('#fields tbody ' + obj).after($('#fields tbody tr:first-child').clone());       
        $('#fields tbody').delegate('.check','click',check);
    });
    
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){        
        var tr = $('#fields tbody tr');
        var trCheck = $('#fields tbody .clone'); //不能全部删除
        if(trCheck.length != tr.length && trCheck.length > 0){ $('#fields tbody .clone').remove(); }        
    });
    
    //用户点选字段 可能是复制或者删除
    $('#fields tbody').delegate('.check','click',check);
    function check()
    {
        $(this).is(':checked') ? $(this).closest('tr').addClass('clone')
                               : $(this).closest('tr').removeClass('clone');
    }
    
    //保存过滤器
    var filterOldValue = filtered();
    function filtered() //收集过滤器值的函数
    {
        var filter = {};
        filter.id = $('#id').text();
        filter.categoryId = $("input:radio[name='categories']:checked").val(); 
        filter.title = $.trim($('#filter-title').val());
        filter.status = $('#status').val();
        //过滤器的字段内容 字段名
        var tr = $('#fields tbody tr');
        var trArr = [];
        tr.each(function(i,obj){
            var td = $(obj).children('td');
            var inputValue = [];
            td.each(function(j,object){
                var input = $(object).children('input');
                if(!input.hasClass('check')){ inputValue.push($.trim(input.val())); }                
            });
            trArr.push(inputValue.join('|'));
        });
        filter.tname = $.trim($('#tablename').val());
        filter.fields = trArr.join(',');
        filter.searcher = $.trim($('#fsearch').val());
        filter.select = $.trim($('#select').val());
        filter.factor = $.trim($('#factor').val());
        filter.rest = $.trim($('#rest').val());
        return filter;
    }
    
    //提交内容
    $('#applied').click(function(){
        $('#error').text('');
        //重新收集过滤器的值
        var filter = filtered();
        if(filter.title.empty()){ $('#error').text('标题不能空.');return false;}
        var fields = filter.fields.split(',');
        for(var j=0;j<fields.length;j++)
        {
            var _tmp = fields[j].split('|');
            if (_tmp[0].empty() || _tmp[1].empty()) { $('#error').text('必须指定数据表字段和显示名称');return false; }
        }
        if(filter.select.empty()){ $('#error').text('select不能空.');return false;}
        var compare = false;
        for(var p in filter){ if(filter[p] != filterOldValue[p]){ compare = true; break;}}
        if(!compare){ $('#error').text('没有可用于提交的内容');return false; }
        //提交过滤器
        $.post('../category/ask/category.oper.filter.ajx.php',filter,function(r){ /*console.log(r);*/
            var j = $.parseJSON(r);
            //更新初始值 阻止重复提交
            if(j.yes == '1'){  filterOldValue = filtered(); }
            $('#error').text(j.tip);
        });
    });
    
    //用户点击更多
    $('.more').click(function(){ 
        var id = $(this).attr('id').split('-')[1]; 
        if ($(this).hasClass('extend'))
        {
            $('#dis' + id).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + id).fadeIn();
            $(this).text('折叠>>');
        }
    });

});