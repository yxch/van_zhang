<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    if(isset($_POST['uid']) && ctype_digit($_POST['uid']))
    {
    
        $user = new users(array('id'=>$_POST['uid']));
        $users = $user->get(array('username','alias'));
        echo $users['username'][0] . ' ' . $users['alias'][0];
        exit;
    }
    
    if(isset($_POST['cid']) && ctype_digit($_POST['cid']))
    {
        $category = new category(array('id'=>$_POST['cid']));
        $categories = $category->get(array('managingURL'));
        echo $categories['managingURL'][0];
    }