<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    
    $back = array('yes'=>0,'err'=>''); //响应求的结果
    if(!isset($_POST['id']) || !ctype_digit($_POST['id'])){ $back['err'] = '异常的请求'; points::jan($back); }
    //用户输入校验
    if(empty($_POST['authority'])){ $back['err'] = '权限值不能为空';points::jan($back); }
    $len = strlen($_POST['authority']);
    if($len != 10){ $back['err'] = '权限值错误';points::jan($back); }
    for($i=0;$i<$len;$i++){ if(!ctype_digit($_POST['authority'][$i])){ $back['err'] = '权限值不能为空';points::jan($back);}}
    if(!in_array($_POST['status'],array('1','0'))){ $back['err'] = '权限状态值不正确'; points::jan($back); }
    
    //当前用户是否有新建条目的权限以防止恶意写入
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'add')){ $set['err'] = '用户权限请求'; points::jan($set); }
    
    //保存内容
    $power = new power(array('id'=>$_POST['id']));
    if($power->iTotal() > 0)
    {
        if($power->set(array('authority'=>$_POST['authority'],'status'=>$_POST['status'],'modifiedTime'=>date('Y-m-d H:i:s'))))
        {
            $back['yes'] = 1;
            $back['err'] = '保存成功';   
        }else{ $back['err'] = '保存失败';}
        
    }else{ $back['err'] = '异常的请求';}
    points::jan($back);
