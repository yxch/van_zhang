//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };

$(document).ready(function(){
    
    //初始化页面表格内容
    var page = 1;
    var ask = 'ask/regions.ajx.php';
    grid(ask,{"page":page}); //默认显示第一页
    
    //初始化弹窗的大小和遮罩层的大小
    f.pop();
    $(window).resize(function(){  f.pop();  f.overlay(); });
    
    //通用函数，为表格的行加载单击事件，来动态显示用户是否选中
    $('#grids tbody').delegate('tr','click',f._trClick);
    
    //获取即将操作的对象
    var err = document.getElementById('err');
    var td = $('#grids tfoot tr td');
    var modify = false;
    
    //用于保存初始值的对象
    var vs = {};
    
    //编辑操作
    td.delegate('#edit','click',function(){
        var checks = $('#grids .checked');        
        var adding = $('#grids .adding');
        if(adding.length >= 1){ err.innerHTML = '正在增加新条目，无法同时编辑其它条目.'; return false; }
        if(checks.length == 0){ err.innerHTML = '没有条目选中'; return false; }
        if(checks.length > 1){ err.innerHTML = '一次只能编辑一个条目'; return false; }
        err.innerHTML = '';
        //取消tr的单击事件
        $('#grids tbody').undelegate('tr','click',f._trClick);
        if(modify){ return false; }
        
        //修改项目呈现
        $('#grids .checked td').each(function(i,obj){
            var td = $(obj);
            var v = td.text();
            var attr = td.attr('region');
            if(attr == 'id'){ vs.id = td.text(); } //保存初始值
            if (td.hasClass('editable'))
            {                
                if (attr == 'region')
                {
                    var r = {"用户数据":1,"控制台":2,"定制":3};
                    td.html('<select id="regions" class="transparent"><option value="1">用户数据</option><option value="2">控制台</option><option value="3">定制</option></seclect>');
                    $('#regions').val(r[v]);
                    vs.region = r[v]; //保存原始值
                }
                if (attr == 'name')
                {
                    td.html('<input id="name" class="transparent" value="' + v + '" />');
                    vs.name = v;
                }
                if (attr == 'authority')
                {
                    td.html('<input id="authority" class="transparent" value="' + v + '" />');
                    vs.authority = v;
                    $('#authority').focus(function(){
                        f.overlay().show();
                        $('#pop').show();                        
                    });
                }
                if (attr == 'directory')
                {
                    td.html('<input id="directory" class="transparent" value="' + v + '" />');
                    vs.directory = v;
                }
                if (attr == 'status')
                {
                    var j = {"停用":0,"启用":1};
                    td.html('<select id="status" class="transparent"><option value="1">启用</option><option value="0">停用</option></seclect>');
                    $('#status').val(j[v]);
                    vs.status = j[v];
                }
            }
            modify = true;
        });
    });
    
    //弹窗确定事件
    $('.ensure').click(function(){
        var power = document.getElementsByName('power');
        var powers = [];
        for(var i=0,len=power.length;i<len;i++){ powers.push(power[i].checked ? 1 : 0); }
        //赋值
        $('#authority').val('1' + powers.join('') + '0');
        //清空
        for(var i=0,len=power.length;i<len;i++){ if(power[i].checked){power[i].checked = false;} }
        
        //关闭弹窗和遮罩层
        $('#pop').hide();
        f.overlay().hide();
    });
    
    //应用操作
    td.delegate('#applied','click',function(){ 
        //应用编辑
        var checked = $('#grids tbody .checked');
        var addings = $('#grids tbody .adding');
        var applied = {};
        if(checked.length == 0 && addings.length == 0){ err.innerHTML = '编辑或者新增操作请求'; return false; }
        if (checked.length > 0 && !modify && addings.length == 0) { err.innerHTML = '编辑操作请求'; return false; }
        var tds = modify ? $('#grids tbody .checked td') : $('#grids tbody .adding td');
        
        //获取值
        tds.each(function(i,obj){
            var td = $(obj);
            var attr = td.attr('region');
            if(attr == 'id' && modify){ applied.id = td.text();}
            if(attr == 'region'){ applied.region = $('#regions').val();}
            if(attr == 'name'){ applied.name = $('#name').val();}
            if(attr == 'authority'){ applied.authority = $('#authority').val();}
            if(attr == 'directory'){ applied.directory = $('#directory').val();}
            if(attr == 'status'){ applied.status = $('#status').val();}                
        });
        
        //验证值
        if (modify && applied.id.empty()) { err.innerHTML = '修改ID未正确提供'; return false; }
        if (applied.region.empty() || $.inArray(applied.region,['1','2','3']) == -1)
        {
            err.innerHTML = '提供的区域代号不正确'; return false;
        }
        if (applied.name.empty()) { err.innerHTML = '没有提供区域选项名称'; return false; }
        if (applied.authority.empty()) { err.innerHTML = '提供的权限值不正确'; return false; }
        if (applied.directory.empty()) { err.innerHTML = '提供的目录结构不正确'; return false; }
        if (applied.status.empty() || $.inArray(applied.status,['1','0']) == -1)
        {
            err.innerHTML = '提供的状态值不正确'; return false;
        }
        
        //比较初始值和修改后的值，如果全等则不提交
        var notAllowSubmit = true;
        for(var p in applied){  if(applied[p] != vs[p]){  notAllowSubmit = false; break; } }
        if(notAllowSubmit){ err.innerHTML = '没有可用于提交的内容'; return false; }
        
        //提交改变
        $.post('ask/regions.save.ajx.php',applied,function(r){ //console.log(r);
            var j = $.parseJSON(r);
            if (j.status == 1)
            {
                grid(ask,{"page":page}); //刷新子窗体
                $('#grids tbody').delegate('tr','click',f._trClick);
                modify = false;
            }else{ err.innerHTML = j.err;}
        });    
    });
    
    //删除操作
    td.delegate('#delete','click',function(){
        var checked = $('#grids tbody .checked');
        var ids = [];
        if (checked.length > 0)
        {
            //获取值
            $('#grids tbody .checked td').each(function(i,obj){
                var td = $(obj);
                var attr = td.attr('region');
                if(attr == 'id'){  ids.push(td.text());}
            });
        }
        if (checked.length > 0 && confirm('确定要删除这些条目吗？删除后将无法恢复！'))
        {
            $.post('ask/regions.delete.ajx.php',{id:ids.join('|')},function(r){ console.log(r);
                var j = $.parseJSON(r);
                if (j.status == 1)
                {
                    grid(ask,{"page":page}); //刷新子窗体
                    $('#grids tbody').delegate('tr','click',f._trClick);
                }else{ err.innerHTML = j.message;}
            });
        }else{err.innerHTML = '没有条目选中'; return false;}
    });
    
    //增加操作
    td.delegate('#add','click',function(){
        $('#loading').hide();
        var checks = $('#grids .checked');
        if (checks.length > 0) { err.innerHTML = '正在编辑条目,不能同时增加新条目！'; return false;}
        var adding = $('#grids tbody .adding');
        if (adding.length == 0)
        {
            err.innerHTML = '';
            var tr = '<tr class="adding"><td region="id"></td><td region="region"><select id="regions" class="transparent"><option value="1">用户数据</option><option value="2">控制台</option><option value="3">定制</option></seclect></td><td region="name"><input id="name" class="transparent" value="" /></td><td region="authority"><input id="authority" class="transparent" value="" /></td><td region="directory"><input id="directory" class="transparent" value="" /></td><td region="status"><select id="status" class="transparent"><option value="1">启用</option><option value="0">停用</option></seclect></td><td></td></tr>'
            $('#grids tbody tr:first-child').before(tr);
            $('#authority').focus(function(){
                f.overlay().show();
                $('#pop').show();                        
            });
            
        }else{ err.innerHTML = '一次仅能增加一个条目,请先应用后再增加'; }        
    });
    
    function grid(url,json)
    {
        var num = parseInt(json.page) || 1;
        $.post(url,json,function(r){
            var j = $.parseJSON(r);
            var status = parseInt(j.status);
            var empty = '加载数据失败或者没有可用数据,请稍候重试！';
            if (status == 1)
            {
                page = j.page;
                $('tbody').html(j.tbody);
                $('#oper').html(j.operations);
                $('#fpage').html(paging(j).show());
            }
            
            if (status == 2)
            {
                $('#grids tbody #loading td').html(empty);
                $('#oper').html(j.operations);
                $('#fpage').html('&nbsp');
                setTimeout(function(){$('#grids tbody #loading td').html(empty);},6000);
            }
        });
    }
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#fpage').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v); }  }
    //});
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){  grid(ask,{"searcher":v}); }
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v});
    });
});
