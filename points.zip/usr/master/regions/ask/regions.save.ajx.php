<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限

    $set = array('status'=>0,'err'=>'');
    
    $updates = array('name'=>trim($_POST['name']),
                    'region'=>$_POST['region'],
                    'authority'=>$_POST['authority'],
                    'directory'=>trim($_POST['directory']),
                    'status'=>$_POST['status']           );
    //检验
    if(empty($updates['name'])){ $set['err'] = '没有提供区域选项名称'; points::jan($set); }
    if(!in_array($updates['region'],array('1','2','3'))){ $set['err'] = '提供的区域代号不正确'; points::jan($set);}
    if(!ctype_digit($updates['authority']) || strlen($updates['authority']) != 10)
    {
        $set['err'] = '提供的权限值不正确'; points::jan($set);
    }
    if(empty($updates['directory']) || $updates['directory'][0] != '/' || $updates['directory'][strlen($updates['directory']) - 1] != '/')
    {
        $set['err'] = '提供的目录结构不正确'; points::jan($set);
    }
    if(!in_array($updates['status'],array('1','0')) ){ $set['err'] = '提供的状态值不正确'; points::jan($set);}
    
    //写入内容
    if(isset($_POST['id'])) //修改条目
    {
         //当前用户是否有修改条目的权限以防止恶意写入        
        if(!points::allowed($authority,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
        
        if(!ctype_digit($_POST['id'])){ $set['err'] = '不正确的ID值'; points::jan($set); }
        $id = $_POST['id'];
        
        $region = new regions(array('id'=>$id));
        if($region->iTotal() > 0)
        {
            $updates['modifiedTime'] = date('Y-m-d H:i:s');  
            if($region->set($updates))
            {
                $set['status'] = 1; points::jan($set);
                
            }else{ $set['err'] = '修改失败'; points::jan($set); }
            
        }else{ $set['err'] = '未找到的内容'; points::jan($set); }
        
    }else //新增条目
    {
        //当前用户是否有新增条目的权限以防止恶意写入
        if(!points::allowed($authority,'add')){ $set['err'] = '用户权限请求'; points::jan($set); }
            
        $region = new regions();
        if($region->set($updates))
        {
            $set['status'] = 1; points::jan($set);
            
        }else{ $set['err'] = '提交失败,请重试！'; points::jan($set); }
    }
