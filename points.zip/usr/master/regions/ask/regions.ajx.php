<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $region = new regions();
    $back['total'] = $region->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //映射集 数据可视化处理
    $regionSets = array('1'=>'用户数据','2'=>'控制台','3'=>'定制');
    $statusSets = array('停用','启用');
    
    //获取数据
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
        $where = "name LIKE '%{$search}%' OR directory LIKE '%{$search}%'";
        
    }else{ $where = ''; }
    
    //获取数据
    $region = new regions($where,array('order'=>'createTime DESC','limit'=>$limit));
    $regions  = $region->get(array('id','region','name','authority','directory','status','createTime'));
    
    //准备显示的内容
    $tbody = '';
    for($i=0;$i<$region->iTotal();$i++)
    {
        $tbody .= '<tr><td region="id">' . $regions['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td region="region" class="editable">' . $regionSets[$regions['region'][$i]] . '</td>';
        $tbody .= '<td region="name" class="editable">' . $regions['name'][$i] . '</td>';
        $tbody .= '<td region="authority" class="editable">' . $regions['authority'][$i] . '</td>';
        $tbody .= '<td region="directory" class="editable">' . $regions['directory'][$i] . '</td>';
        $tbody .= '<td region="status" class="editable">' . $statusSets[$regions['status'][$i]] . '</td>';
        $tbody .= '<td>' . $regions['createTime'][$i] . '</td></tr>';   
    }
    
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],array('import','export'));
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    
    if($region->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;        
    }else{ $back['status'] = 2;}
    points::jan($back);
