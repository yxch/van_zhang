<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    
    $set = array('status'=>0,'tip'=>'');
    
    $murls = points::SURL($_POST['murl'],true);
    if(!$murls['status']){ $set['tip'] = '提供了不正确的管理URL'; points::jan($set); }    
    
    $var = new vars(array('position'=>$murls['md5']));
    if($var->iTotal() > 0)
    {
        $set['tip'] = '此管理URL似乎被初始化过,请转到变量管理页面处理'; points::jan($set);
    }else
    {
        //保存可初始化的变量
        $pst = array();        
        foreach($_POST as $k=>$v){  if(!empty($v) && $k != 'murl'){ $pst[$k] = $v; }  }        
        if(count($pst) == 0) //初始化此类别的变量的空值没有意义 初始化失败
        {
            $set['tip'] = '没有为此类别提供任何可初始化的变量,初始化失败';
            points::jan($set);
            
        }else //初始化变量
        {
            //当前用户是否有新增条目的权限以防止恶意写入
            $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
            if(!points::allowed($authority,'add')){ $set['tip'] = '用户权限请求'; points::jan($set); }
            
            //校验一些值 开始时间 结束时间 变量版本 分页大小
            if(isset($pst['stime']) && !STR::timed($pst['stime'])){$set['tip'] = '标准时间变量一[stime]错误'; points::jan($set);}
            if(isset($pst['etime']) && !STR::timed($pst['etime'])){$set['tip'] = '标准时间变量二[etime]错误'; points::jan($set);}
            if(isset($pst['serial']))
            {
                $len = strlen($pst['serial']); 
                for($i=0;$i<$len;$i++){ if(!ctype_digit($pst['serial'][$i])){ $set['tip'] = '标准类别序列号只能是数字'; points::jan($set); } }
                if($len > 15){ $set['tip'] = '版本值的最大长度为15'; points::jan($set); }
            }
            if(isset($pst['psize']) && !ctype_digit($pst['psize'])){ $set['tip'] = '用户数据分页值只能是数字'; points::jan($set); }
            if(isset($pst['cached']) && !ctype_digit($pst['cached'])){ $set['tip'] = '缓存有效时间值只能是数字'; points::jan($set); }
            if(isset($pst['shortid']))
            {
                for($j=0,$len=strlen($pst['shortid']);$j<$len;$j++)
                {
                    if(!ctype_alnum($pst['shortid'][$j]))
                    {
                        $set['tip'] = '类别变量短标识符只能是数字或者字母'; points::jan($set);
                    }
                }
                if(strlen($pst['shortid']) > 8){ $set['tip'] = '类别变量短标识符的长度不能大于8个字符'; points::jan($set); }
            }
            
            if(isset($pst['ssign'])){ } /*待补充验证规则*/
            if(isset($pst['esign'])){ } /*待补充验证规则*/
            
            if(isset($pst['limited']))
            {
               if(strpos($pst['limited'],'-') !== false)
               {
                    $exp = explode('-',$pst['limited']);
                    if(count($exp) != 2){ $set['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($set); }
                    if(!ctype_digit($exp[0]) || !ctype_digit($exp[1]) || $exp[0] >= $exp[1]){ $set['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($set); }
                
               }else{ $set['tip'] = '类别范围变量值不合规范,格式如0-100'; points::jan($set); }
            }
            if(isset($pst['auxiliary']) && (!ctype_digit($pst['auxiliary'])|| $pst['auxiliary'] > 9)){ $set['tip'] = '附加信息标识符只能是一个数字'; points::jan($set); }
            
            //变量描述映射集
            $desc = array('stime'=>'标准时间变量一',  'etime'=>'标准时间变量二',
                          'serial'=>'标准系统序列号', 'psize'=>'用户数据分页值',
                          'cached'=>'缓存有效时间值', 'shortid'=>'类别变量短标识',
                          'limited'=>'类别范围变量值','auxiliary'=>'附加信息标识符',
                          'ssign'=>'启用起始标识符',  'esign'=>'启用终止标识符');
            
            $rules = array('stime'=>'datetime','etime'=>'datetime',
                           'serial'=>'digit','psize'=>'digit',
                           'cached'=>'digit','shortid'=>'text',
                           'limited'=>'limit','auxiliary'=>'digit',
                           'ssign'=>'text','esign'=>'text'      );
            
            $i = 0; $inserts = array();
            foreach($pst as $k=>$v)
            {
                $inserts[$i]['name'] = $k;
                $inserts[$i]['value'] = $v;
                $inserts[$i]['position'] = $murls['md5'];
                $inserts[$i]['url'] = $murls['url'];
                $inserts[$i]['note'] = $desc[$k];
                $inserts[$i]['text'] = '';
                $inserts[$i]['status'] = '2';
                $inserts[$i]['rule'] = $rules[$k];
                $inserts[$i]['isUserControl'] = 0;
                $i++;
            }
            $var = new vars();
            if($var->set($inserts))
            {
                $set['status'] = 1; $set['tip'] = '初始化变量成功';                
            }else{ $set['tip'] = '初始化变量失败，请检查提供的值'; }
            points::jan($set);
        }
    }
