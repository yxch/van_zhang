<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    
    $set = array('status'=>0,'err'=>'');
    $murls = points::SURL($_POST['murl'],true); //echo $murls['url'];
    //用户输入校验
    if(!$murls['status']){ $set['err'] = '无效的管理URL,请检查输入！'; points::jan($set); }
    if(!ctype_digit($_POST['pos'])){ $set['err'] = '位置不是一个有效的值.';points::jan($set); }
    if(!ctype_digit($_POST['regions'])){ $set['err'] = '区域不是一个有效的值.';points::jan($set); }
    if(!ctype_digit($_POST['status']) || !in_array($_POST['status'],array('0','1','2')))
    {
        $set['err'] = '类别的状态不是一个有效的值.';
        points::jan($set);
    }
    $titleLen = mb_strlen($_POST['title'],'UTF-8'); //SQL注入检查 TODO
    if(STR::hasRisk($_POST['title']) || $titleLen > 32 ){ $set['err'] = '不能接受的标题,存在敏感字符或者长度超过32个字符'; points::jan($set);}
    //访问URL
    if(empty($_POST['dir'])){ $set['err'] = '用户异常提交，没有指定相关的区域范围目录'; points::jan($set); }
    if(empty($_POST['aurl'])){ $set['err'] = '必须指定此类别的访问文件'; points::jan($set);}
    
    //准备表数据
    $tables = array('managingURL'=>$murls['url'],    'MD5'=>$murls['md5'],
                    'title'=>$_POST['title'],        'regionId'=>$_POST['regions'],
                    'accessedURL' => $_POST['dir'] . $_POST['aurl'],
                    'position'=>$_POST['pos'],
                    'status'=>$_POST['status']);
    
    if(!empty($_POST['id'])) //编辑一个类别
    {
        if(!ctype_digit($_POST['id'])){ $set['err'] = '非法的修改id'; points::jan($set);}
        //当前用户是否有修改条目的权限以防止恶意写入
        $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
        if(!points::allowed($authority,'edit')){ $set['err'] = '用户权限请求'; points::jan($set); }
        
        //编辑id的内容
        $md5 = $murls['md5']; $regionId = $_POST['regions']; $status = $_POST['status'];
        $where = 'id !=' . $_POST['id'] . " AND MD5 = '{$md5}' AND regionId = $regionId AND status = '{$status}'";
        $category = new category($where);
        if($category->iTotal() > 0){ $set['err'] = '在此区域范围的当前状态下存在指定的管理URL。';  points::jan($set);}
        
        $category = new category(array('id'=>$_POST['id']));
        $tables['modifiedTime'] = date('Y-m-d H:i:s');
        if($category->set($tables)){  $set['status'] = 1; $set['err'] = '更新类别成功';            
        }else{ $set['err'] = '更新类别失败';}
        points::jan($set);
        
    }else //增加一个类别
    {
        //当前用户是否有新增条目的权限以防止恶意写入
        $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
        if(!points::allowed($authority,'add')){ $set['err'] = '用户权限请求'; points::jan($set); }
        
        $category = new category(array('MD5'=>$murls['md5'],'regionId'=>$_POST['regions'],'status'=>$_POST['status']));
        if($category->iTotal() > 0){ $set['err'] = '在此区域范围的当前状态下存在指定的管理URL。';  points::jan($set);  }
        
        $category = new category();
        if($category->set($tables))
        {
            $set['status'] = 1;
            $set['err'] = '保存类别成功';                
        }else{ $set['err'] = '保存类别失败';}
        points::jan($set);
    }
