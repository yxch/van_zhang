<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];    
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'size'=>15,
                  'total'=>0,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $category = new category();
    $back['total'] = $category->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //获取数据
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
        $where = "title LIKE '%{$search}%' OR managingURL LIKE '%{$search}%' OR accessedURL LIKE '%{$search}%'";
        
    }else{ $where = ''; }
    
    $category = new category($where,array('order'=>'createTime DESC','limit'=>$limit));
    $categories  = $category->get(array('id','title','regionId','managingURL','accessedURL','position','status','createTime'));
    
    //准备显示的内容
    $tbody = '';
    for($i=0;$i<$category->iTotal();$i++)
    {
        $tbody .= '<tr><td class="width6">' . $categories['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td class="hidden" title="' . $categories['title'][$i] . '">' . $categories['title'][$i] . '</td>';
        $tbody .= '<td>' . $categories['regionId'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $categories['managingURL'][$i] . '">' . $categories['managingURL'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $categories['accessedURL'][$i] . '">' . $categories['accessedURL'][$i] . '</td>';
        $tbody .= '<td>' . $categories['position'][$i] . '</td>';
        $tbody .= '<td>' . $categories['status'][$i] . '</td>';
        $tbody .= '<td class="hidden">' . $categories['createTime'][$i] . '</td></tr>';   
    }
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],array('apply','import','export'));
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    if($category->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;
    }else{ $back['status'] = 2; }
    points::jan($back);
