<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $vars = new vars();
    $back['total'] = $vars->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //获取数据 搜索功能
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
        $where = "name LIKE '%{$search}%' OR note LIKE '%{$search}%'";
        
    }else{ $where = ''; }
    
    //获取数据
    $vars = new vars($where,array('order'=>'createTime DESC','limit'=>$limit));
    $varses  = $vars->get(array('id','name','value','url','note','text','status','createTime'));
    
    //准备显示的内容
    $tbody = '';
    for($i=0;$i<$vars->iTotal();$i++)
    {
        $tbody .= '<tr><td>' . $varses['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td>' . $varses['name'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $varses['value'][$i] . '">' . $varses['value'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $varses['url'][$i] . '">'. $varses['url'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $varses['note'][$i] . '">' . $varses['note'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $varses['text'][$i] . '">' . $varses['text'][$i] . '</td>';
        $tbody .= '<td>' . $varses['status'][$i] . '</td>';
        $tbody .= '<td class="hidden">' . $varses['createTime'][$i] . '</td></tr>';   
    }
    $exclusion = ($vars->iTotal()) > 0 ?  array('apply','import','export') : array('edit','delete','apply','import','export');
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],$exclusion);
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    
    if($vars->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;
    }else{ $back['status'] = 2; }
    points::jan($back);
