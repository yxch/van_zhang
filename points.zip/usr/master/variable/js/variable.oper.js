//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };

$(document).ready(function(){
    var vs = valued();
    //应用按钮事件
    $('#applied').click(function(){
        $('#err').text('');
        var v = valued();
        //用户是否已修改了某个值 
        var modifed = false
        for(var p in v){if(v[p] != vs[p]){modifed = true; break; }}
        if (!modifed) { $('#err').text('没有可用于提交的内容,请检查是否有修改'); return false; }
        //校验输入
        var id = $('#id').text();
        if(!id.empty()){ v.id = id; } 
        $.post('ask/vars.oper.ajx.php',v,function(r){ console.log(r);
            var j = $.parseJSON(r);
            $('#err').text(j.tip);
            if(j.status == '1'){ vs = valued(); }
        });     
    });
    
    function valued()
    {
        return {"murl":$.trim($('#murl').val()),
                "status":$('#status').val(),
                "isuser":$('#isuser').val(),
                "note":$.trim($('#note').val()),
                "name":$.trim($('#named').val()),
                "value":$.trim($('#val').val()),
                "rule":$('#rules').val(),
                "type":$('#type').val(),
                "text":$.trim($('#txt').val())        };
    }

});