$(document).ready(function(){
    var page = 1;//默认显示第一页
    var ask = 'ask/banker.ajx.php';
    var filter = $('#filters').val();
    tbl(ask,{"page":page,"filter":filter});
    
    //初始化弹窗的大小和遮罩层的大小
    f.pop();
    $(window).resize(function(){  f.pop();  f.overlay(); });
    
    //用户改变filter
    document.getElementById('filters').onchange = function(){
        filter = this.value;
        tbl(ask,{"page":page,"filter":filter});
    }
    
    //导出按钮单击事件
    $('#grid tfoot').delegate('#export','click',function(){        
        f.overlay().fadeIn();
        $('#pop').show();
    });
    
    //export 的单击事件
    $(".export").click(function(){
        var exports = document.getElementsByName('export');
        for(var i=0;i<exports.length;i++)
        {
            if (exports[i].checked)
            {
                if (exports[i].value == '0')
                {
                    $('#stime').attr('disabled',false);
                    $('#etime').attr('disabled',false);
                }else
                {
                    $('#stime').attr('disabled','disabled');
                    $('#stime').val('');
                    $('#etime').attr('disabled','disabled');
                    $('#etime').val('');                      
                }
                if (exports[i].value == '1')
                {
                    $('#rows').attr('disabled',false);
                }else
                {
                    $('#rows').attr('disabled','disabled');
                    $('#rows').val('');
                }
            }
        }
        $('#tip').text('');
    });
    
    $('#stime,#etime').focus(function(){ if($(this).val().empty()){$(this).val(f.dateTime('date') + ' 23:59:59');} });
    
    function tbl(url,json)
    {
        $.post(url,json,function(r){                   /* console.log(r);*/
            var j = $.parseJSON(r);
            var yes = parseInt(j.yes);
            if (yes == 1)
            {
                $('#grid').show();  $('#none').hide();                
               
                page = j.page; //当前面
                $('#grid thead').html(j.thead);
                $('#grid tbody').html(j.tbody);
                $('#grid tfoot').html(j.tfoot);
                j.pageCurrentClass = 'underline';
                $('#grid tfoot #fpage').html(paging(j).full());
                
                //分页事件 首页 下一页 每一页 上一页 末页
                $('#fpage').delegate('#first,#last,.page,#next,#end','click',function(){ 
                    var num = $(this).attr('name');
                    $('#pager #fpage #goto').val(num);
                    tbl(ask,{"page":num,"filter":filter});
                });
                $('#fpage').delegate('#goto','keyup',function(e){
                    var num = parseInt($(this).val());
                    if(e.which == 13){ if(!isNaN(num)){ tbl(ask,{"page":num,"filter":filter}); }  }
                });
             
            }else{ $('#grid').hide();  $('#none').show(); }
        });
    }
    
    //弹窗的确定按钮
    $('#ensure').click(function(){
        $('#tip').text('');
        var exports = document.getElementsByName('export'); 
        var v = 0;
        for(var i=0;i<exports.length;i++){ if(exports[i].checked){ v = exports[i].value; }}
        var param = '';
        if (v == 0)
        {
            var stime = $.trim($('#stime').val());
            if (stime.empty()) { $('#tip').text('开始时间不能为空');return false; }
            var etime = $.trim($('#etime').val());
            if (etime.empty()) { $('#tip').text('结束时间不能为空');return false; }
            param = '?f=' + filter + '&t=0' + '&stime=' + stime + '&etime=' + etime;
        }
        if (v == 1)
        {
            var rows = $.trim($('#rows').val());
            if (rows.empty()) { $('#tip').text('必须指定一个大于0的数字');return false; }
            var iRows = parseInt(rows);
            if (iRows <= 0) { $('#tip').text('必须指定一个大于0的数字');return false; }
            param = '?f=' + filter + '&t=1' + '&n=' + rows;
        }
        if (v == 2){  param = '?f=' + filter + '&t=2'; }
        if (v == 3){  param = '?f=' + filter + '&t=3' + '&p=' + page; }
        
        window.location.href = 'http://' + window.location.host + '/points/usr/servant/banker/ask/exported.ajx.php' + param;
    });

});