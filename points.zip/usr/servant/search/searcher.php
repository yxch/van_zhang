<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $categoryId = $_SESSION['points']['item']['id'];
    $auth = $_SESSION['points']['category'][$categoryId]['authority'];
 
    $categories = array_keys($_SESSION['points']['filters']);
    if(!in_array($_POST['filter'],$categories)){ exit('supplied an invalid category id.'); }
    
    //用户提供搜索选项值
    if(!STR::fine($_POST['searcher']) || STR::hasRisk($_POST['searcher'])){ exit('supplied an empty or invalid search value'); }
    
    $oper = array('1'=>'=','2'=>'LIKE','3'=>'>','4'=>'<','5'=>'>=','6'=>'<=','7'=>'!=');
    if(!isset($oper[$_POST['type']])){ exit('supplied an invalid operation.'); }
    
    $fields = points::parseField($_SESSION['points']['filters'][$_POST['filter']]['fields']);
    if(empty($fields['field'])){ exit('supplied empty query field.'); }
    
    $fieldArr = $fields['field']; //字段
    $translators = $fields['translator']; //翻译设定
    $recorder = array_search('recorder',$fields['flag']); //记录创建时间
    
    $selected = array();  $titles = array();
    for($j=0,$l=count($_POST['fields']);$j<$l;$j++)
    {
        if(isset($fieldArr[$_POST['fields'][$j]]))
        {
            $titles[] = $fieldArr[$_POST['fields'][$j]];
            $selected[] = $_POST['fields'][$j];
        }else{ exit('supplied an invalid field.'); }
    }
    //查询选项字段是否在已提供的查询字段中
    if(!isset($fieldArr[$_POST['search']])){ exit('supplied an invalid search option.');}
    //显示搜索条件和结果
    $searchCondition =  $fieldArr[$_POST['search']] . ' ' . $oper[$_POST['type']] . $_POST['searcher'];
    $where = $_POST['search'] . ' ' . $oper[$_POST['type']] . ' "' . $_POST['searcher'] . '"';
    if($_POST['type'] == '2') //模糊匹配
    {
        $searchCondition = $fieldArr[$_POST['search']] . ' ' . $oper[$_POST['type']] . ' %' . $_POST['searcher'] . '%';
        $where = $_POST['search'] . ' ' . $oper[$_POST['type']] . ' %' . $_POST['searcher'] . '%';
    }   
    
    //SQL
    $filter = new filter(array('id'=>$_POST['filter']));
    $filters = $filter->get(array('select','factor','rest'));
    $SQL = '';
    if(stripos($filters['select'][0],'select') === false)
    {
        $SQL .= 'SELECT ' . implode(',',$selected) . ' ' . $filters['select'][0];
    }else{ $SQL .= $filters['select'][0]; }
    
    if(empty($filters['factor'][0]))
    {
        $SQL .= ' WHERE ' . $where . ' '; 
    }else{ $SQL .= $filters['factor'][0] . ' AND ' . $where . ' '; }
    $SQL .= $filters['rest'][0];
    
    $pageSize = 15; //计算分页
    //获取设定条件的记录总数
    $tableName = '';
    if($fields['tb'] == 'none')
    {
        $selects = explode(' ',$filters['select'][0]);
        $fromPosition = -1; //from关键字的位置 得到表名
        for($i=0,$l=count($selects);$i<$l;$i++){  if(strtolower($selects[$i]) == 'from'){ $fromPosition = $i; break;}  }
        $tableName = $selects[$fromPosition + 1];
        if(empty($tableName)){ exit('table invalid,please check!'); }
    
    }else{ $tableName = $fields['tb']; }
    
    $_count = DBC::execute('SELECT count(*) AS total FROM ' . $tableName . ' WHERE ' . $where); 
    $count = $_count[0]['total'] ? $_count[0]['total'] : 0; //总记录数
    $pages = ceil($count / $pageSize);  //总页数
    $limit = ' LIMIT ' . $pageSize . ' OFFSET 0';    
    
    $fpage = points::fpage($pages,1,$pageSize); //输出的分页
    
    $result = DBC::execute($SQL . $limit);
    $length = count($result);
    
    $_SESSION['points']['searcher']['SQL'] = $SQL;
    $_SESSION['points']['searcher']['translators'] = $translators;
    $_SESSION['points']['searcher']['filter'] = $_POST['filter'];
    $_SESSION['points']['searcher']['fields'] = $selected;
    $_SESSION['points']['searcher']['titles'] = $titles;
    $_SESSION['points']['searcher']['where'] = $where;
    $_SESSION['points']['searcher']['psize'] = $pageSize; 
    $_SESSION['points']['searcher']['pages'] = $pages;
    $_SESSION['points']['searcher']['recorder'] = $recorder;
?>
<!DOCTYPE html>
<html>
    <head>
        <?php echo points::head(0); ?>
        <link rel="stylesheet" href="css/searcher.css" />
        <script src="/points/usr/local/js/f.js"></script>
        <script src="js/searcher.js"></script>
    </head>
    <body>
        <input type="hidden" id="pages" value="<?php echo $pages; ?>" />
        <div id="outset">
            <div id="topic"><h1><?php echo $_SESSION['points']['search']['title']; ?></h1></div>
            <div id="desc"><a href="search.php?cid=<?php echo $categoryId; ?>">返回</a><label>提供的搜索条件:</label><span><?php echo $searchCondition; ?></span><label>共搜索到<?php echo $count; ?>个结果。</label></div>
            <table id="grid">
                <thead>
                    <tr>
                    <?php for($k=0,$l=count($titles);$k<$l;$k++){ ?>
                        <td class="hidden" title="<?php echo $titles[$k]; ?>"><?php echo $titles[$k]; ?></td>
                    <?php } ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if($length > 0){ ?>
                        <?php for($k=0;$k<$length;$k++){ ?>
                        <tr>
                            <?php foreach($result[$k] as $fieldName=>$v){ $val = points::translator($fieldName,$v,$translators);?>
                                <td class="hidden" title="<?php echo $val; ?>"><?php echo $val; ?></td>
                            <?php } ?>
                        <?php } ?>
                        </tr>
                    <?php }else{ ?>
                        <tr id="loading"><td colspan="<?php echo count($titles); ?>">没有可用数据，请修改搜索条件！</td></tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <?php if($length > 0){ ?>
                    <tr>
                        <td colspan="<?php echo count($titles); ?>">
                            <span id="oper"><?php echo points::authorized($auth,array('edit','delete','add','import')); ?></span><span id="fpage"><?php echo $fpage; ?></span>
                        </td>
                    </tr>
                    <?php } ?>
                </tfoot>
            </table>
        </div>
        <div id="pop">
            <div id="close"><a id="closed"><img title="关闭" src="/points/usr/local/images/close.png" /></a></div>
            <div class="pop">
                <div id="banker">
                    <p><label><input class="export" type="radio" name="export" value="0" />导出　从 </label><input id="stime" value="" /> </p>
                    <p>　　　　到 <input id="etime" value="" /></p>
                    <p><label><input class="export" type="radio" name="export" value="1" />导出最新 </label><input id="rows" value="" /></p>
                    <p><label><input class="export" type="radio" name="export" value="2" />导出全部(不推荐)</label></p>
                    <p><label><input class="export" type="radio" name="export" value="3" />导出当前页</label></p>
                    <p id="tip"></p>
                </div>                
            </div>
            <div id="oper"><a id="ensure">确定</a></div>
        </div>
        <div id="overlay"></div>
    </body>
</html>
