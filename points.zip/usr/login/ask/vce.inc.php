<?php
  require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
  $_vc = new VCE(array('width'=>168));		
  $_vc->showVCE();
  $_SESSION['points']['VCE'] = $_vc->getCodes();