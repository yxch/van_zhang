<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/points/loader.inc.php';
    $back = array('status'=>0,'message'=>'','url'=>''); //响应的结果集
    
    //验证码是否正确
    if(strtolower($_POST['valide']) != $_SESSION['points']['VCE'])
    {
        $back['message'] = '检查验证码,输入的验证码可能有误';
        points::jan($back);
    }
  
    //检查区域id
    if(!ctype_digit($_POST['region']))
    {
        $back['message'] = '异常访问，区域ID不正确';
        points::jan($back);
    }
    $relations = array('1'=>'用户数据','2'=>'控制台','3'=>'定制');
    
    //缓存region
    $_SESSION['points']['region'] = array();
    $_SESSION['points']['region']['id'] = $_POST['region'];
    $_SESSION['points']['region']['name'] = $relations[$_POST['region']];
    
    //检查范围id
    if(!ctype_digit($_POST['subrange']))
    {
        $back['message'] = '异常访问，子区域ID不正确';
        points::jan($back);
    }
    if($_POST['subrange'] != '0') //超级用户的初始化操作被排除在外
    {
        $region = new regions(array('id'=>$_POST['subrange'],'status'=>1));
        $regions = $region->get(array('name','directory'));
        if($region->iTotal() == 0)
        {
            $back['message'] = '区域不可用，可能被管理员废弃。';
            points::jan($back);
        }
        
        //缓存子区域信息
        $_SESSION['points']['subrange'] = array();
        $_SESSION['points']['subrange']['name'] = $regions['name'][0];
        $_SESSION['points']['subrange']['directory'] = $regions['directory'][0];
    }
    
    $username = trim($_POST['username']); 
    if(empty($username)){ $back['message'] = '用户名不能为空'; points::jan($back); }
    
    $password = trim($_POST['password']);
    if(empty($password)){ $back['message'] = '密码不能为空'; points::jan($back); }
    $password = md5($password);
    
    //是否存在此用户
    $user = new users(array('username'=>$username));
    $users = $user->get(array('id','alias','password','type','status'));    
    $_SESSION['points']['user'] = array(); //缓存用户信息
    
    if($user->iTotal() == 1) //用户存在
    {
        if($users['type'][0] == 1){ $back['message'] = '不允许此类用户在此处登录'; points::jan($back); }
        if($users['status'][0] != '1'){ $back['message'] = '用户已被锁定'; points::jan($back); }        
        if($password != $users['password'][0]){$back['message'] = '不正确的用户名或者密码'; points::jan($back); }
        
        $_SESSION['points']['user']['username'] = $username;
        $_SESSION['points']['user']['id'] = $users['id'][0];
        $_SESSION['points']['user']['alias'] = $users['alias'][0];
        $_SESSION['points']['user']['type'] = $users['type'][0];
        
        //查找所有此子区域的类别条目
        $category = new category('regionId = ' . $_POST['subrange'] . ' AND status > 0');
        $categories = $category->get(array('id','title','MD5','accessedURL'));
        if($category->iTotal() == 0)
        {
            $back['message'] = '在此区域下没有可访问的条目';
            points::jan($back);
        }
        
        $_arr = array();
        for($k=0;$k<$category->iTotal();$k++)
        {
            $_arr[$categories['id'][$k]]['title'] = $categories['title'][$k];
            $_arr[$categories['id'][$k]]['aurl'] = $categories['accessedURL'][$k];
            $_arr[$categories['id'][$k]]['MD5'] = $categories['MD5'][$k];
        }
        
        //缓存类别的一些信息
        $_SESSION['points']['category'] = array();
        
        if($users['type'][0] == 9) //超级用户
        {
            foreach($_arr as $k=>$v)
            {
                $_SESSION['points']['category'][$k]['title'] = $v['title'];
                $_SESSION['points']['category'][$k]['aurl'] = $v['aurl'];
                $_SESSION['points']['category'][$k]['MD5'] = $v['MD5'];
                $_SESSION['points']['category'][$k]['authority'] = MAXAUTH;
            }
            
        }else //不是超级用户
        {
            $uid = $users['id'][0];
            //从用户权限列表中查出所有此uid的访问条目
            $power = new power(array('userId'=>$uid,'status'=>1));
            $powers = $power->get(array('categoryId','authority'));
            
            //求$powers['categoryId'] 与 $categories['id']交集
            $intersect = array_intersect($powers['categoryId'],$categories['id']);  
            if(count(array_values($intersect)) == 0)
            {
                $back['message'] = '在此区域范围内此用户没有任何可访问的类别条目';
                points::jan($back);
            }
            
            $_auth = array();
            for($j=0;$j<$power->iTotal();$j++)
            {
                $_auth[$powers['categoryId'][$j]]['authority'] = $powers['authority'][$j];
            }
            
            foreach($intersect as $k=>$v)
            {
                $_SESSION['points']['category'][$v]['title'] = $_arr[$v]['title'];
                $_SESSION['points']['category'][$v]['aurl'] = $_arr[$v]['aurl'];
                $_SESSION['points']['category'][$v]['MD5'] = $_arr[$v]['MD5'];
                $_SESSION['points']['category'][$v]['authority'] = $_auth[$v]['authority'];
            }      
        }
        
        $back['status'] = 1;
        $back['url'] = PHOST . $_SESSION['points']['subrange']['directory'];
        $_SESSION['points']['VCE'] = '';
        points::jan($back);
        
    }else //如果用户不存在
    {
        //是否是内置初始化用户
        $pointers = parse_ini_file(SLIB . 'etc/pointer.ini',true);
        if($username != $pointers['username']){ $back['message'] = '不正确的用户名或者密码'; points::jan($back); }
        if($password != $pointers['password']){ $back['message'] = '不正确的用户名或者密码'; points::jan($back); }
        
        //查找所有有效类别条目
        $category = new category(' status > 0');
        if($category->iTotal() > 0)
        {
            $back['message'] = '系统异常,可能在上次初始时失败';
            points::jan($back);
        }
        
        $_SESSION['points']['user']['username'] = $pointers['username'];
        $_SESSION['points']['user']['id'] = 0;
        $_SESSION['points']['user']['alias'] = $pointers['alias'];
        $_SESSION['points']['user']['type'] = $pointers['type'];
        
        $back['status'] = 1;
        $back['url'] = PHOST . $pointers['directory'];
        points::jan($back);
    }
