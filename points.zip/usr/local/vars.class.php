<?php
class vars extends DBO
{
    protected $id;
    protected $name;
    protected $value;
    protected $position;
    protected $url;
    protected $note;
    protected $text;
    protected $status;
    protected $rule;
    protected $isUserControl;
    protected $type;
    protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_variables'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'named'=>'name',
                     'val'=>'value',
                     'pos'=>'position',
                     'url'=>'url',
                     'note'=>'note',
                     'txt'=>'text',
                     'yes'=>'status',
                     'rule'=>'rule',
                     'isuser'=>'isUserControl',
                     'tye'=>'type',
                     'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'     );
    }
}