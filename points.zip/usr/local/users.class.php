<?php
class users extends DBO
{
    protected $id;
    protected $username;
    protected $password;
    protected $alias;
    protected $email;
    protected $portrait;
    protected $type;
    protected $status;
    protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_users'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'usr'=>'username',
                     'pwd'=>'password',
                     'alias'=>'alias',
                     'email'=>'email',
                     'ppath'=>'portrait',
                     'tye'=>'type',
                     'yes'=>'status',
                     'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'    );
    }
}
