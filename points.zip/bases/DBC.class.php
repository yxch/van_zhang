<?php
class DBC
{
  private static $_instance = null;
  private static $_handle  = null;
  private static $prefix = '';
  private static $_dbKey1 = ''; //仅适用于招商信诺的数据库配置
  private static $_dbKey2 = ''; //仅适用于招商信诺的数据库配置
  
  private function __construct()
  {
    //包含drupal的settings.php 载入数据库配置
    require_once $_SERVER['DOCUMENT_ROOT'] . '/sites/default/settings.php';
    
    //重置在settings.php文件中设置的ini变量
    ini_set('session.gc_divisor',1000);
    ini_set('session.gc_maxlifetime',1440);
    ini_set('session.cookie_lifetime',0);    
    
    //MySQL连接参数
    $db = $databases[self::$_dbKey1][self::$_dbKey2];
    $host = $db['host'];
    $database = $db['database'];      
    $username = $db['username'];
    $password = $db['password'];    
    $driver =   $db['driver'];      
    self::$prefix = $db['prefix'];      
    $dsn = $driver . ':host=' . $host . ';dbname=' . $database . ';charset=utf8';
    
    try //尝试连接MySQL
    {
      self::$_handle = new PDO($dsn,$username,$password); 
      
    }catch(Exception $e){ exit($e->getMessage()); }  
  }
  
  /*
   *数据库连接的单一实例
   *@param string $key1 仅适用于招商信诺的数据库配置
   *@param string $key2 仅适用于招商信诺的数据库配置
   */
  public static function PDO($key1='',$key2='') 
  {
    if(!empty($key1) && !empty($key2))
    {
      self::$_dbKey1 = $key1; self::$_dbKey2 = $key2;
      
    }else{ self::$_dbKey1 = 'activity'; self::$_dbKey2 = 'default'; }
   
    if(!(self::$_instance instanceof self)){ self::$_instance = new self;}
    return self::$_handle;
  }
  
  //返回设定的表前缀
  public static function prefix()
  {
    if(!(self::$_instance instanceof self)){ self::$_instance = new self;}
    return self::$_prefix;
  }
  
  /*
   *执行一条查询 2015-12-07增加
   *@param string $sql 要执行的sql
   *@param array $arr 参数绑定数组
   *@param string $way 获取结果的方式，应为FETCH_LAZY，FETCH_ASSOC，FETCH_NAMED，FETCH_NUM ，FETCH_BOTH，FETCH_OBJ，FETCH_BOUND，FETCH_COLUMN，FETCH_CLASS
   *@param array $params 指定PDO的一些全局设置参数也就是PDO::setAttribute
   *@return array 返回结果数组
   */
  public static function execute($sql,array $arr=array(),$way=PDO::FETCH_ASSOC)
  {
    $dbc = self::PDO()->prepare($sql,array(PDO::ATTR_CURSOR=>PDO::CURSOR_FWDONLY));
    return $dbc->execute($arr) ? $dbc->fetchAll($way) : array();
  }
}
