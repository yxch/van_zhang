<?php
class VCE
{
  private $width = 120;   //宽度
  private $height = 32;   //高度
  private $fontsize = 18; //指定字体大小
  private $length = 4;    //验证码长度
  private $font='';       //指定的字体
  //随机因子
  private $charsets = 'abcdefghkmnprstuvwxyzABCDEFGHKMNPRSTUVWXYZ23456789';
  private $code;//验证码  
  private $img;//图形资源句柄
  private $type='png'; //生成的图片类型 如png gif jpg jpeg
  private $fontcolor;//指定字体颜色
  
  /*
   *$opt = array('width'=>130,'height'=>48,'fontsize'=>20,'length'=>4,'font'=>'elephant.ttf','charsets'=>'abcdef123456789ABCDEF');
   */
  public function __construct(array $opt=null)
  {
    if(isset($opt['width']) && $opt['width']){  $this->width = $opt['width'];}
    if(isset($opt['height']) && $opt['height']){ $this->height = $opt['height'];}
    if(isset($opt['fontsize']) && $opt['fontsize']){ $this->fontsize = $opt['fontsize'];}
    if(isset($opt['length']) && $opt['length']){ $this->length = $opt['length'];}
    if(isset($opt['font']) && $opt['font'] && file_exists( $_SERVER['DOCUMENT_ROOT'] . '/points/bases/fonts/' . $opt['font'] ) )
    {
      $this->font = $_SERVER['DOCUMENT_ROOT'] . '/points/plugins/Fonts/' . $opt['font'];
	  
    }else{ $this->font = $_SERVER['DOCUMENT_ROOT'] . '/points/plugins/Fonts/elephant.ttf';  }
    if(isset($opt['charsets']) && $opt['charsets']){ $this->charsets = $opt['charsets'];}
	//如果不提供字体文件，无法画出验证码
    if(empty($this->font)){   exit('载入字体文件件失败');  }
  }
  
  //创建画布
  private function canvas()
  {
    $this->img = imagecreatetruecolor($this->width, $this->height);
    $color = imagecolorallocate($this->img, mt_rand(157,255), mt_rand(157,255), mt_rand(157,255));
    imagefilledrectangle($this->img,0,$this->height,$this->width,0,$color);
  }
  
  //把生成的验证码写在图片资源上
  private function codes()
  {
    $_x = $this->width / $this->length;
    for ($i=0;$i<$this->length;$i++)
    {
     $this->fontcolor = imagecolorallocate($this->img,mt_rand(0,156),mt_rand(0,156),mt_rand(0,156));
     imagettftext($this->img,$this->fontsize,mt_rand(-30,30),$_x * $i + mt_rand(1,5),$this->height / 1.4,$this->fontcolor,$this->font,$this->code[$i]);
    }
  }
  
  //生成干扰元素 线条、雪花、孤线
  private function disturb()
  {
    //线条
    for ($i=0;$i<6;$i++)
    {
      $color = imagecolorallocate($this->img,mt_rand(0,156),mt_rand(0,156),mt_rand(0,156));
      imageline($this->img,mt_rand(0,$this->width),mt_rand(0,$this->height),mt_rand(0,$this->width),mt_rand(0,$this->height),$color);
    }
    //雪花
    for ($i=0;$i<100;$i++)
    {
      $color = imagecolorallocate($this->img,mt_rand(200,255),mt_rand(200,255),mt_rand(200,255));
      imagestring($this->img,mt_rand(1,5),mt_rand(0,$this->width),mt_rand(0,$this->height),'*',$color);
    }
    //孤线
    for($i=0;$i<3;$i++)
    {
      $color = imagecolorallocate($this->img,mt_rand(0,156),mt_rand(0,156),mt_rand(0,156));
      imagearc($this->img,mt_rand(1,$this->width),mt_rand(1,$this->height),mt_rand(1,$this->width),mt_rand(1,$this->height),0,0,$color);
    }
  }  
  //输出验证码图像
  public function showVCE()
  {
    //创建画面
    $this->canvas();
    //随机生成验证码
    $len = strlen($this->charsets) - 1;
    for ($i=0;$i<$this->length;$i++) {  $this->code .= $this->charsets[ mt_rand(0,$len) ]; }
    //生成干扰元素
    $this->disturb();
    //把生成的验证码写在图片上
    $this->codes();
    //输出图片
    header('Content-type:image/png');
    imagepng($this->img);
    imagedestroy($this->img);
  }  
  //获取验证码
  public function getCodes(){ return strtolower($this->code); }
}
