CREATE TABLE `tb_points_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `md5` char(32) DEFAULT NULL COMMENT '路径MD5值',
  `title` varchar(64) DEFAULT NULL COMMENT '类别中文标题',
  `rid` int(11) DEFAULT NULL COMMENT '区域id',
  `murl` varchar(254) DEFAULT NULL COMMENT '管理路径',
  `aurl` varchar(254) DEFAULT NULL COMMENT '访问路径',
  `pos` char(1) DEFAULT '1' COMMENT '隶属于1:前端页面显示2:后台管理页面',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`),
  KEY `yes` (`yes`),
  KEY `md5` (`md5`),
  KEY `rid` (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=715 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_filters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '过滤器名称',
  `cid` int(11) DEFAULT NULL COMMENT '所属类别id',
  `flds` text COMMENT '字段设定',
  `scher` varchar(254) DEFAULT NULL COMMENT '探索设定',
  `slt` text COMMENT 'SQL语句select部分',
  `factor` text COMMENT 'SQL语句where部分',
  `rst` text COMMENT 'SQL语句的其它部分',
  `flag` char(32) DEFAULT NULL COMMENT '显示字段唯一标识',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '是否废弃 1使用 0废弃',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `flag` (`flag`),
  KEY `yes` (`yes`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=1009 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_powers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `cid` int(11) DEFAULT NULL COMMENT '分类id',
  `ctle` varchar(128) DEFAULT NULL COMMENT '类别的标题',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '权限值',
  `yes` char(1) NOT NULL DEFAULT '1',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cid` (`cid`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_regions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '区域的中文显示名',
  `region` char(1) NOT NULL DEFAULT '1' COMMENT '1:用户数据2:控制台3:定制',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '区域的默认权限',
  `dir` varchar(254) DEFAULT NULL COMMENT '区域的默认目录',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '区域的默认状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '区域的创建时间',
  PRIMARY KEY (`id`),
  KEY `named` (`named`),
  KEY `dir` (`dir`),
  KEY `region` (`region`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=606 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_session` (
  `sid` char(32) NOT NULL,
  `mme` int(11) DEFAULT NULL COMMENT 'session的修改时间',
  `cip` char(15) DEFAULT NULL COMMENT '客户端的ipv4的地址',
  `txt` text COMMENT '用户写入session的自定义内容',
  `ctt` text COMMENT '其它的基于session id的内容(通常是json格式的)',
  `cme` int(11) DEFAULT NULL COMMENT '记录创建时间，访问时间',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '表主键 id',
  `usr` varchar(64) DEFAULT NULL COMMENT '用户名',
  `pwd` char(32) DEFAULT NULL COMMENT '密码',
  `alias` varchar(64) DEFAULT NULL COMMENT '中文别名',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱地址',
  `ppath` varchar(254) DEFAULT NULL COMMENT '头像路径',
  `tye` char(1) NOT NULL DEFAULT '1' COMMENT '作用范围: 1前端页面 2后台页面 3通用',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_usr` (`usr`),
  KEY `passwd` (`pwd`),
  KEY `yes` (`yes`),
  KEY `usr` (`usr`),
  KEY `tye` (`tye`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_points_variables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '变量名',
  `val` varchar(254) DEFAULT NULL COMMENT '变量值',
  `pos` char(32) DEFAULT NULL COMMENT '变量应用在',
  `url` varchar(254) DEFAULT NULL COMMENT '应用路径',
  `note` varchar(254) DEFAULT NULL COMMENT '变量的描述',
  `txt` text COMMENT '变量文本',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '状态 1:用户变量 2:系统变量 0:废弃',
  `rule` varchar(32) DEFAULT NULL COMMENT '校验规则',
  `isuser` char(1) NOT NULL DEFAULT '1' COMMENT '是否用户可控 0不可控 1可控',
  `tye` varchar(32) NOT NULL DEFAULT 'text' COMMENT 'input的显示类型',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`,`ctime`),
  KEY `pos` (`pos`),
  KEY `named` (`named`),
  KEY `yes` (`yes`),
  KEY `note` (`note`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

DELIMITER $$
/*!50003 CREATE DEFINER=`drupal_user`@`%` PROCEDURE `cmb_201601_promoter`(IN pin INT(11))
BEGIN
DECLARE i INT(11) DEFAULT 1;
DECLARE pid CHAR(28) DEFAULT 'ocZ-njqyUJQZIPaYAOLkgyA0BuEc';
DECLARE openid CHAR(28);
DECLARE nickname VARCHAR(64);
DECLARE named VARCHAR(64);
DECLARE sfz CHAR(18) DEFAULT '121221321212211123';
DECLARE idc CHAR(18);
DECLARE m CHAR(11) DEFAULT '13800000000';
DECLARE mobile CHAR(11);
WHILE i<pin DO
 SET openid = CONCAT(LEFT(pid,28-LENGTH(i)),i);
 SET nickname = CONCAT(LEFT(pid,4),i);
 SET named = CONCAT(LEFT(pid,6),'-',i);
 SET idc = CONCAT(LEFT(idc,18-LENGTH(i)),i);
 SET mobile = CONCAT(LEFT(m,11-LENGTH(i)),i);
 INSERT INTO tb_CMB201601_promoter(`openid`,`nickname`,`ffptime`,`chTime`,`stime`,`fullTime`,`lutime`,`mmtimes`,`named`,`idc`,`mobile`,`answers`,`sutime`)
 VALUES(openid,nickname,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,5,named,idc,mobile,pid,CURRENT_TIMESTAMP);
 SET i = i + 1;
 END WHILE;
 END */$$
DELIMITER ;

/* Procedure structure for procedure `TEST` */

/*!50003 DROP PROCEDURE IF EXISTS  `TEST` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`drupal_user`@`%` PROCEDURE `TEST`(in cnt int)
BEGIN
declare i int;
    set i=0;
    while i<=cnt do
    INSERT INTO `tb_cmbcc_active_promoter` (openid,full_name,ctime,photo,score_total,etime)
VALUES(CONCAT('oDXZ9jn',CONVERT(CAST(10000*RAND()AS SIGNED ),CHAR(10))),'erintest',1425357901,'',100,1430737291);
    set i=i+1;
    end while;

    END */$$
DELIMITER ;

/* Procedure structure for procedure `TEST1` */

/*!50003 DROP PROCEDURE IF EXISTS  `TEST1` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`drupal_user`@`%` PROCEDURE `TEST1`(in cnt int)
BEGIN
declare i int;
declare var varchar(50);
    set i=0;
    while i<=cnt do
    set var = CONCAT('oDXZ9jn',CHAR(ROUND((RAND())*25)+65),CHAR(ROUND((RAND())*25)+97),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10)),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10)));
    /*INSERT INTO `tb_cmbcc_active_promoter` (openid,full_name,ctime,photo,score_total,etime)
VALUES(var,'erintest',1425357901,'',100,1430737291);*/
   INSERT INTO `tb_cmbcc_active_friends` (userinfo_id,promoter_id,contribution_value,ctime)
VALUES(CONCAT('oDXZ9jn',CHAR(ROUND((RAND())*25)+65),CHAR(ROUND((RAND())*25)+97),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10)),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10))),var,CAST(100*RAND()AS SIGNED) ,1430737291);
    set i=i+1;
    end while;


    END */$$
DELIMITER ;

/* Procedure structure for procedure `TEST_CGB` */

/*!50003 DROP PROCEDURE IF EXISTS  `TEST_CGB` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`drupal_user`@`%` PROCEDURE `TEST_CGB`(in temp int)
BEGIN

    declare var varchar(50);
    declare mb varchar(11);
    declare i int;

    set i=0;
    while i<temp do
    set var = CONCAT('oDXZ9jn',CHAR(ROUND((RAND())*25)+65),CHAR(ROUND((RAND())*25)+97),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10)),CONVERT(CAST(1000000*RAND()AS SIGNED ),CHAR(10)));
    set mb = CONCAT('138',CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),
    CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),CONVERT(CAST(10*RAND()AS SIGNED),CHAR(1)),'52');

    insert into `tb_cgb_bases` (openid,nickname,coverage,mobile,etime,underwrited,address,ctime) values
    (var,'erintest',0,mb,NULL,CAST(10*RAND()AS SIGNED),'广东省-广州市',1430897566);

    insert into `tb_cgb_reward` (openid,mobile,rewarded,award,`week`,ctime) values
    (var,mb,CAST(4*RAND()AS SIGNED),NULL,19,1430897566);


    set i=i+1;
    end while;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `TEST_TEST` */

/*!50003 DROP PROCEDURE IF EXISTS  `TEST_TEST` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`drupal_user`@`%` PROCEDURE `TEST_TEST`()
BEGIN
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
