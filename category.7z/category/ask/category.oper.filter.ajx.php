<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    
    $back = array('yes'=>0,'tip'=>''); //响应请求的结果
    
    $inserts = array();
    if(isset($_POST['id']) && ctype_digit($_POST['id'])) //编辑操作
    {
       if(!in_array($_POST['status'],array('1','0'))){ $back['tip'] = '状态值异常'; points::jan($back); }
       if(!ctype_digit($_POST['categoryId'])){ $back['tip'] = '类别id异常'; points::jan($back); }
       
       $category = new category(array('id'=>$_POST['categoryId']));
       if($category->iTotal() > 0)
       {
            $inserts['categoryId'] = $_POST['categoryId'];
            $inserts['status'] = $_POST['status'];
        
       }else{ $back['tip'] = '未找到此类别信息'; points::jan($back); }
       
    }else //新增即在类别管理界面下初始化过滤器
    {
        //校验  murl
        if(empty($_POST['murl'])){ $back['tip'] = '没有提供管理URL,系统无法处理'; points::jan($back); }
        $murls = points::SURL($_POST['murl']);
        if($murls['status'] == 0)
        {
            $back['tip'] = '提供的管理URL可能不正确或者不符合规范';
            points::jan($back);
        }
        if(!isset($_POST['region']) || !ctype_digit($_POST['region']))
        {
            $back['tip'] = '提供区域及子区域的ID是非法的或者无效';
            points::jan($back);
        }
        //查找是否存在此URL的类别记录
        $category = new category(array('MD5'=>$murls['md5'],'regionId'=>$_POST['region']));
        if($category->iTotal() == 0)
        {
            $back['tip'] = '初始化用户数据过滤器之前必须初始此类别';
            points::jan($back);
        }
        $categories = $category->get(array('id'));
        $inserts['categoryId'] = $categories['id'][0];
    }
    
    //名称
    if(empty($_POST['title'])){ $back['tip'] = '没有提供过滤器的名称'; points::jan($back); }
    $inserts['name'] = $_POST['title'];
    if(STR::hasRisk($_POST['title']) || mb_strlen($_POST['title']) > 32)
    {
        $back['tip'] = '过滤器的名称不可用，存在敏感字符或者长度超过了32个字符';
        points::jan($back);
    }
    
    //字段 id|||,openid|openid||,nickname|用户昵称|fun:urldecode($v)|,
    //     ffptime|首次玩好友牌局的时间||,
    //     sutime|提交表单时间||,
    //     ctime|记录创建时间||recorder,
    //     tb:tb_CMB201601_promoter" 最后的字段内容为表名称
    
    if(STR::hasRisk($_POST['fields']))
    {
        $back['tip'] = '过滤器的字段选项可能存在安全风险';
        points::jan($back);
    }
    
    $fields = explode(',',$_POST['fields']);
    $arr = array();
    
    for($i=0,$len=count($fields);$i<$len;$i++)
    {
        $rows = explode('|',$fields[$i]);        
        if(empty($rows[0]) || empty($rows[1])){ $back['tip'] = '必须指定数据表字段和显示名称'; points::jan($back); }
    }
    $tableName = (empty($_POST['tname'])) ? 'none' : trim($_POST['tname']);
    $inserts['fieldText'] = $tableName . '=' . $_POST['fields']; 
    $inserts['flag'] = $fmd5 = md5($inserts['fieldText']);   
    
    //搜索选项
    if(STR::hasRisk($_POST['searcher'])){ $back['tip'] = '过滤器的搜索选项存在安全风险'; points::jan($back); }
    if(!empty($_POST['searcher'])){ $inserts['searcher'] = $_POST['searcher']; }
    
    //SQL语句
    if(empty($_POST['select'])){ $back['tip'] = '没有提供过滤器的SQL'; points::jan($back); }
    if(STR::hasRisk($_POST['select'])){ $back['tip'] = '过滤器的SELECT部分存在安全风险'; points::jan($back); }
    if(!empty($_POST['factor']) && STR::hasRisk($_POST['factor']))
    {
        $back['tip'] = '过滤器的factor部分存在安全风险';
        points::jan($back);
    }
    if(!empty($_POST['rest']) && STR::hasRisk($_POST['rest']))
    {
        $back['tip'] = '过滤器的其余部分存在安全风险';
        points::jan($back);
    }
    $inserts['select'] = $_POST['select']; 
    $inserts['factor'] = $_POST['factor']; 
    $inserts['rest'] = $_POST['rest']; 
 
    if(isset($_POST['id']) && ctype_digit($_POST['id'])) //编辑操作
    {
        //当前用户是否有修改条目的权限以防止恶意写入        
        if(!points::allowed($authority,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
        
        $where = "id !=" . $_POST['id'] . " AND flag = '{$fmd5}' AND categoryId = " .  $inserts['categoryId'];
        $filter = new filter($where);
        if($filter->iTotal() > 0)
        {
            $back['tip'] = '存在相同的数据过滤器'; points::jan($back);
        }else
        {
            $inserts['modifiedTime'] = date('Y-m-d H:i:s');
            $filter = new filter(array('id'=>$_POST['id']));
            if($filter->set($inserts))
            {
                $back['yes'] = 1;
                $back['tip'] = '修改成功';
            }else{ $back['tip'] = '修改失败'; }
        }
    }else
    {
        //当前用户是否有新增条目的权限以防止恶意写入
        if(!points::allowed($authority,'add')){ $back['tip'] = '用户权限请求'; points::jan($back); }
        
        //是否存在相同的过滤器
        $filter = new filter(array('flag'=>$fmd5,'categoryId'=>$inserts['categoryId']));
        if($filter->iTotal() > 0){ $back['tip'] = '在此URL下可能存在相同的用户数据过滤器'; points::jan($back); }
        $filter = new filter(); 
        if($filter->set($inserts))
        {
            $back['yes'] = 1; $back['tip'] = '保存成功';
        }else{ $back['tip'] = '保存失败'; }
    }
    points::jan($back);
