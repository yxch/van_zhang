//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };
String.prototype.doubled = function(){ var i = parseInt(this); return i < 10 ? '0' + i : i; };

$(document).ready(function(){
    
    //初始化默认显示的访问URL路径
    $('#dir').text($('#regions').find("option:selected").attr('dir'));
    
    var select = document.getElementById('regions');
    select.onchange = function()
    {
        $('#dir').text($(this).find('option:selected').attr('dir'));
    }
    //初始值
    var vs = values();
    
    //获取category的初始值
    function values()
    {
        return {"murl":$('#murl').val(),
                "pos":$('#pos').val(),
                "title":$('#title').val(),
                "regions":$('#regions').val(),
                "status":$('#status').val(),
                "dir":$('#dir').text(),
                "aurl":$.trim($('#aurl').val())    };
    }

    $('#save-category').click(function(event){
        $('#category-err').text('');
        event.stopPropagation();    
        var _id = $(this).attr('_id');
        var j = values();
        var modify = false; //用户是否修改了值
        for(var p in j ){ if(j[p] != vs[p]){ modify = true; break;} }
        if (!modify) { $('#category-err').text('没有可用于提交的内容，请检查输入是否有效！'); return false; }
        j.id = vs.id = _id;        
        //用户输入校验 TODO
        
        
        $.post('ask/category.oper.ajx.php',j,function(r){ 
            var json = $.parseJSON(r);
            $('#category-err').text(json.err);
            if (j.status == '1') { vs = values(); }
        });
    
    });
    
    var user = users();
    //用户指派
    $('#save-user').click(function(){
        $('#user-err').text('');
        var j = users(); //获取新值
        //基本校验
        if (j.murl.empty()) { $('#user-err').text('必须指定管理URL'); return false; }
        if (j.uid.empty() && j.username.empty()){$('#user-err').text('必须有用户指派'); return false; }
        if (!j.username.empty())
        {
            if ((!j.pwd1.empty() || !j.pwd2.empty()) && j.pwd1 != j.pwd2)
            {
                $('#user-err').text('两次输入的密码不一致,如果为空，则使用默认的密码'); return false;
            }
        }
        $('#user-err').text('');
        //是否允许提交
        var allowed = false;
        for(var p in j){ if(j[p] != user[p]){ allowed = true; break;}}
        if (!allowed){ $('#user-err').text('没有可用于提交的内容!'); return false; }
        
        var json = {"murl":j.murl,  "rid":j.rid, "status":j.status,
                    "uid":j.uid,    "username":j.username,
                    "alias":j.alias,"type":j.type        };
        if(!j.pwd1.empty()){ json.password = j.pwd1; }
        
        $.post('../users/ask/users.save.ajx.php',json,function(r){  //提交内容
            var jn = $.parseJSON(r);
            if(jn.status == '1')
            {
                user = users();
                $('#username').val('');
                $('#alias').val('');
                $('#password').val('');
                $('#pwd').val();
            }
            $('#user-err').text(jn.err);
        });
    });
    
    $('#user #lists .more').click(function(){
        var serial = $(this).attr('id').split('-')[1];
        if ($(this).hasClass('extend'))
        {
            $('#dis' + serial).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + serial).fadeIn();
            $(this).text('折叠>>');
        }
    });
    
    function users()
    {
        var user = document.getElementsByName('user');
        var selects = [];
        for(var i=0;i<user.length;i++){ if(user[i].checked){selects.push(user[i].value); } }
        
        return {"murl":$.trim($('#murl').val()),
                "rid":$('#regions').val(),
                "status":$('#status').val(),
                "uid":selects.join('|'),
                "username":$.trim($('#username').val()),
                "alias":$.trim($('#alias').val()),
                "type":$('#type').val(),
                "pwd1":$('#password').val(),
                "pwd2":$('#pwd').val()                      };
    }
    
    //为空值对象提供默认值
    $('#stime,#etime,#serial').focus(function(){
        var date = new Date();
        var v = $.trim($(this).val());
        if (v.empty())
        {
            var arr = [];
            arr.push(date.getFullYear(),String(date.getMonth() + 1).doubled(),String(date.getDate()).doubled());
            
            var time = [];
            time.push(String(date.getHours()).doubled(),String(date.getMinutes()).doubled(),String(date.getSeconds()).doubled());
            
            if ($(this).attr('id') == 'serial')
            {
                $(this).val(arr.join('') + time.join(''));
            
            }else{ $(this).val(arr.join('-') + ' ' + time.join(':'));}
        }
    });
    function vars()
    {
        return {"murl":$.trim($('#murl').val()),   "stime":$.trim($('#stime').val()),
                "etime":$.trim($('#etime').val()), "serial":$.trim($('#serial').val()),
                "psize":$.trim($('#psize').val()), "cached":$.trim($('#cached').val()),
                "shortid":$.trim($('#shortid').val()), "ssign":$.trim($('#ssign').val()),
                "esign":$.trim($('#esign').val()),     "limited":$.trim($('#limited').val()),
                "auxiliary":$.trim($('#auxiliary').val())
        }
    }
    
    var vared = vars();
    //初始化变量
    $('#save-var').click(function(){
        $('#variable-err').text(''); //清空错误提示
        var v = vars();
        //获取managingURL的值
        if(v.murl.empty()){ $('#variable-err').text('必须指定管理URL');return false; }
        //至少有一个变量值不为空
        var empties = 0;
        for(var p in v){  if( p != 'murl' && v[p].empty()){ empties += 1; } } 
        if(empties == 10){ $('#variable-err').text('没有为此类别提供任何可初始化的变量,初始化失败');return false; }
        var allowed = false;
        
        if(!v.serial.empty() && isNaN(parseInt(v.serial))){ $('#variable-err').text('标准类别序列号只能是数字'); return false;}
        if(!v.psize.empty() && isNaN(parseInt(v.psize))){ $('#variable-err').text('用户数据分页值只能是数字'); return false;}
        if(!v.cached.empty() && isNaN(parseInt(v.cached))){ $('#variable-err').text('缓存有效时间值只能是数字'); return false;}
        if(!v.auxiliary.empty() && isNaN(parseInt(v.auxiliary))){ $('#variable-err').text('附加信息标识符只能是一个数字'); return false;}
        
        for(var q in v){ if(v[q] != vared[q]){ console.log(v[q]); allowed = true; break; }}
        if(!allowed){ $('#variable-err').text('没有可用于提交的内容，此内容可能提交过');return false; }
        //提交内容
        $.post('ask/category.oper.vars.ajx.php',v,function(r){
            var j = $.parseJSON(r);
            if(j.status == 1){ vared = vars();}
            $('#variable-err').text(j.tip);
        });    
    });
    
    //获取表的内容
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
                $('#fields tbody').html('');
                $('#fields tbody').html('<tr><td><input /></td><td><input /></td><td><input /></td><td><input /></td><td><input type="checkbox" class="check" /></td></tr>');  
                return false;
            }
            $('#select').val('FROM ' + v);
            $.post('ask/columns.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
                    $('#fields tbody').html('');
                    $('#fields tbody').html(j.tbody);                    
                }
            });
        }
    });  
    
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
        var trCheck = $('#fields tbody .clone');
        var obj = trCheck.length == 0 ? 'tr:last-child' : '.clone';
        $('#fields tbody ' + obj).after($('#fields tbody tr:first-child').clone());       
        $('#fields tbody').delegate('.check','click',check);
    });
    
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){        
        var tr = $('#fields tbody tr');
        var trCheck = $('#fields tbody .clone'); //不能全部删除
        if(trCheck.length != tr.length && trCheck.length > 0){ $('#fields tbody .clone').remove(); }        
    });
    
    //用户点选字段 可能是复制或者删除
    $('#fields tbody').delegate('.check','click',check);
    function check()
    {
        $(this).is(':checked') ? $(this).closest('tr').addClass('clone')
                               : $(this).closest('tr').removeClass('clone');
    }
    
    //保存过滤器
    var filterOldValue = filtered();
    function filtered() //收集过滤器值的函数
    {
        var filter = {};
        filter.murl = $('#murl').val();
        filter.region = $('#regions').val();
        filter.title = $.trim($('#filter-title').val());
        //过滤器的字段内容 字段名
        var tr = $('#fields tbody tr');
        var trArr = [];
        tr.each(function(i,obj){
            var td = $(obj).children('td');
            var inputValue = [];
            td.each(function(j,object){
                var input = $(object).children('input');
                if(!input.hasClass('check')){ inputValue.push($.trim(input.val())); }                
            });
            trArr.push(inputValue.join('|'));
        });
        filter.tname = $.trim($('#tablename').val());
        filter.fields = trArr.join(',');
        filter.searcher = $.trim($('#fsearch').val());
        filter.select = $.trim($('#select').val());
        filter.factor = $.trim($('#factor').val());
        filter.rest = $.trim($('#rest').val());
        return filter;
    }
    
    //提交过滤器内容
    $('#save-filter').click(function(){
        $('#filter-err').text('');
        //重新收集过滤器的值
        var filter = filtered();
        if(filter.murl.empty()){ $('#filter-err').text('必须指定管理URL');return false; }
        if(filter.title.empty()){ $('#filter-err').text('标题不能空.');return false;}
        var fields = filter.fields.split(',');
        for(var j=0;j<fields.length;j++)
        {
            var _tmp = fields[j].split('|');
            if (_tmp[0].empty() || _tmp[1].empty()) { $('#filter-err').text('必须指定数据表字段和显示名称');return false; }
        }

        if(filter.select.empty()){ $('#filter-err').text('select不能空.');return false;}
        var compare = false;
        for(var p in filter){ if(filter[p] != filterOldValue[p]){ compare = true; break;}}
        if(!compare){ $('#filter-err').text('没有可用于提交的内容');return false; }
        //提交过滤器
        $.post('ask/category.oper.filter.ajx.php',filter,function(r){ /*console.log(r);*/
            var j = $.parseJSON(r);
            //更新初始值 阻止重复提交
            if(j.yes == '1'){  filterOldValue = filtered(); }
            $('#filter-err').text(j.tip);
        });
        
    });
    
    //variable filter的折叠显示
    $('.closed').click(function(){
        if ($(this).hasClass('folded'))
        {
            $(this).removeClass('folded');
            $(this).children('img').attr('src','/points/usr/local/images/plus.png');
            $(this).parent().parent().children('div').fadeOut();
        }else
        {
            $(this).children('img').attr('src','/points/usr/local/images/minus.png');
            $(this).addClass('folded');
            $(this).parent().parent().children('div').fadeIn();
        }
    });
});
