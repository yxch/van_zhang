<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>
<!DOCTYPE html>
<html>
	 <head>
		<?php echo points::head(0); ?>
		<link rel="stylesheet" href="/points/cross/local/css/master.css" />
		<link rel="stylesheet" href="/points/cross/local/css/page-lists.css" />
		<link rel="stylesheet" href="/points/bases/world/paging.css" />
		<script src="/points/cross/local/js/f.js"></script>  
		<script src="/points/cross/local/js/frame.js"></script>
		<script src="/points/bases/world/paging.js"></script>
		<style>.page-lists li i{width:120px;}</style>
    </head>
    <body>
        <div id="outset">
              <div id="topic"><h1>类别管理器</h1><span id="err"></span></div>
              <div id="tip">
			<p class="first">提示：顶部的搜索框可以按<strong>类别显示名</strong>,<strong>管理URL</strong>或者<strong>访问URL</strong>的相关内容进行模糊搜索。输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
              </div>
		<div id="ul"></div>
		<div id="paging"><span></span></div>
		<div id="oper">
			<a id="close"><img title="关闭" src="<?php echo IMAGE; ?>close-16px.png" /></a>
			<a id="delete"><img title="删除" src="<?php echo IMAGE; ?>delete-1.png" /></a>
			<a id="edit"><img title="编辑" src="<?php echo IMAGE; ?>edit-1.png" /></a>
			<a id="add"><img title="增加" src="<?php echo IMAGE; ?>new-1.png" /></a>
			<a id="checked"><img title="选择" src="<?php echo IMAGE; ?>check-1.png" /></a>
			<a id="uncheck"><img title="取消选择" src="<?php echo IMAGE; ?>uncheck-1.png" /></a>
			<a id="isshow"><img title="展开" src="<?php echo IMAGE; ?>expand.png" /></a>
			<a id="showall"><img title="全部展开" src="<?php echo IMAGE; ?>all-expand.png" /></a>
		</div>
        </div>
	<script src="js/category.js"></script>
    </body>
</html>