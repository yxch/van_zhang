
var local = {"hides":1,"showall":false}; //全局变量定义
$(document).ready(function(){
	//页面初始化时收起所有条目
	$('.page-lists').each(function(i,obj){
		$(obj).children('li').each(function(j,o){
			if(j > local.hides){ $(o).hide(); }
		});
		$(obj).children('.more').show();	$(obj).removeClass('showed');
		$(obj).append('<li class="more"><a title="查看更多">. . .</a></li>');
	});	
	//每一条记录的第一个字段的单击事件 显示操作小窗口
	$('.page-lists li:nth-child(1)').click(function(){
		local.w = $(this).closest('.page-lists').width() - $('#oper').width();
		local.h = $(this).closest('.page-lists').offset().top;
		$('#oper').css({"top":local.h + 10,"left":local.w});
		$('#oper').show();
		local.id = $(this).closest('.page-lists').attr('id'); 
		if($(this).closest('.page-lists').hasClass('showed'))
		{
			$('#oper #isshow  img').attr({"title":'收起',"src":'image/arrow-up.png'});
		}else{	$('#oper #isshow  img').attr({"title":'展开',"src":'image/arrow-down.png'}); }
	});
	//当用户鼠标离开当前ul时隐藏操作小窗口
	$('.page-lists').mouseleave(function(){ $('#oper').hide(); });
	//当用户鼠标进入小窗口时显示
	$('#oper').mouseover(function(){ $('#oper').show(); });
	//单击每一个查看更多按钮
	$('.more a').click(function(){
		$(this).closest('.page-lists').addClass('showed');
		$(this).parent().hide();
		$(this).parent().siblings('li').show();
		local.showall = true;
		$('#oper #showall').children('img').attr({"title":'全部收起',"src":'image/arrow-collapsed.png'});
	});
	//展开或收起当前操作的条目
	$('#oper #isshow').click(function(){
		var e = $('#' + local.id);
		if(e.hasClass('showed')) //隐藏指定的li
		{
			var li = e.children('li');
			li.each(function(i,obj){ if(i > local.hides){ $(obj).hide(); }	});
			e.children('.more').show();	e.removeClass('showed');
			$(this).children('img').attr({"title":'展开',"src":'image/arrow-down.png'});
			local.showall = false;
			$('#oper #showall').children('img').attr({"title":'全部展开',"src":'image/arrow-expand.png'});
		}else
		{
			e.children('li').show();	e.children('.more').hide();	e.addClass('showed');
			$(this).children('img').attr({"title":'收起',"src":'image/arrow-up.png'});
			local.showall = true;
			$('#oper #showall').children('img').attr({"title":'全部收起',"src":'image/arrow-collapsed.png'});
		}
	});
	//展开全部和收起全部按钮事件
	$('#oper #showall').click(function(){
		var ul = $('.page-lists');
		if(local.showall) //默认收起全部 单击后展开全部
		{
			local.showall = false;
			ul.each(function(i,obj){
				$(obj).children('li').each(function(j,o){
					if(j > local.hides){ $(o).hide(); }
				});
				$(obj).children('.more').show();	$(obj).removeClass('showed');
			});
			$(this).children('img').attr({"title":'全部展开',"src":'image/arrow-expand.png'});
		}else
		{
			local.showall = true;
			ul.each(function(i,obj){
				$(obj).addClass('showed'); $(obj).children('li').show(); $(obj).children('.more').hide();
			});
			$(this).children('img').attr({"title":'全部收起',"src":'image/arrow-collapsed.png'});
		}
	});
	//小窗口的关闭按钮事件
	$('#oper #close').click(function(){ $('#oper').fadeOut(); });
});
