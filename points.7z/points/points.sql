﻿
DROP TABLE IF EXISTS `drupal_activity`.`tb_points_category`;

CREATE TABLE `drupal_activity`.`tb_points_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `md5` char(32) DEFAULT NULL COMMENT '路径MD5值',
  `title` varchar(64) DEFAULT NULL COMMENT '类别中文标题',
  `rid` int(11) DEFAULT NULL COMMENT '区域id',
  `murl` varchar(254) DEFAULT NULL COMMENT '管理路径',
  `tid` int(11) unsigned DEFAULT NULL,
  `pos` char(1) DEFAULT '1' COMMENT '隶属于1:前端页面显示2:后台管理页面',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`),
  KEY `yes` (`yes`),
  KEY `md5` (`md5`),
  KEY `rid` (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=712 DEFAULT CHARSET=utf8;


insert  into `drupal_activity`.`tb_points_category`(`id`,`md5`,`title`,`rid`,`murl`,`tid`,`pos`,`yes`,`mtime`,`ctime`) values (701,'95331b78d9c7fa01183b64b44ec89f38','类别管理器',601,'http://system.points.org/usr/master/category/',301,'1','1',NULL,'2016-01-02 10:08:14'),(702,'6d9d8b070083cb6a01264ca87699528c','数据过滤器',601,'http://system.points.org/usr/filters/',305,'2','1',NULL,'2016-01-02 10:09:27'),(703,'af3f4175c9160c46b4e2136b66e9aa51','变量管理器',601,'http://system.points.org/usr/master/variable/',306,'2','1',NULL,'2016-01-02 10:09:48'),(704,'64677b4b7bea8fe9963df2c304d84c97','用户管理器',601,'http://system.points.org/usr/master/users/',303,'2','1',NULL,'2016-01-02 10:10:10'),(705,'455733af3200ffb5aaa8e7ad36c66e47','权限管理器',601,'http://system.points.org/usr/master/powers/',304,'2','1',NULL,'2016-01-02 10:10:30'),(706,'df729e298001a98034eed6e3c351afba','区域管理器',601,'http://system.points.org/usr/master/regions/',302,'2','1',NULL,'2016-01-02 10:11:32'),(707,'754091694fac875d5bd9bda45f876ad0','模板管理器',601,'http://system.points.org/usr/master/template/',307,'2','1',NULL,'2016-01-02 10:11:56'),(708,'237169f63a9feea5e22727bf7d134a45','客服中心价格价值险数据管理',604,'http://www.cignacmb.com/service/',308,'2','2',NULL,'2016-01-02 10:24:47'),(709,'919c8135f2f538d832dfefb6d1de5617','招行4月活动基础数据',602,'http://test.cignacmb.com/campaign/mc/cmbcc/201604/',309,'2','2',NULL,'2016-01-02 10:25:47'),(710,'b972be535c32bb6a8a7875b330badafb','广发4月活动基础数据',603,'http://test.cignacmb.com/campaign/mc/cgb/201604/',309,'2','2',NULL,'2016-01-02 10:26:11'),(711,'b972be535c32bb6a8a7875b330badafb','广发4月活动控制台',603,'http://test.cignacmb.com/campaign/mc/cgb/201604/',310,'2','2',NULL,'2016-01-02 10:26:34');


DROP TABLE IF EXISTS `drupal_activity`.`tb_points_filters`;

CREATE TABLE `drupal_activity`.`tb_points_filters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '过滤器名称',
  `cid` int(11) DEFAULT NULL COMMENT '所属类别id',
  `flds` text COMMENT '字段设定',
  `slt` text COMMENT 'SQL语句select部分',
  `rst` text COMMENT 'SQL语句的其它部分',
  `flag` char(32) DEFAULT NULL COMMENT '显示字段唯一标识',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '是否废弃 1使用 0废弃',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `flag` (`flag`),
  KEY `yes` (`yes`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `drupal_activity`.`tb_points_powers`;

CREATE TABLE `drupal_activity`.`tb_points_powers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `cid` int(11) DEFAULT NULL COMMENT '分类id',
  `ctle` varchar(128) DEFAULT NULL COMMENT '类别的标题',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '权限值',
  `yes` char(1) NOT NULL DEFAULT '1',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cid` (`cid`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;

insert  into `drupal_activity`.`tb_points_powers`(`id`,`uid`,`cid`,`ctle`,`auth`,`yes`,`mtime`,`ctime`) values (201,102,709,'招行4月活动基础数据','1000000010','1',NULL,'2016-01-02 10:27:30'),(202,103,711,'广发4月活动控制台','1000000010','1',NULL,'2016-01-02 10:28:12'),(203,104,708,'客服中心价格价值险数据管理','1000000000','1',NULL,'2016-01-02 10:28:40'),(204,103,710,'广发4月活动基础数据','1000000010','1',NULL,'2016-01-02 10:33:36');


DROP TABLE IF EXISTS `drupal_activity`.`tb_points_regions`;

CREATE TABLE `drupal_activity`.`tb_points_regions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '区域的中文显示名',
  `region` char(1) NOT NULL DEFAULT '1' COMMENT '1:用户数据2:控制台3:定制',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '区域的默认权限',
  `dir` varchar(254) DEFAULT NULL COMMENT '区域的默认目录',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '区域的默认状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '区域的创建时间',
  PRIMARY KEY (`id`),
  KEY `named` (`named`),
  KEY `dir` (`dir`),
  KEY `region` (`region`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=605 DEFAULT CHARSET=utf8;

insert  into `drupal_activity`.`tb_points_regions`(`id`,`named`,`region`,`auth`,`dir`,`yes`,`mtime`,`ctime`) values (601,'设置中心','2','1111111111','/points/usr/master/','1',NULL,'2016-01-02 10:08:14'),(602,'招商银行','1','1000000010','/points/usr/servant/','1',NULL,'2016-01-02 10:14:43'),(603,'广发银行','1','1000000010','/points/usr/servant/','1',NULL,'2016-01-02 10:14:58'),(604,'客服中心','2','1000000000','/points/usr/master/','1',NULL,'2016-01-02 10:15:46');

DROP TABLE IF EXISTS `drupal_activity`.`tb_points_session`;

CREATE TABLE `drupal_activity`.`tb_points_session` (
  `sid` char(32) NOT NULL,
  `mme` int(11) DEFAULT NULL COMMENT 'session的修改时间',
  `cip` char(15) DEFAULT NULL COMMENT '客户端的ipv4的地址',
  `txt` text COMMENT '用户写入session的自定义内容',
  `ctt` text COMMENT '其它的基于session id的内容(通常是json格式的)',
  `yes` char(1) DEFAULT '1' COMMENT '状态描述',
  `cme` int(11) DEFAULT NULL COMMENT '记录创建时间，访问时间',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `drupal_activity`.`tb_points_template`;

CREATE TABLE `drupal_activity`.`tb_points_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL COMMENT '模板标题',
  `md5` char(32) DEFAULT NULL COMMENT '路径标识符',
  `path` varchar(255) DEFAULT NULL COMMENT '路径',
  `layer` text COMMENT '布局',
  `tag` char(2) DEFAULT '1' COMMENT '标识符',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `md5` (`md5`)
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8;


insert  into `drupal_activity`.`tb_points_template`(`id`,`title`,`md5`,`path`,`layer`,`tag`,`mtime`,`ctime`) values (301,'类别列表界面[查看类别详情]','2320111fed2678f8b240c0ae5cfceb20','/points/usr/master/category/category.php','','1',NULL,'2016-01-02 10:08:14'),(302,'区域管理系统界面[查看修改添加删除]','f9f6415e850501da0c562027ddcf0117','/points/usr/master/regions/regions.php','','1',NULL,'2016-01-02 10:08:14'),(303,'用户管理系统列表界面[查看修改添加用户]','e4d8c43d334654b6585ec8792383cbeb','/points/usr/master/users/users.php','','1',NULL,'2016-01-02 10:08:14'),(304,'权限管理系统列表界面[查看修改添加权限]','ed9b52078686ae4383738102fd870667','/points/usr/master/users/power.php','','1',NULL,'2016-01-02 10:08:14'),(305,'数据过滤器系统列表界面[查看过滤器详情]','782300e071ca7ae471f452c829016e24','/points/usr/master/filters/filters.php','','1',NULL,'2016-01-02 10:08:14'),(306,'变量系统列表界面[查看变量内容]','82bbf409f15df18137a59903c73789f6','/points/usr/master/variable/variable.php','','1',NULL,'2016-01-02 10:08:14'),(307,'模板管理系统列表界面[查看修改添加模板]','14903d55c4fb2d2a4d09f21c3f21ba7d','/points/usr/master/template/template.php','','1',NULL,'2016-01-02 10:08:14'),(308,'客服中心价格价值险管理模板','4ad2d1fa71a5df5024d04a4776f2ed76','/points/usr/service/universal/universal.php','','2',NULL,'2016-01-02 10:22:22'),(309,'用户数据查询导出管理界面','205e1a5d707ab9c35540966e504d30fc','/points/usr/servant/banker/banker.php','','2',NULL,'2016-01-02 10:23:08'),(310,'活动流程控制管理界面','c1e3e4de772c6de883238b183a8b842e','/points/usr/servant/backer/backer.php','','2','2016-01-02 08:31:38','2016-01-02 10:23:35');


DROP TABLE IF EXISTS `drupal_activity`.`tb_points_users`;

CREATE TABLE `drupal_activity`.`tb_points_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '表主键 id',
  `usr` varchar(64) DEFAULT NULL COMMENT '用户名',
  `pwd` char(32) DEFAULT NULL COMMENT '密码',
  `alias` varchar(64) DEFAULT NULL COMMENT '中文别名',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱地址',
  `ppath` varchar(254) DEFAULT NULL COMMENT '头像路径',
  `tye` char(1) NOT NULL DEFAULT '1' COMMENT '作用范围: 1前端页面 2后台页面 3通用',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_usr` (`usr`),
  KEY `passwd` (`pwd`),
  KEY `yes` (`yes`),
  KEY `usr` (`usr`),
  KEY `tye` (`tye`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;


insert  into `drupal_activity`.`tb_points_users`(`id`,`usr`,`pwd`,`alias`,`email`,`ppath`,`tye`,`yes`,`mtime`,`ctime`) values (101,'pointer','530af9881273c3a5efe8c1052c940492','魔法师','vxzhan@cignacmb.com.cn','','9','1',NULL,'2016-01-02 10:13:34'),(102,'cmbcc','d847f5bbe427010efbf1e27934b8efcb','招行数据管理员','','','2','1',NULL,'2016-01-02 10:27:30'),(103,'CGB2016','d847f5bbe427010efbf1e27934b8efcb','广发数据管理员','','','2','1',NULL,'2016-01-02 10:28:12'),(104,'service','d847f5bbe427010efbf1e27934b8efcb','客服中心','','','2','1',NULL,'2016-01-02 10:28:40');


DROP TABLE IF EXISTS `drupal_activity`.`tb_points_variables`;

CREATE TABLE `drupal_activity`.`tb_points_variables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '变量名',
  `val` varchar(254) DEFAULT NULL COMMENT '变量值',
  `pos` char(32) DEFAULT NULL COMMENT '变量应用在',
  `url` varchar(254) DEFAULT NULL COMMENT '应用路径',
  `note` varchar(254) DEFAULT NULL COMMENT '变量的描述',
  `txt` text COMMENT '变量文本',
  `tag` char(1) NOT NULL DEFAULT '1' COMMENT '状态 2:用户变量 1:系统变量 0:废弃',
  `rule` varchar(32) DEFAULT NULL COMMENT '校验规则',
  `tye` varchar(32) NOT NULL DEFAULT 'text' COMMENT 'input的显示类型',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`,`ctime`),
  KEY `pos` (`pos`),
  KEY `named` (`named`),
  KEY `yes` (`tag`),
  KEY `note` (`note`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

