<?php
class points
{
    //与json_encode(array('status'=>x,'message'=>y))作用相同
    public static function jen($status=0,$message='未知错误!')
    {
        return json_encode(array('status'=>$status,'message'=>$message));   
    }
    public static function jan($arr){ echo  json_encode($arr); exit; }
    
    /**
          *账户映射(临时) 因为没有产品表
          */
    public static function accounts()
    {
        return array('rate_day'=>'日结算利率','rate_year'=>'年结算利率','rate_lowest'=>'最低保证利率');
    }
    
    /**
          *返回相应权限是否可用
         *@param string $authority 权限值，通常为1000000000
         *@param string $oper  edit delete add import export
         *@return boolean;
         */
    public static function allowed($authority,$oper)
    {
        if($oper == 'edit' && $authority[1] == 1){ return true; }
        if($oper == 'delete' && $authority[2] == 1){ return true; }
        if($oper == 'add' && $authority[3] == 1){ return true; }
        if($oper == 'import' && $authority[7] == 1){ return true; }
        if($oper == 'export' && $authority[8] == 1){ return true; }
        return false;
    }
    
    /**
	 *区域映射集
          */
    public static function regions(){ return array('1'=>'用户数据','2'=>'控制台','3'=>'定制');}
    
    /**
         * 虚拟的基本系统路径
         * @param string $type md5 或者 url
	* 注意：$arr的顺序 在初始化使用时加上了相应的标题
         */
    public static function sysurl($type="url")
    {
        $arr = array('http://system.points.org/usr/master/category/',
					 'http://system.points.org/usr/master/regions/',
                     'http://system.points.org/usr/master/users/',
                     'http://system.points.org/usr/master/powers/',
                     'http://system.points.org/usr/filters/',
                     'http://system.points.org/usr/master/variable/',
			         'http://system.points.org/usr/master/template/'		);
        if($type == 'url'){ return $arr; }
        if($type == 'md5')
        {
            $md = array();
            foreach($arr as $v){ $md[] = md5($v);}
            return $md;
        }
        return array();        
    }
    
    /**
          *提供分页的统一显示列表内容
          *@param int $total 总页数
          *@param int $page  当前页数
          *$size int $size   分页大小
          *@return string $fpage 返回html字符串
          *注意：class和id属性的修改可能导致样式和js的不可用！！！
          */
    public static function fpage($total,$page,$size)
    {
        if($total == 0){ return ''; }
        $fpage = '';        
        $fpage .= '<a class="first" id="p-1">首页</a>'; //首页        
        $last = ($page - 1) <= 1 ? 1 : $page - 1; //上一页
        $fpage .= '<a class="last" id="p-' . $last . '">上页</a>';        
        //页面列表
        $pager = 8;//显示10个分页
        $_h = ceil($pager / 2);
        
        $s = 1; $e = $pager;
        $s = $page - $_h < 1 ? 1 : $page - $_h; //设置起始页
        $e = $page + $_h > $total ? $total : $s + ($pager - 1); //设置结束页
        if($e - $pager + 1 >= 1){ $s = ($e - $s + 1) < $pager ? $e - $pager + 1 : $s;}

        for($s;$s<=$e;$s++)
        {
            $underline = ($s == $page) ? 'underline' : ''; 
            $fpage .= '<a class="page ' . $underline .  '" id="p-' . $s . '">' . $s . '</a>';
        }
        
        $next = ($page + 1) >= $total ? $total : $page + 1;   //下一页
        $fpage .= '<a class="next" id="p-' . $next . '">下页</a>';
        $fpage .= '<a class="end" id="p-' . $total . '">末页</a>';    //末页        
        return $fpage;
    }
    
    //公用头部内容
    public static function head($shell=true,$head=null)
    {
        $header = '';
        $header .= "<meta charset=\"utf-8\" />\r\n\t";
        if(isset($head['title'])){ $header .= '<title>' . $head['title'] . "</title>\r\n\t"; }
        $header .= "<link rel=\"stylesheet\" href=\"/points/bases/world/reset.css\" />\r\n\t";
        if($shell)
        {
            $header .= "<link rel=\"stylesheet\" href=\"/points/cross/local/css/shell.css\" />\r\n\t";
            $header .= "<link rel=\"stylesheet\" href=\"/points/cross/local/css/foot.css\" />\r\n\t";
        }
        $header .= "<script type=\"text/javascript\" src=\"/points/bases/world/jquery.min.js\"></script>\r\n";
        return $header;
    }
    
    //公用页脚部分
    public static function foot()
    {
        return '<span id="linked"><a href="http://www.cignacmb.com">招商信诺首页</a></span><span id="copyright">Copyright © 2016 招商信诺人寿保险有限公司. All Rights Reserved. 粤ICP备11053445号-2</span>';
    }
    
    /**
          * 显示shell.php并处理变量
          * @param string $page 面板路径如果不提供则包含shell.php
          * @param array $shell   板所需的变量，必须按指定的键名赋值
          */
    public static function shell(array $page,$shell='')
    {
        if(empty($shell))
        {
            include_once TPL . 'shell.tpl.php';
        }else
        {
            if(file_exists(SPH . '/usr/local/shell/' . $shell . '.tpl.php'))
            {
                include_once SPH . '/usr/local/shell/' . $shell . '.tpl.php';
            
            }else{ exit('指定的界面文件不存在！'); }
        }
    }
    
    /**
	 *检查url是否符合要求
	 */
    public static function SURL($url,$removeBasename=false)
    {
        $arr = array('status'=>0,'url'=>'','md5'=>'');
        //把10.140.130.35:8001替换成test.cignacmb.com
        $url = strtr($url,array('10.140.130.35:8001'=>'test.cignacmb.com'));
        
        $urls = parse_url(trim($url));
        if(!isset($urls['scheme']) || !isset($urls['host'])){ return $arr; }
        
        if($url[strlen($url) - 1] != '/' && $removeBasename){ $url = strtr($url,array(basename($url)=>'')); }
        $arr['status'] = 1;
        $arr['url'] = implode('',explode(' ',$url)); //去掉全部空格
        $arr['md5'] = md5($arr['url']); //url的md5值        
        return $arr;
    }
    
    /**
     * 处理字段内容的函数 用于数据过滤器
     */
    public static function parseField($field)
    {
        $arr = array('tb'=>'','field'=>null,'translator'=>null,'flag'=>null);
        if(empty($field)){ return $arr; }
        
        $exp = explode('=',$field);
        if(empty($exp[0]) || empty($exp[1])){ return $arr; } //表名和字段不能为空
        $arr['tb'] = $exp[0];
        $fields = explode(',',$exp[1]);
        for($i=0,$l=count($fields);$i<$l;$i++)
        {
            $_tmp = explode('|',$fields[$i]);
            $arr['field'][$_tmp[0]] = $_tmp[1];
            if(!empty($_tmp[2])){ $arr['translator'][$_tmp[0]] = $_tmp[2]; }
            if(!empty($_tmp[3])){ $arr['flag'][$_tmp[0]] = $_tmp[3];}
        }
        return $arr;
    }    
    
    /**
     *处理翻译设定的函数 用于数据过滤器
     */
    public static function translator($key,$v,$translator)
    {
        //如果没有设定此字段的翻译条件，立即返回字段的原始值
        if(!is_array($translator) || !isset($translator[$key])){ return $v; } 
        $tran = $translator[$key];
        if(stripos($tran,'fun') !== false)
        {
            $trans = explode(':',$tran);
            eval("\$v = " . $trans[1] . ";");
            return $v; //返回翻译后的值
        }else
        {
            $arr = explode(' ',$tran);
            for($i=0,$l=count($arr);$i<$l;$i++)
            {
                $_arr = explode(':',$arr[$i]);
                if($_arr[0] == $v){ return $_arr[1]; }
            }
        }
        return $v;
    }

    public static function exits($message='')
    {
        return '<div style="border:3px solid red;width:80%;height:32px;margin:100px auto;text-align:center;font-style:italic;">' . $message . '</div>';
    }
}
