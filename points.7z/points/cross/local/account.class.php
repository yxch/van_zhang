<?php
class account extends DBO
{
    protected $id;
    protected $account;
    protected $aliase;
    protected $status;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_account'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'aname'=>'account',
                     'aliase'=>'aliase',
                     'yes'=>'status',
                     'ctime'=>'createTime'         );
    }
}
