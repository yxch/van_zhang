<?php
class power extends DBO
{
    protected $id;
    protected $userId;
    protected $categoryId;
    protected $categoryTitle;
    protected $authority;
    protected $status;
	protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_powers'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'uid'=>'userId',
                     'cid'=>'categoryId',
                     'ctle'=>'categoryTitle',
                     'auth'=>'authority',
                     'yes'=>'status',
					 'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'         );
    }
}
