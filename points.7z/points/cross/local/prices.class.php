<?php
class prices extends DBO
{
    protected $id;
    protected $accountId;    //账户id
    protected $price;        //价值
    protected $settleTime;   //结算时间
    protected $modifiedTime; //记录修改时间
    protected $createTime;   //记录创建时间
    
    protected function definedTableName(){ return 'tb_account_price'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'aid'=>'accountId',
                     'price'=>'price',
                     'etime'=>'settleTime',
                     'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'         );
    }
}
