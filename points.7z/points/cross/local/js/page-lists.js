
//empty: 表示用户请求时返回的条目数量 如果大于0则为假 否则为真 
//hides: 表示在单展开或收起以及全部展开和全部收起时隐藏的起始索引
//showall:当前是否全展开或收起
//page:当前页

var local = {"empty":false,"hides":3,"showall":false,"page":1,"select":{}}; //全局变量定义

$(document).ready(function(){
	
	var img = '/points/cross/local/image/';
	
	//每一条记录的单击事件 显示操作小窗口
	$('.page-lists').click(function(){
		local.w = $(this).closest('.page-lists').width() - $('#oper').width();
		local.h = $(this).closest('.page-lists').offset().top;
		$('#oper').css({"top":local.h + 10,"left":local.w});
		$('#oper').show();
		local.id = $(this).closest('.page-lists').attr('id'); 
		if($(this).closest('.page-lists').hasClass('showed'))
		{
			$('#oper #isshow  img').attr({"title":'收起',"src": img + 'collapse.png'});
		}else{	$('#oper #isshow  img').attr({"title":'展开',"src": img + 'expand.png'}); }
	});
	
	//第一个li单击时选择，实现多选功能
	$('.page-lists li:nth-child(1)').click(function(){
		if(local.empty){ return false; }
		var ul = $(this).closest('ul');
		if(ul.hasClass('selected'))
		{
			ul.removeClass('selected');
			delete local.select[ul.attr('id')];
		}else
		{
			ul.addClass('selected');
			local.select[ul.attr('id')] = '';
		}
	});
	
	//当用户鼠标离开当前ul时隐藏操作小窗口
	$('.page-lists').mouseleave(function(){ 
		$('#oper').hide(); 
		if($('#editable').length > 0){ $('#editable').hide(); }
	});
	
	//当用户鼠标进入小窗口时显示
	$('#oper').mouseover(function(){ $('#oper').show(); });
	
	//单击每一个查看更多按钮
	$('.more a').click(function(){
		$(this).closest('.page-lists').addClass('showed');
		$(this).parent().hide();
		$(this).parent().siblings('li').show();
		local.showall = true;
		$('#oper #showall').children('img').attr({"title":'全部收起',"src":img + 'all-collapsed.png'});
	});
	
	//小窗口上的选择按钮
	$('#oper #checked').click(function(){
		var ul = $('#' + local.id);
		if(!ul.hasClass('selected'))
		{
			ul.addClass('selected');
			local.select[ul.attr('id')] = '';
		}
	});
	
	//小窗口的取消选择按钮
	$('#oper #uncheck').click(function(){
		local.select = {}; //清空local.select
		$('.selected').removeClass('selected'); //清除样式显示
	});
	
	//展开或收起当前操作的条目
	$('#oper #isshow').click(function(){
		if(local.empty){ return; }
		var e = $('#' + local.id);
		if(e.hasClass('showed')) //隐藏指定的li
		{
			var li = e.children('li');
			li.each(function(i,obj){ if(i > local.hides){ $(obj).hide(); }	});
			e.children('.more').show();	e.removeClass('showed');
			$(this).children('img').attr({"title":'展开',"src":img + 'expand.png'});
			local.showall = false;
			$('#oper #showall').children('img').attr({"title":'全部展开',"src":img + 'all-expand.png'});
		}else
		{
			e.children('li').show();	e.children('.more').hide();	e.addClass('showed');
			$(this).children('img').attr({"title":'收起',"src":img + 'collapse.png'});
			local.showall = true;
			$('#oper #showall').children('img').attr({"title":'全部收起',"src": img + 'all-collapsed.png'});
		}
	});
	
	//展开全部和收起全部按钮事件
	$('#oper #showall').click(function(){
		if(local.empty){ return; }
		var ul = $('.page-lists');
		if(local.showall) //默认收起全部 单击后展开全部
		{
			local.showall = false;
			ul.each(function(i,obj){
				$(obj).children('li').each(function(j,o){
					if(j > local.hides){ $(o).hide(); }
				});
				$(obj).children('.more').show();	$(obj).removeClass('showed');
			});
			$(this).children('img').attr({"title":'全部展开',"src":img + 'all-expand.png'});
			$('#oper #isshow').children('img').attr({"title":'展开',"src":img + 'expand.png'});
		}else
		{
			local.showall = true;
			ul.each(function(i,obj){
				$(obj).addClass('showed'); $(obj).children('li').show(); $(obj).children('.more').hide();
			});
			$(this).children('img').attr({"title":'全部收起',"src":img + 'all-collapsed.png'});
			$('#oper #isshow').children('img').attr({"title":'收起',"src":img + 'collapse.png'});
		}
	});
	
	//小窗口的关闭按钮事件
	$('#oper #close').click(function(){ $('#oper').fadeOut(); });
});
