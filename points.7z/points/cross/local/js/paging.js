
/**
 *js分页函数
 *van_zhang 2016-01-23
 *参数 j是一个json对象
 *j.total,j.page,j.size,j.pager
 *j.firstName,j.lastName,j.nextName,j.endName
 *j.firstId,j.lastId,j.nextId,j.endId,j.pageClass,j.pageCurrentClass
 *j.inputId
 */
function paging(j)
{
    var obj = new Object();
    obj.total = parseInt(j.total) || 0;  //总记录数 程序必须提供的值
    obj.page = parseInt(j.page) || 1;    //当前页 程序必须提供的值
    obj.size = parseInt(j.size) || 20;   //分页大小 程序可能提供的值
    obj.pager = parseInt(j.pager) || 8; //显示的分页个数 程序可能提供的值
    
    obj.firstName = j.firstName || '首页'; //首页的显示名称
    obj.firstId = j.firstId || 'first';		//首页的id 如果用户没有提供就用first 单击事件和样式需要
    obj.lastName = j.lastName || '上一页';		//上一页的显示名称
    obj.lastId = j.lastId || 'last';    //上页的id 如果用户没有提供就用last 单击事件和样式需要
    obj.pageCurrentClass = j.pageCurrentClass || 'current'; //用户选择的当前页的类名
    obj.pageClass = j.pageCalss || 'page';    //每页的class 如果用户没有提供就用page 单击事件和样式需要
    obj.nextName = j.nextName || '下一页'; //下一页的显示名称
    obj.nextId = j.nextId || 'next';    //下页的id 如果用户没有提供就用next 单击事件和样式需要
    obj.endName = j.endName || '末页';  //末页的显示名称
    obj.endId = j.endId || 'end';    //末页的id 如果用户没有提供就用end 单击事件和样式需要
    obj.inputId = j.inputId || 'goto'; //跳转输入框的id 单击事件和样式需要
    
    obj.pages = Math.ceil(obj.total / obj.size); //计算页数
    
    obj.html = function(arr)
    {
		if(obj.total == 0 ){ return '';}
        var html = '';
        for(var i=0;i<arr.length;i++)
        {
            //显示首页
            if(arr[i] == 'first'){ html += '<a id="' + obj.firstId + '" ' + 'name="1">' + obj.firstName + '</a>'; }
            var last = (obj.page - 1) >= 1 ? obj.page - 1 : 1; //显示上一页
            if(arr[i] == 'last'){ html += '<a id="' + obj.lastId + '" ' + 'name="' + last + '">' + obj.lastName + '</a>'; }
            if(arr[i] == 'page'){ html += obj.all(); } //显示所有页
            var next = (obj.page + 1) <= obj.pages ? obj.page + 1 : obj.pages; //显示下一页
            if(arr[i] == 'next'){ html += '<a id="' + obj.nextId + '" ' + 'name="' + next + '">' + obj.nextName + '</a>'; }
            //显示末页
            if(arr[i] == 'end'){ html += '<a id="' + obj.endId + '" ' + 'name="' + obj.pages + '">' + obj.endName + '</a>'; }
            if (arr[i] == 'goto'){ html += '<input id="' + obj.inputId + '" value="' + obj.page + '"/>'; } //显示跳转到第几页的输入框
        }
        return html;        
    };
    
    obj.all = function()
    {
        var s = 1,e = obj.pager;
        var h = Math.ceil(obj.pager / 2);
        s = obj.page - h < 1 ? 1 : obj.page - h; //设置起始页
        e = obj.page + h > obj.pages ? obj.pages : s + (obj.pager - 1); //设置结束页
        if(e - obj.pager + 1 >= 1){ s = (e - s + 1) < obj.pager ? e - obj.pager + 1 : s;}
        var a = '';
        for(s;s<=e;s++)
        {
           var current = obj.page == s ? obj.pageCurrentClass : ''; 
           a += '<a class="' + obj.pageClass + ' ' + current + '" ' + 'name="' + s + '">' + s + '</a>';
        }
        return a;
    };
    obj.show = function(){ return obj.html(['first','last','page','next','end']);};
    obj.only = function(){ return obj.html(['page']); };
    obj.simple = function(){ return obj.html(['last','page','next']);};
    obj.full = function(){ return obj.html(['first','last','page','next','end','goto']);};
    return obj;
}

/**
 *empty: 表示用户请求时返回的条目数量 如果大于0则为假 否则为真 
 *hides: 表示在单展开或收起以及全部展开和全部收起时隐藏的起始索引
 *showall:当前是否全展开或收起
 *page:当前页 
 **/

//全局对象
var pagings = {"empty":false,"hides":3,"showall":false,"page":1,"select":{}}; //全局变量定义

$(document).ready(function(){
	var img = '/points/cross/local/image/';
	
	//每一条记录的单击事件 显示操作小窗口
	$('#ul').delegate('.page-lists','click',function(){
		if($(this).hasClass('clone')){ return false; } //在新建时不显示浮动小窗口
		pagings.w = $(this).closest('.page-lists').width() - $('#oper').width();
		pagings.h = $(this).closest('.page-lists').offset().top;
		$('#oper').css({"top":pagings.h + 10,"left":pagings.w}); //确定小窗口的位置
		$('#oper').show(); //显示小窗口
		pagings.id = $(this).closest('.page-lists').attr('id'); //记住单击对象的id值
		if($(this).closest('.page-lists').hasClass('showed')) //小窗口上图标显示
		{
			$('#oper #isshow  img').attr({"title":'收起',"src": img + 'collapse.png'});
		}else{	$('#oper #isshow  img').attr({"title":'展开',"src": img + 'expand.png'}); }
	});
	
	//第一个li单击时选择，实现多选功能
	$('#ul').delegate('.page-lists li:nth-child(1)','click',function(e){ 
		e.stopPropagation();
		if($(this).closest('ul').hasClass('clone')){ return false; } //在新建时取消选择功能
		if(pagings.empty){ return false; }
		var ul = $(this).closest('ul');
		if(ul.hasClass('selected'))
		{
			ul.removeClass('selected');
			delete pagings.select[ul.attr('id')];
		}else
		{
			ul.addClass('selected');
			pagings.select[ul.attr('id')] = '';
		}
	});
	
	//当用户鼠标离开当前ul时隐藏操作小窗口
	$('#ul').delegate('.page-lists','mouseleave',function(){ 
		$('#oper').hide(); 
		if($('#editable').length > 0){ $('#editable').hide(); }
	});

	//单击每一个查看更多按钮
	$('#ul').delegate('.more a','click',function(e){
		e.stopPropagation();
		$(this).closest('.page-lists').addClass('showed');
		$(this).parent().hide();
		$(this).parent().siblings('li').show();
		pagings.showall = true;
		$('#oper #showall').children('img').attr({"title":'全部收起',"src":img + 'all-collapsed.png'});
	});
	
	//当用户鼠标进入小窗口时显示
	$('#oper').mouseover(function(){ $('#oper').show(); });
	
	//小窗口上的选择按钮
	$('#oper #checked').click(function(){
		var ul = $('#' + pagings.id);
		if(!ul.hasClass('selected'))
		{
			ul.addClass('selected');
			pagings.select[ul.attr('id')] = '';
		}
	});
	
	//小窗口的取消选择按钮
	$('#oper #uncheck').click(function(){
		pagings.select = {}; //清空pagings.select
		$('.selected').removeClass('selected'); //清除样式显示
	});
	
	//展开或收起当前操作的条目
	$('#oper #isshow').click(function(){
		if(pagings.empty){ return; }
		var e = $('#' + pagings.id);
		if(e.hasClass('showed')) //隐藏指定的li
		{
			var li = e.children('li');
			li.each(function(i,obj){ if(i > pagings.hides){ $(obj).hide(); }	});
			e.children('.more').show();	e.removeClass('showed');
			$(this).children('img').attr({"title":'展开',"src":img + 'expand.png'});
			pagings.showall = false;
			$('#oper #showall').children('img').attr({"title":'全部展开',"src":img + 'all-expand.png'});
		}else
		{
			e.children('li').show();	e.children('.more').hide();	e.addClass('showed');
			$(this).children('img').attr({"title":'收起',"src":img + 'collapse.png'});
			pagings.showall = true;
			$('#oper #showall').children('img').attr({"title":'全部收起',"src": img + 'all-collapsed.png'});
		}
	});
	
	//展开全部和收起全部按钮事件
	$('#oper #showall').click(function(){
		if(pagings.empty){ return; }
		var ul = $('.page-lists');
		if(pagings.showall) //默认收起全部 单击后展开全部
		{
			pagings.showall = false;
			ul.each(function(i,obj){
				$(obj).children('li').each(function(j,o){
					if(j > pagings.hides){ $(o).hide(); }
				});
				$(obj).children('.more').show();	$(obj).removeClass('showed');
			});
			$(this).children('img').attr({"title":'全部展开',"src":img + 'all-expand.png'});
			$('#oper #isshow').children('img').attr({"title":'展开',"src":img + 'expand.png'});
		}else
		{
			pagings.showall = true;
			ul.each(function(i,obj){
				$(obj).addClass('showed'); $(obj).children('li').show(); $(obj).children('.more').hide();
			});
			$(this).children('img').attr({"title":'全部收起',"src":img + 'all-collapsed.png'});
			$('#oper #isshow').children('img').attr({"title":'收起',"src":img + 'collapse.png'});
		}
	});
	
	//小窗口的关闭按钮事件
	$('#oper #close').click(function(){ $('#oper').fadeOut(); });
});
