
//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };
String.prototype.doubled = function(){ var i = parseInt(this); return i < 10 ? '0' + i : i; };

var global = {};
var timer = '';
//弹出提示浮动层
global.tip = function(err,type)
{
	var errType = type || 'error';
	if(errType == 'error') //错误提示图片设置
	{ 
		$('#err-ico',top.document).attr({"title":'错误',"src":'/points/cross/local/image/error-1.png'});
	}
	if(errType == 'success') //成功提示图片设置
	{
		$('#err-ico',top.document).attr({"title":'成功',"src":'/points/cross/local/image/success-1.png'});
	}
	if(errType == 'warning') //敬告提示图片设置
	{
		$('#err-ico',top.document).attr({"title":'警告',"src":'/points/cross/local/image/warning-1.png'});
	}
	$('#overlay',top.document).show();
	$('#message',top.document).text(err);
	$('#err-ico',top.document).show();
	$('#err',top.document).fadeIn();
	timer = setTimeout(function(){	global.closed(); },10000);
};
//关闭提示浮动层
global.closed = function()
{
	$('#overlay',top.document).fadeOut();
	$('#err-ico',top.document).hide();
	$('#err-ico',top.document).attr('title','');
	$('#err-ico',top.document).attr('src','');
	$('#message',top.document).text('');
	$('#err',top.document).fadeOut();
	clearTimeout(timer);
};

//有限正整数
global.positive = function (n) { return isFinite(n) && n > 0 && n == Math.round(n); };

$(document).ready(function(){
	//浮动层的关闭按钮
	$('#hide-err',top.document).click(function(){ global.closed(); });
});