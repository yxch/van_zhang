
//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };

var global = {};
var timer = '';
//弹出提示浮动层
global.showError = function(err,type)
{
	var errType = type || 'error';
	if(errType == 'error') //错误提示图片设置
	{ 
		$('#err-type',top.document).attr('title','错误');
		$('#err-type',top.document).attr('src','/points/cross/local/image/error-1.png');
	}
	if(errType == 'success') //成功提示图片设置
	{
		$('#err-type',top.document).attr('title','成功');
		$('#err-type',top.document).attr('src','/points/cross/local/image/success-1.png');
	}
	if(errType == 'warning') //敬告提示图片设置
	{
		$('#err-type',top.document).attr('title','警告');
		$('#err-type',top.document).attr('src','/points/cross/local/image/warning-1.png');
	}
	$('#overlay',top.document).show();
	$('#message',top.document).text(err);
	$('#err',top.document).fadeIn();
	timer = setTimeout(function(){	global.closeError(); },8000);
};
//关闭提示浮动层
global.closeError = function()
{
	$('#overlay',top.document).hide();
	$('#err',top.document).fadeOut();
	$('#message',top.document).text('');
	clearTimeout(timer);
};

$(document).ready(function(){
	//浮动层的关闭按钮
	$('#hide-err',top.document).click(function(){ global.closeError(); });
});