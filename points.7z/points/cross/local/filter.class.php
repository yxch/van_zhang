<?php
class filter extends DBO
{
    protected $id;
    protected $name;
    protected $categoryId;
    protected $fieldText;
    protected $searcher;
    protected $select;
    protected $factor;
    protected $rest;
    protected $flag;
    protected $status;
    protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_filters'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'named'=>'name',
                     'cid'=>'categoryId',
                     'flds'=>'fieldText',
                     'scher'=>'searcher',
                     'slt'=>'select',
                     'factor'=>'factor',
                     'rst'=>'rest',
                     'flag'=>'flag',
                     'yes'=>'status',
                     'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'      );
    }
}
