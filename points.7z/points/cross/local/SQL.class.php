<?php
class SQL
{
	//获取当前可用的注册区域信息
	const GetRegionsFromPointsRegions = '
		SELECT id AS id,named AS name,region AS region 
		FROM tb_points_regions
		WHERE yes=1
		ORDER BY  ctime ';
	
	//由id获取注册区域名称和目录
	const GetRegionsFromPointsRegionsById = '
		SELECT named AS name,dir AS directory 
		FROM tb_points_regions
		WHERE yes=1 AND  id=:id ';
	
	//由用户名查询用户信息
	const GetUsersFromPointsUserByUsername = '
		SELECT id AS id, alias AS alias,pwd AS password, tye AS type, yes AS status
		FROM tb_points_users
		WHERE yes = 1 AND usr = :username 	';

	//类别表名
	const TblCategory = 'tb_points_category';
	//查找对应区域id的类别条目
	const GetCategoriesFromPointsCategoryByRegionId = '
		SELECT id AS id, title AS title, md5 AS MD5, aurl AS accessedURL
		FROM tb_points_category
		WHERE rid=:regionId AND yes > 0  ';
	//从类别表中获取数据并分页显示
	const GetPageFromPointsCategory = '
		SELECT id,title AS title, rid AS regionId, murl AS managingURL, aurl AS accessedURL, pos AS position, yes AS status, ctime AS createTime
		FROM tb_points_category
		WHERE yes = 1
		ORDER BY ctime 
		LIMIT :size OFFSET :page ';
	//搜索类别SQL
	const GetInformFromPointsCategoryBySearcher = '
		SELECT id,title AS title, rid AS regionId, murl AS managingURL, aurl AS accessedURL, pos AS position, yes AS status, ctime AS createTime
		FROM tb_points_category
		WHERE yes = 1 AND (title LIKE :title OR murl LIKE :murl OR aurl LIKE :aurl)
		ORDER BY ctime
		LIMIT :size OFFSET :page ';
	//设置类别条目的状态值 即yes的值
	const SetYesInPointsCategory = '
		UPDATE tb_points_category SET yes = 0 
		WHERE id = :id ';

	//由uid获取此uid的权限列表
	const GetPowerListFromPointsPowersByUID = '
		SELECT cid AS categoryId, auth AS authority
		FROM tb_points_powers
		WHERE uid = :uid AND  yes = 1	';

	
}
