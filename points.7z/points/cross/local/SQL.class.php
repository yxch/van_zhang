<?php
class SQL
{
	//区域表
	const TblRegion = 'tb_points_regions';
	//获取当前可用的注册区域信息
	const GetRegionsFromPointsRegions = '
		SELECT id AS id,named AS name,region AS region,dir AS directory
		FROM tb_points_regions
		WHERE yes=1
		ORDER BY  ctime DESC';
	//由id获取注册区域名称和目录
	const GetRegionsFromPointsRegionsById = '
		SELECT named AS name,dir AS directory
		FROM tb_points_regions
		WHERE yes=1 AND  id=:id ';
	//由id获取注册区域权限
	const GetRegionsPowerFromPointsRegionsById = 'SELECT auth AS authority FROM tb_points_regions WHERE yes=1 AND  id=:id ';
	//计算区域条目总数
	const GetCountsFromPointsRegions = 'SELECT COUNT(*) AS total FROM tb_points_regions';
	//获取区域信息
	const GetRegionFromPOintsRegions = '
		 SELECT  id AS id, region AS region,named AS name,auth AS authority,dir AS directory,yes AS yes,mtime AS mtime,ctime AS ctime
		 FROM tb_points_regions
		 ORDER BY ctime DESC
		 LIMIT :size OFFSET :page ';
	//由搜索选项计算区域总数
	const GetCountsFromPointsRegionsBySearch = '
		SELECT COUNT(*) AS total
		FROM tb_points_regions
		WHERE  named LIKE :search OR dir LIKE :search';
	//获取区域信息
	const GetRegionFromPOintsRegionsBySearch = '
		 SELECT  id AS id, region AS region,named AS name,auth AS authority,dir AS directory,yes AS yes,mtime AS mtime,ctime AS ctime
		 FROM tb_points_regions
		 WHERE named LIKE :search OR dir LIKE :search
		 ORDER BY ctime DESC
		 LIMIT :size OFFSET :page ';
	//新建一个区域
	const NewRegionInPointsRegions = 'INSERT INTO tb_points_regions(named,region,auth,dir)VALUES(:named,:region,:auth,:dir)';
	//是否存在此区域
	const GetCountFromPointsRegionsByRegionAndName = '
		SELECT COUNT(*) AS total 
		FROM tb_points_regions
		WHERE region=:region AND named=:named';
	//是否存在此区域
	const GetCountFromPointsRegionsByIdAndName = '
		SELECT COUNT(*) AS total
		FROM tb_points_regions
		WHERE region = (SELECT region FROM tb_points_regions WHERE id=:id) AND named = :named';
	//删除区域
	const DelRegionsFromPointsRegionsById = 'DELETE FROM tb_points_regions WHERE id=:id	';
	
	//用户表
	const TblUsers = 'tb_points_users';
	//由用户名查询用户信息
	const GetUsersFromPointsUserByUsername = '
		SELECT id AS id, alias AS alias,pwd AS password, tye AS type, yes AS status
		FROM tb_points_users
		WHERE  usr = :username ';
	//由uid查询用户信息
	const GetUsersFromPointsUserById = 'SELECT usr AS username,pwd AS password,alias AS alias,email AS email FROM tb_points_users WHERE  id = :id';
	//锁定用户
	const SetUserLockedInPointsUserByUsername = 'UPDATE  tb_points_users SET yes = 0 WHERE id = :id AND usr = :username';
	//计算有效用户总数 分页 users.ajx.php
	const GetCountsFromPointsUsers = 'SELECT  COUNT(*) AS total 	FROM tb_points_users';
	//获取有效的用户记录信息
	const GetUsersFromPointsUsers = '
		SELECT id AS id,usr AS username,alias AS alias,email AS email,ppath AS portrait,tye AS type,yes AS status,mtime AS mtime,ctime AS ctime
		FROM tb_points_users
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page';
	//根据搜索条件计算用户总数 分页
	const GetCountsFromPointsUsersBySearch = '
		SELECT COUNT(*) AS  total 
		FROM tb_points_users
		WHERE  usr LIKE :search OR alias LIKE :search OR email LIKE :search';
	//获取符合搜索条件的用户记录
	const GetUsersFromPointsUsersBySearch = '
		SELECT id AS id,usr AS username,alias AS alias,email AS email,ppath AS portrait,tye AS type,yes AS status,mtime AS mtime,ctime AS ctime
		FROM tb_points_users
		WHERE usr LIKE :search OR alias LIKE :search OR email LIKE :search
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page';
	//获取全部有效用户的部分信息
	const GetUsersSomeFromPointsUsers = 'SELECT id AS id,usr As username,alias As alias FROM tb_points_users	WHERE yes > 0 ';
	//确认是否还存在其它相同的用户名 修改
	const GetCountsFromPointsUsersByIdAndUsername = '
		SELECT COUNT(*) AS total 
		FROM tb_points_users
		WHERE usr = :usr AND id !=:id';
	//确认是否还存在其它相同的用户名 修改
	const GetCountsFromPointsUsersByUsername = 'SELECT COUNT(*) AS total FROM tb_points_users	WHERE usr = :usr';
	//更新用户
	const SetUsersInPointsUsersByUid = 'UPDATE tb_points_users SET usr = :usr,alias = :alias,pwd = :pwd,email = :email WHERE id = :id';
	//新建用户
	const NewUserInPointsUsers = 'INSERT INTO tb_points_users (usr,pwd,alias,email,ppath,tye)VALUES(:usr,:pwd,:alias,:email,:ppath,:tye)';
	//删除(锁定)用户
	const SetYesInPointsUsersById = 'UPDATE tb_points_users SET yes=0 WHERE id=:id'; 
	
	//类别表名
	const TblCategory = 'tb_points_category';
	//查找对应区域id的类别条目
	const GetCategoriesFromPointsCategoryByRegionId = '
		SELECT id AS id, title AS title, md5 AS MD5, tid AS templateId
		FROM tb_points_category
		WHERE rid=:regionId AND yes > 0  ';
	//查询系统类别的总数
	const GetSystemCategoriesCountFromPointsCategory = '	SELECT COUNT(*) AS total FROM tb_points_category WHERE md5 IN(:limit)';
	//删除类别 设置类别条目的状态值 即yes的值
	const SetYesInPointsCategory = '	UPDATE tb_points_category SET yes = 0 WHERE id = :id ';
	//由指定categoryid查询信息
	const GetCategoryFromPointsCategoryById = '
		SELECT rid AS regionId,title AS title,murl AS managingURL,tid AS templateId,pos AS position, yes AS status
		FROM tb_points_category
		WHERE id=:id ';
	//由类别id查询类别的标题
	const GetCategoryTitleFromPointsCategoryById = '	SELECT title AS title FROM tb_points_category WHERE id=:id AND yes > 0	';
	//由md5查询category是否存在
	const GetExistFromPointsCatgoryByMd5 = 'SELECT COUNT(*) AS total FROM tb_points_category WHERE md5 = :md5 AND yes = 1';
	//同一murl下同一区域id只存在一个模板id  修改
	const GetCategoryExistFromPointsCategory = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE id != :id AND md5 = :md5 AND rid = :rid AND tid = :tid	';
	//同一murl下同一区域id只存在一个模板id 新增
	const GetAddCategoryExistFromPointsCategory = '
		SELECT COUNT(*) AS total
		FROM tb_points_category
		WHERE  md5 = :md5 AND rid = :rid AND tid = :tid ';
	//新增一个类别条目
	const NewCategoryInPointsCategory = '
		INSERT  INTO tb_points_category
		(md5,title,rid,murl,tid,pos,yes)
		VALUES(:md5,:title,:rid,:murl,:tid,:pos,:yes)';
	//获取类别（但不包括系统类别）的部分信息
	const GetCategoriesFromPointsCategory = 'SELECT  id AS id, title AS title FROM tb_points_category WHERE md5 NOT IN(:limit)	';
	//计算符合条件的类别总数
	public static function SQLCategoryTotal($oper='=',$search=FALSE)
	{
		$where = ' WHERE yes ' . $oper . ' :yes' . ($search ? ' AND (title LIKE :search OR murl LIKE :search  )' : '');
		return 'SELECT COUNT(*) AS total FROM tb_points_category ' . $where;
	}
	//获取符合条件的类别信息
	public static function SQLCategoryList($oper='=',$search=FALSE)
	{
		$where = ' WHERE yes ' . $oper . ':yes' . ($search ? ' AND (title LIKE :search OR murl LIKE :search  )' : '');
		return 'SELECT id,title AS title, rid AS regionId, murl AS managingURL, tid AS templateId, pos AS position, yes AS status, ctime AS createTime 
			        FROM tb_points_category' . 
			   $where . 
			   ' ORDER BY ctime DESC LIMIT :size OFFSET :page ';
	}
	
	//权限表
	const TblPowers = 'tb_points_powers';
	//由uid获取此uid的权限列表
	const GetPowerListFromPointsPowersByUID = '
		SELECT cid AS categoryId, auth AS authority
		FROM tb_points_powers
		WHERE uid = :uid AND  yes = 1	';
	//计算全部权限条目数
	const GetCountsFromPointsPowers = 'SELECT COUNT(*) AS total FROM tb_points_powers	';
	//获取权限信息
	const GetPowersFromPointsPowers = '
		SELECT id AS id, uid AS uid, cid AS cid,ctle AS categoryTitle,auth AS authority,yes AS yes,mtime AS mtime,ctime AS ctime
		FROM tb_points_powers
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page  ';
	//由搜索选项计算权限的总数
	const GetCountsFromPointsPowersBySearch = '
		SELECT COUNT(*) AS total 
		FROM tb_points_powers	
		WHERE uid =  :uid OR cid = :cid OR ctle LIKE :search	';
	//获取权限信息
	const GetPowersFromPointsPowersBySearch = '
		SELECT id AS id, uid AS uid, cid AS cid,ctle AS categoryTitle,auth AS authority,yes AS yes,mtime AS mtime,ctime AS ctime
		FROM tb_points_powers
		WHERE uid =  :uid OR cid = :cid OR ctle LIKE :search
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page  ';
	//删除权限
	const DelPowerInPointsPowersById = 'DELETE FROM tb_points_powers WHERE id=:id';
	//新建权限
	const NewPowerInPointsPower = 'INSERT INTO tb_points_powers(uid,cid,ctle,auth)VALUES(:uid,:cid,:ctitle,:auth)';

	//模板表
	const TblTemplate = 'tb_points_template';
	//获取全部模板文件
	const GetTemplatesFromPointsTemplate = '
		SELECT id AS id,title AS title, path AS path,tag AS tag	
		FROM tb_points_template 
		WHERE tag > 0
		ORDER BY ctime DESC ';
	//列出多个模板id的详细信息
	const GetTemplatesFromPointsTemplateByIds = 'SELECT id AS id,path AS path FROM tb_points_template WHERE tag > 0 AND id IN(:limit)	';
	//标注模板为废弃
	const SetTagInPointsTemplateById = 'UPDATE tb_points_template SET tag = 0 WHERE id = :id';
	//确认是否有同名的模板
	const GetCountFromPointsTemplateByIdTitleMd5 = '
		SELECT COUNT(*) AS total
		FROM tb_points_template
		WHERE title = :title  AND md5 = (SELECT md5 FROM tb_points_template WHERE id = :id)';
	//确认是否有同名的模板
	const GetCountFromPointsTemplateByTitleMd5 = '
		SELECT COUNT(*) AS total
		FROM tb_points_template
		WHERE title = :title  AND md5 = :md5';
	//由md5查询此模板文件是否存在
	const GetExistFromPointsTemplateByMd5 = 'SELECT COUNT(*) AS total FROM tb_points_template	WHERE md5 = :md5';
	//由md5查询模板文件的内容
	const GetTemplateFromPointsTemplateByMd5 = 'SELECT id AS id FROM tb_points_template WHERE md5 = :md5';
	//新建模板
	const NewTemplateInPointsTemplate = 'INSERT INTO tb_points_template(title,md5,path,layer,tag)VALUES(:title,:md5,:path,:layer,:tag)';
	//计算符合条件的模板总数
	public static function SQLTemplateTotal($oper='=',$search=FALSE)
	{
		$where = ' WHERE tag ' . $oper . ' :tag' . ($search ? ' AND (  title LIKE :search OR path LIKE :search )' : '');
		return 'SELECT COUNT(*) AS total FROM tb_points_template ' . $where;
	}
	//获取符合条件的模板信息
	public static function SQLTemplateList($oper='=',$search=FALSE)
	{
		$where = ' WHERE tag ' . $oper . ':tag' . ($search ? ' AND (title LIKE :search OR path LIKE :search  )' : '');
		return 'SELECT id AS id,title AS title,path AS path,layer AS layer,tag AS tag,mtime AS mtime,ctime AS ctime 
			        FROM tb_points_template' . 
			   $where . 
			   ' ORDER BY ctime DESC LIMIT :size OFFSET :page ';
	}
	
	//变量表
	const TblVariable = 'tb_points_variables';
	//计算指定管理标识符的变量条目
	const GetCountsFromPointsVariablesByMd5 = 'SELECT COUNT(*) AS total	FROM tb_points_variables WHERE pos = :md5';
	//由id获取变量的字段内容
	const GetVariableFromPointsVariablesById = '
		 SELECT  named AS name,val AS value,url AS url,note AS note,txt AS text,rule AS rule,tag AS status,tye AS type
		 FROM tb_points_variables
		 WHERE id = :id	';
	//由id获取变量的字段内容
	const GetVarsFromPointsVariablesById = '
		 SELECT  named AS name,pos AS md5,note AS note,tag AS status
		 FROM tb_points_variables
		 WHERE id = :id	';
	//由id获取变量的校验规则
	const GetVarRuleFromPointsVariablesById = ' SELECT  rule AS rule	 FROM tb_points_variables  WHERE id = :id AND yes > 0';
	//向变量表中插入变量
	const NewVariablesInPointsVariables = '
		INSERT INTO tb_points_variables
		(named,val,pos,url,note,txt,tag,rule,tye)
		VALUES(:name,:value,:pos,:url,:note,:text,:tag,:rule,:type)	';
	//删除变量
	const DelVariableInPointsVariable = 'DELETE FROM tb_points_variables WHERE id=:id	';
	//由管理标识符的md5查询变量信息
	const GetVarsFromPointsVariableByMd5 = '
		SELECT  id  AS id,val AS value,note AS note,txt AS text,tye AS type
		 FROM tb_points_variables
		 WHERE pos = :pos AND  tag = 2
		 ORDER BY ctime DESC ';
	//更新变量
	const SetVarInPointsVarablesById = '	UPDATE tb_points_variables SET val = :val WHERE id = :id';

	//计算符合条件的模板总数
	public static function SQLVarsTotal($oper='=',$search=FALSE)
	{
		$where = ' WHERE tag ' . $oper . ' :tag' . ($search ? ' AND (named LIKE :search OR note LIKE :search  OR url LIKE :search)' : '');
		return 'SELECT COUNT(*) AS total FROM tb_points_variables ' . $where;
	}
	//获取符合条件的模板信息
	public static function SQLVarsList($oper='=',$search=FALSE)
	{
		$where = ' WHERE tag ' . $oper . ':tag' . ($search ? ' AND (named LIKE :search OR note LIKE :search  OR url LIKE :search)' : '');
		return 'SELECT id AS id,named AS name,val AS value,url AS url,note AS note,txt AS text,tag AS status,rule AS rule,tye AS type
			        FROM tb_points_variables' . 
			   $where . 
			   ' ORDER BY ctime DESC LIMIT :size OFFSET :page ';
	}
	
	//数据过滤器
	const TblFilter = 'tb_points_filters';
	//新建一个过滤器条目
	const NewFilterInPointsFilters = '
		INSERT INTO  tb_points_filters(named,cid,flds,slt,flag)
		VALUES(:name,:cid,:fields,:select,:flag) 	';
	//由flag查询过滤器是否已创建
	const GetFilterFromPointsFiltersByFlag = 'SELECT COUNT(*) AS total FROM tb_points_filters WHERE cid = :cid AND flag = :flag';
	//由flag和id查询过滤器是否已创建
	const GetFilterFromPointsFiltersByFlagId = 'SELECT COUNT(*) AS total FROM tb_points_filters WHERE cid = :cid AND flag = :flag AND id != :id';
	//由搜索选项计算条目总数
	const CountFiltersFromPointsFilterBySearch = '
		SELECT COUNT(*) AS total 
		FROM tb_points_filters
		WHERE yes  > 0 AND named LIKE :name		';
	//由搜索选项获取过滤器信息
	const GetFilterFromPointsFiltersBySearch = '
		SELECT id AS id,named AS name,cid AS cid,flds AS fields,slt AS statement,rst AS rest,yes AS status,mtime AS mtime, ctime AS ctime
		FROM tb_points_filters
		WHERE  named LIKE :name
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page		';
	//计算有效过滤器的条目总数
	const CountFiltersFromPointsFilter = 'SELECT COUNT(*) AS total FROM tb_points_filters WHERE yes > 0 ';
	//获取过滤器信息
	const GetFiltersFromPointsFilters = '
		SELECT id AS id,named AS name,cid AS cid,flds AS fields,slt AS statement,rst AS rest,yes AS status,mtime AS mtime, ctime AS ctime
		FROM tb_points_filters
		ORDER BY ctime DESC
		LIMIT :size OFFSET :page	';
	//由id获取过滤器信息
	const GetFitlerFromPointsById = '
		SELECT named AS name,cid AS cid,flds AS fields,slt AS statement,rst AS rest,yes AS status
		FROM tb_points_filters
		WHERE id = :id 
		ORDER BY ctime DESC		';
	//由id更新过滤器
	const SetFilterInPointsFilterById = '
		UPDATE tb_points_filters SET  
		named = :name,cid = :cid,flds = :fields,slt = :select,flag = :flag,yes = :status,mtime = :mtime
		WHERE id = :id	';
	//由id删除过滤器
	const DelFiltersInPointsFiltersById = 'DELETE FROM tb_points_filters WHERE id=:id';
	//由类别id获取过滤器的id和标题
	const GetFilterFromPointsFiltersByCid = 'SELECT id AS id, named AS name	FROM tb_points_filters WHERE yes > 0 AND cid = :cid';
	//由过滤器id查询过滤器信息
	const GetFilterFromPointsFiltersById = 'SELECT flds AS fields,slt AS statement,rst AS rest	FROM tb_points_filters WHERE  id = :id ';
}
