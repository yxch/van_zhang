<?php
class category extends DBO
{
    protected $id;
    protected $MD5;
    protected $title;
    protected $regionId;
    protected $managingURL;
    protected $accessedURL;
    protected $position;
    protected $status;
    protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_category'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'md5'=>'MD5',
                     'title'=>'title',
                     'rid'=>'regionId',
                     'murl'=>'managingURL',
                     'aurl'=>'accessedURL',
                     'pos'=>'position',
                     'yes'=>'status',
                     'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'     );
    }
}
