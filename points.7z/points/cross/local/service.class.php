<?php
class service extends DBO
{
    protected $id;
    protected $xianFeng;
    protected $heXie;
    protected $tianLi;
    protected $huoBi;
    protected $lingDong;
    protected $ruiQu;
    protected $chengZhang;
    protected $postTime;
    
    protected function definedTableName(){ return 'tb_check_price'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'xianfeng_a'=>'xianFeng',
                     'hexie_a'=>'heXie',
                     'tianli_a'=>'tianLi',
                     'huobi_a'=>'huoBi',
                     'lingdong_a'=>'lingDong',
                     'ruiqu_a'=>'ruiQu',
                     'chengzhang'=>'chengZhang',
                     'post_time'=>'postTime'               );
    }
}
