<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    if(ctype_digit($_POST['item']))
    {
        $_SESSION['points']['item']['id'] = $_POST['item'];
        echo 1; exit;
    }
    echo 0; exit;