<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<?php echo points::head(0); ?>
		<link rel="stylesheet" href="/points/cross/local/css/initialization.css" />
	</head>
	<body>
		<div id="initialization">
			<p id="error"><i><img src="/points/cross/local/image/error-1.png" /></i><label>错误</label></p>
			<p>检测到系统重要组件不正常或者丢失，点击<label> 立即修复 </label>将自动修复这些错误，是否要立即执行？</p>
			<p id="repaired"><a id="repair">立即修复</a></p>
		</div>
		<script>
			$('#repair').click(function(){
				$.get('initialization.ajx.php',function(r){  console.log(r);
					$('#repair').text('正在修复一些错误，请稍候......');
					$('#repair').attr('id','');
					var j = $.parseJSON(r);
					setTimeout(function(){
						if(j.status == '1')
						{
							$('#repaired a').attr('id','go');
							$('#go').text('已成功修复这些错误　确定');
							$('#go').click(function(){
								top.document.location.href="/points/usr/login/ask/loginout.inc.php";
							});
						}else{ $('#repaired a').text('修复失败，请注销后重试！'); }
					},4000);
				});
			});
		</script>
	</body>
</html>

