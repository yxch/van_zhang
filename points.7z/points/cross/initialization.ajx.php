<?php
	require_once $_SERVER['DOCUMENT_ROOT'].'/points/loader.inc.php';
	
	$back = ['status'=>0,'error'=>'unkonw error'];
	
	//新建 一个区域
	$regions = [':named'=>'设置中心',':region'=>'2',':auth'=>MAXAUTH,':dir'=>'/points/usr/master/'];

	//确认区域是否存在
	$exist = DBC::selected(SQL::GetCountFromPointsRegionsByRegionAndName,[':region'=>$regions[':region'],':named'=>$regions[':named']],['one'=>TRUE]);
	if($exist['total'] > 0)
	{
		$back['erro'] = '初始化区域时失败，区域已存在';
		points::jan($back);
	}
	
	$regionId = DBC::modified(SQL::NewRegionInPointsRegions,$regions,['LID'=>TRUE]);
	if($regionId > 0)
	{
		//初始化系统管理模板文件
		$vsys = points::vsys();
		$inserts = [];
		$i = 0;  $arr = [];
		foreach($vsys AS $k=>$ar)
		{
			//确认此md5是否存在  循环查询，仅在初始化或出错时操作且循环次数不超过8次 ???
			$arr[':md5'] = md5($ar['turl']);
			$exec = DBC::selected(SQL::GetExistFromPointsTemplateByMd5,$arr,['one'=>TRUE]);
			if($exec['total'] == 0)
			{
				$inserts[$i][':title'] = $ar['template'];
				$inserts[$i][':md5'] = $arr[':md5'];
				$inserts[$i][':path'] = $ar['turl'];
				$inserts[$i][':layer'] = '';
				$inserts[$i][':tag'] = '1';
				$i++;
			}
		}
		//插入数据
		if(DBC::modified(SQL::NewTemplateInPointsTemplate,$inserts) > 0)
		{
			//获取类别管理器的tid
			$template = DBC::selected(SQL::GetTemplateFromPointsTemplateByMd5,[':md5'=>md5($vsys['category']['turl'])],['one'=>TRUE]);
			//插入系统必要的类别组件
			$category = ['md5'=>md5($vsys['category']['murl']),':title'=>$vsys['category']['title'],
				         ':rid'=>$regionId,':murl'=>$vsys['category']['murl'],':tid'=>$template['id'],
				         ':pos'=>'1',':yes'=>1	];

			if(DBC::modified(SQL::NewCategoryInPointsCategory,$category))
			{
				//使初始化用户成为第一个超级用户
				$points = parse_ini_file(SYSINI . 'pointer.ini',true);
				$usersInfo = array(':usr'=>$_SESSION[TAG]['user']['username'],
		               ':alias'=>$points['alias'],
		               ':pwd'=>$points['password'],
		               ':email'=>$points['email'],
					   ':ppath'=>'',
		               ':tye'=>$points['type']		);
				if(DBC::modified(SQL::NewUserInPointsUsers,$usersInfo))
				{
					$back['status'] = 1;
					$back['error'] = '';
				}
			}
		}
	}
	points::jan($back);
	exit;
	
	
