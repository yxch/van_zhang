<?php
class GEN
{
	/**
	 *得到数组类型 索引数组 混合数组 关联数组 函数名称由getArrayType 改成 type
	 *@param array $arr
	 *@return -1 不是一个数组 0空数组 1索引数组 2 关联数组 3 混合数组
	 */
	public static function typed($arr)
	{
		if(!is_array($arr)){ return -1;} //如果不是一个数组 返回-1
		if(empty($arr)) { return 0;} //空数组无意义
		$t = count($arr);
		$intersect = array_intersect_key($arr,range(0,$t-1)); //求两个数组的交集
		if(count($intersect) == $t) {  return 1;  }elseif(empty($intersect)) {  return 2; }else { return 3; }
	} 

	/**
	 *本函数用来在php文件中实现跳转
	 *@param string $url
	 *@return string 
	 */
	public static function JSGO($url)
	{
		$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://';
		$url = preg_match("/^(http:\/\/)|(https:\/\/)|(ftp:\/\/).*$/i",$url) ? $url : $protocol . $url;
		echo "<script language=\"javascript\">window.top.document.location=\"$url\"</script>";
		exit();
	}

	//获取主机地址(包含协议)
	public static function PHOST()
	{	
		return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'];
	}

	//获取url中完整的path部分 如http://www.sample.com/samples/aaa/bbb/
	public static function UPATH()
	{
		$PHPSELF = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		$short = strtr($PHPSELF,array(basename($PHPSELF)=>''));
		return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'] . $short;
	}

	//获取完整的文件路径
	public static function UFILE()
	{
		$PHPSELF = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !='off' ) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'] . $PHPSELF;
	}

	/**
	 *本函数用来根据文件完整路径输出文件可读的文件大小，（当前仅支持TB级）
	 *@param int $filename  文件的完整路径 注意在非GB2312的编码下无法识别，因此文件名最好不要是中文
	 *@return string $size 返回文件大小或者假
	 */
	public static function fsize($filename)
	{
		if(!file_exists($filename)){ return 0;}
		$size = filesize($filename);
		if($size > pow(2,40))		 	$size = round($size/pow(2,40),2) . 'TB';
		elseif($size >= pow(2,30)) 		$size = round($size/pow(2,30),2) . 'GB';
		elseif($size >= pow(2,20)) 		$size = round($size/pow(2,20),2) . 'MB';
		elseif($size >= pow(2,10)) 		$size = round($size/pow(2,10),2) . 'KB';
		else				     	 	$size = $size . 'byte';
		return $size;
	}

	/*
	 * CURL 远程资源请求  post
	 * @param string $url  远程地址 
	 * @param array  提交的数据
	 * 返回请求的资源
	 */
	public static function cpost($url,array $data) 
	{
		//如果提供了空的url或post参数 返回空值
        if (empty($url) || empty($data)) { return NULL; }

		//组合请求的数据
		$posts = http_build_query($data);

        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_SSLVERSION, 1);        
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_URL,$url);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header 如果设置为1时则返回头信息 通常不需要
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $posts);
		curl_setopt($ch, CURLOPT_TIMEOUT,30);
        $res = curl_exec($ch);//运行curl
        curl_close($ch);
        return $res;
    }
	
	/*
	 * CURL 远程资源请求 get
	 * @param string $url  远程地址 
	 * 返回请求的资源
	 */
	public static function cget($url)
	{
		if(empty($url)){ return ''; }
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL,$url);//设置请求的url
		//设置头文件的信息作为数据流输出 如果设置为1时则返回头信息 通常不需要
		curl_setopt($curl, CURLOPT_HEADER,0); 
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//设置获取的信息以文件流的形式返回，而不是直接输出。
		curl_setopt($curl, CURLOPT_TIMEOUT,30);
		$data = curl_exec($curl);
		curl_close($curl);		//print_r($data);
		return $data; //显示获得的数据
	}
	
}
