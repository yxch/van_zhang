<?php
/**
 *@author:van_zhang 
 *@date:2015/04/20
 *@version:1.0
 *
 *加密类
 *如果使用此类加或解密url字符串
 *请在加密后使用STR::URLCode($string)处理加密后的字符串，
 *请在解密前使用STR::URLCode($string,false)处理加密后的字符串
 *注：解密和加密必须使用相同的算法、密钥及模式，否则无法解密
 *目前此类仅支持四种算法 3DES DES RIJNDAEL128 RIJNDAEL256,可以稍加修改支持更多算法
 */
class MCR
{
  private $strings = 'abcUVdefghij3knDGHo1pqrs2tuvwx456789yzABCIJKlEFmLMNO0PQRSTWXYZ';
  private $sKey = '';
  private $sArithmetic = MCRYPT_3DES; //算法默认值
  private $sMode = 'cbc'; //默认的加密模式
  
  /**
   *如果在配置文件和_construct中均没有指相关参数，则此类的加密使用默认的key 3DES cbc加密
   *通常建议在配置文件中指定这些参数
   * @param $opt = array('key'=>'','arithmetic'=>'','mode'=>'') 约定键名
   */
  public function __construct(array $opt=null)
  {
    //读取websites.ini
    $arConfig = GEN::CFG(ETC . 'website.ini','MCRYPT');  //GEN::look($arConfig);
    //key声明 使用默认值
    $this->sKey = md5($this->strings);
    //key声明 配置文件中的key
    if(isset($arConfig['key']) && !empty($arConfig['key'])){ $this->sKey = $arConfig['key']; }
    //key声明 用户提供了key
    if(isset($opt['arithmetic']) && !empty($opt['arithmetic'])){ $this->sKey = $opt['key']; }
    
    //arithmetic声明 配置文件中的arithmetic
    if(isset($arConfig['arithmetic']) && !empty($arConfig['arithmetic'])){ $this->sArithmetic = $this->arithmeticRelations($arConfig['arithmetic']); }
    //arithmetic声明 用户提供了arithmetic
    if(isset($opt['arithmetic']) && !empty($opt['arithmetic'])){ $this->sArithmetic = $this->arithmeticRelations($opt['arithmetic']); }
    
    //mode 配置文件中的mode
    if(isset($arConfig['mode']) && !empty($arConfig['mode'])){ $this->sMode = $arConfig['mode']; }
    //mode 用户提供了mode
    if(isset($opt['mode']) && !empty($opt['mode'])){ $this->sMode = strtolower($opt['mode']); }
    
    //GEN::look($this->sArithmetic);
    //GEN::look($this->sMode);
  }
  //加密明文
  public function encrypt($text)
  {
    //填充
    if($this->sArithmetic == 'des') $text = $this->_pkcs5Pad($text);
    //加密
    $resource = mcrypt_module_open($this->sArithmetic,'',$this->sMode, '');
    $vector = base64_encode(@mcrypt_create_iv (mcrypt_enc_get_iv_size($resource), MCRYPT_RAND));    
    @mcrypt_generic_init($resource,$this->sKey,$vector);
    $ret = mcrypt_generic($resource,$text);                                   
    mcrypt_generic_deinit($resource);
    mcrypt_module_close($resource);
    //保存vector及长度到ret中以备解密使用
    $ret = $vector . base64_encode($ret); //. strlen($vector);      
    return $ret;
  }
  //解密密文
  public function decrypt($text)
  {
    //提取vector
    $vector = substr($text,0,$this->getVectorLen());
    //提取密文并反编码
    $text = base64_decode(substr($text,$this->getVectorLen()));
    
    $resource = mcrypt_module_open($this->sArithmetic,'',$this->sMode,'');
    @mcrypt_generic_init($resource,$this->sKey,$vector);
    $decryptedText = mdecrypt_generic($resource,$text);                      
    mcrypt_generic_deinit($resource); 
    mcrypt_module_close($resource);  
    return $this->sArithmetic == 'des' ? $this->_pkcs5Unpad($decryptedText) : $decryptedText;    
  }
  //填充
  private function _pkcs5Pad($text)
  {  
    $blocksize = mcrypt_get_block_size($this->sArithmetic, $this->sMode); 
    $pad = $blocksize - (strlen($text) % $blocksize);
    return $text . str_repeat(chr($pad),$pad);  
  }  
  //反填充
  private function _pkcs5Unpad($text)
  {  
    $pad = ord($text{strlen($text) - 1});  
    if ($pad > strlen($text)) return false;  
    if (strspn($text, chr($pad), strlen($text) - $pad) != $pad) return false;  
    $ret = substr($text, 0, -1 * $pad);  
    return $ret;  
  }
  //映射集
  private function arithmeticRelations($sArithmetic)
  {
    $ar = array(
                'DES'=>MCRYPT_DES,
                '3DES'=>MCRYPT_3DES,
                'RIJNDAEL128'=>MCRYPT_RIJNDAEL_128,
                'RIJNDAEL256'=>MCRYPT_RIJNDAEL_256
                );
    return $ar[$sArithmetic];
  }
  //得到向量长度
  private function getVectorLen()
  {
    $ar = array('des'=>12,'tripledes'=>12,'rijndael-128'=>24,'rijndael-256'=>44);
    return $ar[$this->sArithmetic];
  }
}
?>