<?php
	//header("Content-type:text/html;charset=utf-8");
	date_default_timezone_set('Asia/Urumqi');  //设置时区

	define('RPH',rtrim($_SERVER['DOCUMENT_ROOT'],'/') . '/');//定义根路径  
	define('CPH','points/'); //定义当前目录路径

	define('SPH',RPH . CPH);				//程序起始路径
	define('BASES',SPH . 'bases/');		//通用类所在目录
	define('LOCAL',SPH . 'cross/local/');	//项目类所在目录
	define('SYSINI',BASES . 'etc/');		//配置文件所在目录
	define('TPL',SPH . 'cross/template/');		//模板所在路径
	define('IMAGE','/points/cross/local/image/');	//项目图像图标文件路径

	define('DEMO',FALSE); //是否是演示程序
	//是否是测试环境 以下判断仅适用于招商信诺
	define('TEST',stripos($_SERVER['HTTP_HOST'],'.cigna') === FALSE ||
				stripos($_SERVER['HTTP_HOST'],'test.cigna') !== FALSE);
	//定义基本的访问路径和前缀
	define('PHOST', TEST ? 'http://10.140.130.35' : 'http://www.cignacmb.com' ); 
	define('BASIC',  PHOST . '/' . CPH);
	//define('_SESSION',SLIB . 'SSN.class.php');  //将session写入数据库的自定义函数文件

	//如果是演示程序或测试环境，打开全部错误提示否则关闭
	error_reporting( DEMO || TEST ? E_ALL : 0);

	spl_autoload_register('loader'); //注册系统类
	function loader($class)
	{
		//使基目录下的公共类可用
		if(defined('BASES') && file_exists(BASES.$class.'.class.php'))
		{ 
			include_once BASES.$class.'.class.php'; 
		}
		//使项目目录下的项目类可用 
		if(defined('LOCAL') && file_exists(LOCAL.$class.'.class.php'))
		{ 
			include_once LOCAL.$class.'.class.php'; 
		}
	}
	
	//通用的session启用方式, 将session写入数据库表tb_points_session
	SSN::start(DBC::PDO(),array('sname'=>'points','lifeTime'=>86400,'updateTime'=>30,'divisor'=>10));
	//本项目定义的最大权限和最小权限值
	define('MAXAUTH','1111111111');
	define('MINAUTH','1000000000');
	//确保用户不是非法访问的校验文件
	define('ACCESSIBLED',SPH . 'usr/login/ask/accessible.inc.php');