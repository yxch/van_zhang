$(document).ready(function(){
    var page = 1;
    var ask = 'ask/users.ajx.php';
    grid(ask,{"page":page});
    
    //通用函数，为表格的行加载单击事件，来动态显示用户是否选中
    $('#grids tbody').delegate('tr','click',f._trClick);
    
    var err = document.getElementById('err');
    var td = $('#grids tfoot tr td');
    
    //初始化弹窗的大小和遮罩层的大小
    f.pop();
    $(window).resize(function(){  f.pop();  f.overlay(); });
    
    var modify = false;
    var add = false;
    
    //编辑用户
    var vs = {}; //保存初始值
    td.delegate('#edit','click',function(){ 
        var tr = $('#grids tbody .checked');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        if (tr.length > 1) { err.innerHTML = '一次只能编辑一个条目'; return; }
        err.innerHTML = '';
        //取消tr的单击事件
        $('#grids tbody').undelegate('tr','click',f._trClick);
        if(modify){ return false; }
        
        //修改用户呈现
        $('#grids .checked td').each(function(i,obj){
            var td = $(obj);
            var v = td.text();
            var attr = td.attr('user');
            if(attr == 'id'){ vs.id = td.text(); } //保存初始值
            if (td.hasClass('editable'))
            {
                if (attr == 'username')
                {
                    td.html('<input id="username" class="transparent" value="' + v + '" />');
                    vs.username = v;
                }
                if (attr == 'alias')
                {
                    td.html('<input id="alias" class="transparent" value="' + v + '" />');
                    vs.alias = v;
                }
                if (attr == 'email')
                {
                    td.html('<input id="email" class="transparent" value="' + v + '" />');
                    vs.email = v;
                }
                if (attr == 'portrait')
                {
                    td.html('<input id="portrait" class="transparent" value="' + v + '" />');
                    vs.portrait = v;
                }
                if (attr == 'type')
                {
                    var r = {"前端页面":1,"后台页面":2,"全局用户":3,"超级用户":9};
                    td.html('<select id="type" class="transparent"><option value="1">前端页面</option><option value="2">后台页面</option><option value="3">全局用户</option><option value="9">超级用户</option></seclect>');
                    $('#type').val(r[v]);
                    vs.type = r[v]; //保存原始值
                }
                if (attr == 'status')
                {
                    var r = {"启用":1,"废弃":0};
                    td.html('<select id="status" class="transparent"><option value="1">启用</option><option value="0">废弃</option></seclect>');
                    $('#status').val(r[v]);
                    vs.status = r[v]; //保存原始值
                }
            }
        });
        modify = true;
    });
    
    //应用按钮
    var applied = {}; 
    td.delegate('#applied','click',function(){ 
        //应用编辑
        var checked = $('#grids tbody .checked'); 
        var addings = $('#grids tbody .adding'); 
        if (checked.length == 0 && addings.length == 0){ err.innerHTML = '编辑或者新增操作请求'; return; }
        //修改
        if (checked.length == 1 && addings.length == 0)
        {
            if(modify){var tds = $('#grids tbody .checked td');}else{ err.innerHTML = '编辑操作请求'; return; }
        }
        //新增
        if(addings.length == 1){ var tds = $('#grids tbody .adding td'); }
        //获取值
        tds.each(function(i,obj){
            var td = $(obj);
            var attr = td.attr('user');
            if(attr == 'id' && modify){ applied.id = td.text();}
            if(attr == 'username'){ applied.username = $('#username').val();}
            if(attr == 'alias'){ applied.alias = $('#alias').val();}
            if(attr == 'email'){ applied.email = $('#email').val();}
            if(attr == 'portrait'){ applied.portrait = $('#portrait').val();}
            if(attr == 'type'){ applied.type = $('#type').val();}                
            if(attr == 'status'){ applied.status = $('#status').val();}                
        });
        
        //验证值
        if (modify && applied.id.empty()) { err.innerHTML = '修改ID未正确提供'; return false; }
        if (applied.username.empty()) { err.innerHTML = '用户名不能为空不建议中文'; return false; }
        
        err.innerHTML = '';
        //弹出密码填写框
        f.overlay().show();
        $('#pop').show();      
    });
    
    //弹窗的确定按钮
    $('#ensure').click(function(){ 
        var isChange = document.getElementById('pwd').checked;
        if (!isChange)
        {
            var pwd1 = $('#pwd1').val();
            var pwd2 = $('#pwd2').val();
            if (pwd1.empty()){ $('#error').text('密码不能为空强密码求'); return false; }
            if (pwd2.empty()){ $('#error').text('没有确认密码'); return false; }
            if (pwd1 !== pwd2) { $('#error').text('两次密码不一致'); return false; }
            $('#error').text('');
            applied.password = pwd1;
        
        }else{ if(applied.password){ delete applied["password"];} }
        
        $.post('ask/users.save.ajx.php',applied,function(r){
            var j = $.parseJSON(r);
            if (j.status == 1)
            {
                $('#pop').fadeOut();
                f.overlay().fadeOut();
                grid(ask,{"page":page});
                $('#grids tbody').delegate('tr','click',f._trClick);
                modify = false;
            }
            $('#error').text(j.err);
        });
    });
    //是否使用原密码，即不更改密码
    $('#pwd').click(function(){
        if (document.getElementById('pwd').checked)
        {
            $('#pwd1').val('');
            $('#pwd1').attr('disabled','disabled');
            $('#pwd2').val('');
            $('#pwd2').attr('disabled','disabled');
        }else
        {
            $('#pwd2').attr('disabled',false);
            $('#pwd1').attr('disabled',false);
        }
    });
    
    //增加用户
    $('#grids tfoot tr td').delegate('#add','click',function(){
        $('#loading').hide();
        var checks = $('#grids .checked');
        if (checks.length > 0) { err.innerHTML = '正在编辑条目,不能同时增加新条目！'; return false;}
        var adding = $('#grids tbody .adding');
        if (adding.length == 0)
        {
            err.innerHTML = '';
            var tr = '<tr class="adding"><td user="id"></td><td user="username"><input id="username" class="transparent" value="" /></td><td user="alias"><input id="alias" class="transparent" value="" /></td><td user="email"><input id="email" class="transparent" value="" /></td><td user="portrait"><input id="portrait" class="transparent" value="" /></td><td user="type"><select id="type" class="transparent"><option value="1">前端页面</option><option value="2">后台页面</option><option value="3">全局用户</option><option value="9">超级用户</option></seclect></td>   <td user="status"><select id="status" class="transparent"><option value="1">启用</option><option value="0">停用</option></seclect></td><td></td></tr>'
            $('#grids tbody tr:first-child').before(tr);
            
        }else{ err.innerHTML = '一次仅能增加一个条目,请先应用后再增加'; }
        add = true;
    });
    
    //删除用户
    $('#grids tfoot tr td').delegate('#delete','click',function(){
        var tr = $('#grids tbody .checked');
        var err = document.getElementById('err');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        err.innderHTML = '';
        var id = [];
        tr.each(function(i,obj){ id.push($(obj).find(':first-child').text()); });
        if (window.confirm('你确定要删除这些条目吗？'))
        {
            $.post('ask/users.delete.ajx.php',{"id":id.join('|')},function(r){
                var j = $.parseJSON(r);
                if (j.status)
                {
                    grid(ask,{"page":page});
                    $('#grids tbody').delegate('tr','click',f._trClick);
                }
                $('#err').text(j.message);
            });        
        }
    });
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#fpage').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
    
    function grid(url,json)
    {
        var num = parseInt(json.page) || 1;
        $.post(url,json,function(r){
            var j = $.parseJSON(r);
            var status = parseInt(j.status);
            var empty = '加载数据失败或者没有可用数据,请稍候重试！';
            if (status == 1)
            {
                page = j.page;
                $('tbody').html(j.tbody);
                $('#oper').html(j.operations);
                $('#fpage').html(paging(j).show());
            }
            
            if (status == 2)
            {
                $('#grids tbody #loading td').html(empty);
                $('#oper').html(j.operations);
                $('#fpage').html('&nbsp');
                setTimeout(function(){$('#grids tbody #loading td').html(empty);},6000);
            }
        });
    }
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v}); }
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v});
    });

});
