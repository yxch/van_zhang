$(document).ready(function(){
    var page = 1;//默认显示第一页
    var ask = 'ask/power.ajx.php';
    grid(ask,{"page":page});
    
    //通用函数，为表格的行加载单击事件，来动态显示用户是否选中
    $('#grids tbody').delegate('tr','click',f._trClick);
    
    var err = document.getElementById('err');
    var td = $('#grids tfoot tr td');
    
    //初始弹窗的大小和遮罩层的大小
    f.pop();
    $(window).resize(function(){  f.pop();  f.overlay(); });
    
    var modify = false;    
    //编辑权限
    var vs = {}; //保存初始值
    td.delegate('#edit','click',function(){ 
        var tr = $('#grids tbody .checked');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        if (tr.length > 1) { err.innerHTML = '一次只能编辑一个条目'; return; }
        err.innerHTML = '';
        //取消tr的单击事件
        $('#grids tbody').undelegate('tr','click',f._trClick);
        if(modify){ return false; }        
        
        //修改用户呈现
        $('#grids .checked td').each(function(i,obj){
            var td = $(obj);
            var v = td.text();
            var attr = td.attr('power');
            if(attr == 'id'){ vs.id = td.text(); } //保存初始值
            if (td.hasClass('editable'))
            {
                if (attr == 'authority')
                {
                    td.html('<input id="authority" class="transparent" value="' + v + '" />');
                    vs.authority = v;
                    $('#authority').focus(function(){
                        //弹出权限选择框
                        f.overlay().show();  $('#pop').show();      
                    });
                }
                if (attr == 'status')
                {
                    var r = {"启用":1,"废弃":0};
                    td.html('<select id="status" class="transparent"><option value="1">启用</option><option value="0">废弃</option></seclect>');
                    $('#status').val(r[v]);
                    vs.status = r[v]; //保存原始值
                }
            }
        });
        modify = true;
    });
    
    //弹窗确定事件
    $('#ensure').click(function(){
        var power = document.getElementsByName('power');
        var powers = [];
        for(var i=0,len=power.length;i<len;i++){ powers.push(power[i].checked ? 1 : 0); }
        //赋值
        $('#authority').val('1' + powers.join('') + '0');
        //清空
        for(var i=0,len=power.length;i<len;i++){ if(power[i].checked){power[i].checked = false;} }
        
        //关闭弹窗和遮罩层
        $('#pop').hide();
        f.overlay().hide();
    });    
    //应用修改
    td.delegate('#applied','click',function(){
        var applied = {}; 
        //应用编辑
        var checked = $('#grids tbody .checked'); 
        if (checked.length == 0 || !modify){ err.innerHTML = '编辑操作请求'; return false; }
        if (checked.length > 1){ err.innerHTML = '一次只能编辑一个条目'; return false; }
        //获取值
        $('#grids tbody .checked td').each(function(i,obj){
            var td = $(obj);
            var attr = td.attr('power'); 
            if(attr == 'id' && modify){ applied.id = td.text();}
            if(attr == 'authority'){ applied.authority = $('#authority').val();}
            if(attr == 'status'){ applied.status = $('#status').val();}                
        });        
        //验证值
        if (modify && applied.id.empty()){ err.innerHTML = '修改ID未正确提供'; return false; }
        if (applied.authority.empty()){ err.innerHTML = '权限值不能为空'; return false; }        
        //是否允许提交
        var allowed = false;
        for(var p in applied){ if(applied[p] != vs[p]){ allowed = true; break;}}
        if(!allowed){ err.innerHTML = '没有可用于提交的内容'; return false; }
        err.innerHTML = '';
        $.post('ask/power.save.ajx.php',applied,function(r){ 
            var j = $.parseJSON(r);
            if (j.yes == '1')
            {
                grid(ask);
                $('#grids tbody').delegate('tr','click',f._trClick);
                modify = false;
            }
        });
    
    });
    
    //删除权限条目
    $('#grids tfoot tr td').delegate('#delete','click',function(){
        var tr = $('#grids tbody .checked');
        var err = document.getElementById('err');
        if (tr.length == 0) { err.innerHTML = '没有条目选中'; return; }
        err.innderHTML = '';
        var id = [];
        tr.each(function(i,obj){ id.push($(obj).find(':first-child').text()); });
        if (window.confirm('你确定要删除这些条目吗？'))
        {
            $.post('ask/power.delete.ajx.php',{"id":id.join('|')},function(r){
                var j = $.parseJSON(r);
                if (j.status == '1')
                {
                    grid(ask);
                    $('#grids tbody').delegate('tr','click',f._trClick); //重新加载事件
                }
                $('#err').text(j.message);
            });        
        }
    });
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#fpage').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
    
    function grid(url,json)
    {
        var num = parseInt(json.page) || 1;
        $.post(url,json,function(r){
            var j = $.parseJSON(r);
            var status = parseInt(j.status);
            var empty = '加载数据失败或者没有可用数据,请稍候重试！';
            if (status == 1)
            {
                page = j.page;
                $('tbody').html(j.tbody);
                $('#oper').html(j.operations);
                $('#fpage').html(paging(j).show());
            }
            
            if (status == 2)
            {
                $('#grids tbody #loading td').html(empty);
                $('#oper').html(j.operations);
                $('#fpage').html('&nbsp');
                setTimeout(function(){$('#grids tbody #loading td').html(empty);},6000);
            }
        });
    }
    
    //鼠标事件 获取当前对象的解释性名称
    $('#grids tbody').delegate('.uover','mouseover',function(){
        var v = $(this).text();
        var _this = $(this);
        if (!_this.attr('title').empty()){ return false; }
        setTimeout(function(){
            $.post('ask/power.mouseover.ajx.php',{"uid":v},function(r){ _this.attr('title',r); });        
        },1000);
    });
    
    $('#grids tbody').delegate('.cover','mouseover',function(){
        var v = $(this).text();
        var _this = $(this);
        if (!_this.attr('title').empty()) { return false; }
        setTimeout(function(){
            $.post('ask/power.mouseover.ajx.php',{"cid":v},function(r){ _this.attr('title',r); });
        },1000);
    });
    
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v});}
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v});
    });    

});
