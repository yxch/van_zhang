<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $power = new power();
    $back['total'] = $power->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //获取数据 搜索功能
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
        if(ctype_digit($search))
        {
            $where = "userId = '{$search}'";            
        }else{  $where = "categoryTitle LIKE '%{$search}%'"; }
        
    }else{ $where = ''; }
    
    $power = new power($where,array('order'=>'createTime DESC','limit'=>$limit));
    $powers  = $power->get(array('id','userId','categoryId','categoryTitle','authority','status','modifiedTime','createTime'));
    
    //准备显示的内容
    $tbody = '';
    $statuses = array('1'=>'启用','0'=>'废弃');
    for($i=0;$i<$power->iTotal();$i++)
    {
        $tbody .= '<tr><td power="id" class="width6">' . $powers['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td class="uover" title="">' . $powers['userId'][$i] . '</td>';
        $tbody .= '<td class="cover" title="">' . $powers['categoryId'][$i] . '</td>';
        $tbody .= '<td>' . $powers['categoryTitle'][$i] . '</td>';
        $tbody .= '<td power="authority" class="editable">' . $powers['authority'][$i] . '</td>';
        $tbody .= '<td power="status" class="editable">' . $statuses[$powers['status'][$i]] . '</td>';
        $tbody .= '<td>' . $powers['modifiedTime'][$i] . '</td>';
        $tbody .= '<td>' . $powers['createTime'][$i] . '</td></tr>';   
    }
    
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],array('add','import','export'));
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    
    if($power->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;        
    
    }else{ $back['status'] = 2; }
    
    points::jan($back);
