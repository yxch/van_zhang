<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('page'=>$_POST['page'],'total'=>0,'size'=>6,'tbody'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
   
    //获取数据
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
		$count = DBC::selected(SQL::GetCountsFromPointsUsersBySearch,[':search'=>'%' . $search . '%'],['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		if($back['total'] > 0)
		{
			$users = DBC::selected(SQL::GetUsersFromPointsUsersBySearch,
				     [':search'=>'%' . $search . '%',':size'=>$back['size'], ':page'=>($back['page'] - 1) * $back['size']]);
		}
    }else
	{ 
		//获取符合条件的总数并处理分页
		$count = DBC::selected(SQL::GetCountsFromPointsUsers,[],['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		//分页查询数据
		if($back['total'] > 0)
		{
			$users = DBC::selected(SQL::GetUsersFromPointsUsers,
								  [':size'=>$back['size'], ':page'=>($back['page'] - 1) * $back['size']]);
		}
	}
	/**
	 * 字段显示映射集 
	 * $set的每个单元的第一个元素表示 表字段的别名 
	 * 第二个元素表示显示的中文 
	 * 第三个元素表示是否在初始化隐藏,
	 * 第四个为可修改标识符
	 */
	$set = [ ['id','表序列ID',0,0],
		     ['username','用户名称',0,1],
		     ['alias','用户别或昵称',0,1],
		     ['type','用户类型',1,1],
		     ['email','电子邮件地址',1,1],
		     ['portrait','头像路径',1,1],
		     ['status','用户状态',1,1],
			 ['cipher','变更密码',1,1],
		     ['mtime','修改时间',1,0],
		     ['ctime','创建时间',1,0]	];
	
	$type = ['1'=>'普通用户','2'=>'管理用户','3'=>'全局用户','9'=>'超级用户'];
	$status = ['0'=>'锁定的用户','1'=>'启用的用户'];

	$usersLen = isset($users) ? count($users) : 0;
	if($usersLen > 0) //有可用于显示的内容
	{
		//打印内容
		$ul = '';
		for($i=0;$i<$usersLen;$i++)
		{
			$ul .= '<ul id="ul_' .$users[$i][$set[0][0]] . '" class="page-lists">';
			for($j=0,$len=count($set);$j<$len;$j++)
			{
				//是否隐藏并确定是否有title内容
				$ul .= $set[$j][2] ? ($j == 0 ? '<li class="hide" title="点击这里选择">' : '<li class="hide">')
					               : ($j == 0 ? '<li title="点击这里选择">' : '<li>');
				$ul .= '<i>' . $set[$j][1]. '</i>';
				$ul .= $set[$j][3] ? '<span name="' . $set[$j][0] . '" class= "revisable">'
					               : '<span name="' . $set[$j][0] .  '">';
				$matter = '';
				if($set[$j][0] == 'type') //需要转换用户类型为可读文本
				{
					$matter = $type[ $users[$i][$set[$j][0]] ];
				}else if($set[$j][0] == 'status') //需要转换用户状态为可读文本
				{
					$matter = $status[ $users[$i][$set[$j][0]] ];
				}else if($set[$j][0] == 'cipher'){ //需要设置用户密码
					$matter = '';
				}else{  $matter = $users[$i][ $set[$j][0] ]; } //否则取原始值
				$matter = empty($matter) ? '　　　' : $matter; //如果值为空时显示8个空格 编辑时需要
				$ul .= $matter . '</span></li>';
			}
			$ul .= '<li class="more"><a title="查看更多">. . .</a></li>';
			$ul .= '</ul>';
		}
	}else //没有可用于显示的内容
	{
		$ul = '<ul class="page-lists empty">';
		$ul .= '<li><i></i><span></span></li>';
		$ul .= '<li><i></i><span>没有可用于显示的内容</span></li>';
		$ul .= '</ul>';
	}
	$back['tbody'] = $ul;
    points::jan($back);