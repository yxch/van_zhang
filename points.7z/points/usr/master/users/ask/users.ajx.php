<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $user = new users();
    $back['total'] = $user->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //获取数据
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    {
        $search = trim($_POST['searcher']);
        $where = "username LIKE '%{$search}%' OR alias LIKE '%{$search}%' OR email LIKE '%{$search}%'";
        
    }else{ $where = ''; }
    
    $user = new users($where,array('order'=>'createTime DESC','limit'=>$limit));
    $users  = $user->get(array('id','username','alias','email','portrait','type','status','modifiedTime','createTime'));
    
    //准备显示的内容
    $tbody = '';
    $types = array('1'=>'前端页面','2'=>'后台页面','3'=>'全局用户','9'=>'超级用户');
    $statuses = array('1'=>'启用','0'=>'废弃');
    for($i=0;$i<$user->iTotal();$i++)
    {
        $tbody .= '<tr><td user="id" class="width6">' . $users['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td user="username" class="editable">' . $users['username'][$i] . '</td>';
        $tbody .= '<td user="alias" class="editable">' . $users['alias'][$i] . '</td>';
        $tbody .= '<td user="email" class="editable">' . $users['email'][$i] . '</td>';
        $tbody .= '<td user="portrait" class="editable" title="' . $users['portrait'][$i] .'">' . $users['portrait'][$i] . '</td>';
        $tbody .= '<td user="type" class="editable">' . $types[$users['type'][$i]] . '</td>';
        $tbody .= '<td user="status" class="editable">' . $statuses[$users['status'][$i]] . '</td>';
        $tbody .= '<td class="hidden" title="' . $users['modifiedTime'][$i] .'">' . $users['modifiedTime'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $users['createTime'][$i] .'">' . $users['createTime'][$i] . '</td></tr>';   
    }
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],array('import','export'));
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    if($user->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;
    }else{ $back['status'] = 2; }
    points::jan($back);
