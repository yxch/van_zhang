<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //确认用户是否有权限访问
	if(!isset($_SESSION[TAG]) || empty($_SESSION[TAG])){ echo '<script>window.top.document.location="' . ACCESSIBLED . '"</script>'; exit; }
	$vsys = points::vsys();
	$MD5 = md5($vsys['power']['murl']);
	$allowed = false;
	foreach($_SESSION[TAG]['category'] AS $k=>$ar){ if($ar['MD5'] == $MD5){ $allowed = true; break;}  }
	if(!$allowed){ echo '<script>window.top.document.location="' . ACCESSIBLED . '"</script>'; exit; }
?>
<!DOCTYPE html>
<html>
<head>
	<?php echo points::head(0); ?>
	<link rel="stylesheet" href="/points/cross/local/css/points.css" />
	<link rel="stylesheet" href="/points/cross/local/css/paging.css" />
	<script src="/points/cross/local/js/points.js"></script>
	<script src="/points/cross/local/js/paging.js"></script>
	<style>.page-lists li i{width:100px;}</style>
	
</head>
<body>
	<h1>用户权限管理</h1>
	<p id="tip">友情提示：顶部的搜索框可以按<strong>用户ID</strong><strong>类别标题</strong>的相关内容进行模糊搜索.输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
	<div id="ul"></div>
	<div id="paging"><span></span></div>
	<div id="oper">
		<a id="close"><img title="关闭" src="<?php echo IMAGE; ?>close-16px.png" /></a>
		<a id="delete"><img title="删除" src="<?php echo IMAGE; ?>delete-1.png" /></a>
		<a id="add"><img title="增加" src="<?php echo IMAGE; ?>new-1.png" /></a>
		<a id="checked"><img title="选择" src="<?php echo IMAGE; ?>check-1.png" /></a>
		<a id="uncheck"><img title="取消选择" src="<?php echo IMAGE; ?>uncheck-1.png" /></a>
		<a id="isshow"><img title="展开" src="<?php echo IMAGE; ?>expand.png" /></a>
		<a id="showall"><img title="全部展开" src="<?php echo IMAGE; ?>all-expand.png" /></a>
	</div>
	<div id="editable">
		<a id="editor"><img title="编辑" src="<?php echo IMAGE; ?>edit_yellow.png" /></a>
		<a id="writer"><img title="保存" src="<?php echo IMAGE; ?>save_yellow.png" /></a>
	</div>
	 <div id="clone">
		<ul class="page-lists clone">
			<div class="selectbox">
				<label><input type="checkbox" class="power" />编辑</label>
				<label><input type="checkbox" class="power" />删除</label>
				<label><input type="checkbox" class="power" />增加</label>
				<label><input type="checkbox" class="power" />权限扩展1</label>
				<label><input type="checkbox" class="power" />权限扩展2</label>
				<label><input type="checkbox" class="power" />权限扩展3</label>
				<label><input type="checkbox" class="power" />导入</label>
				<label><input type="checkbox" class="power" />导出</label>
				<a class="ensure">更改权限</a>
			</div>
		</ul>
	</div>
	<script src="js/power.js"></script>
</body>
</html>