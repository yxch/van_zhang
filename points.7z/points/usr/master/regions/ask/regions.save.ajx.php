<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限

	$back = ['status'=>0,'err'=>'','type'=>'error']; //请求的响应
	$editor = false; $details = [];
	
	if(isset($_POST['id']) && !empty($_POST['id'])) //修改内容
	{
		$editor = true;
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['err'] = '用户权限请求'; points::jan($back); }
		$_arr = explode('_',trim($_POST['id']));
		if(empty($_arr[2]) || !isset($_POST['val']) || !ctype_digit($_arr[1]))
		{
			$back['err'] = '异常的请求！'; 
			points::jan($back);
		}
		$_POST[$_arr[2]] = $_POST['val'];
		$details['mtime'] = date('Y-m-d H:i:s');
		
	}else //新增内容
	{
		//当前用户是否有新建条目的权限
        if(!points::allowed($authority,'add')){ $back['err'] = '用户权限请求'; points::jan($back); }
		//必须设置的一些值
		if(!isset($_POST['region'])){  $back['err'] = '请选择一个区域！'; points::jan($back);	}
		if(!isset($_POST['name'])){  $back['err'] = '必须提供区域名称'; points::jan($back);	}
		if(!isset($_POST['directory'])){  $back['err'] = '必须提供区域路径'; points::jan($back);	}
	}
	if(isset($_POST['region']))
	{
		if(!in_array($_POST['region'],['1','2','3']))
		{
			$back['err'] = '提供了一个错误的区域';
			points::jan($back);
		}
		$details['region'] = $_POST['region'];
	}
	
	if(isset($_POST['name']))  //检查区域权限
	{
		if(mb_strlen($_POST['name']) > 30)
		{
			$back['err'] = '提供的区域名称太长';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['named'] = trim($_POST['name']);
	}

	if(isset($_POST['authority'])) //检查区域权限
	{ 
		if(strlen($_POST['authority']) != 10)
		{
			$back['err'] = '异常的请求';
			points::jan($back);
		}
		for($i=0;$i<10;$i++)
		{ 
			if(!ctype_digit($_POST['authority'][$i]))
			{ 
				$back['err'] = '异常的请求';
				points::jan($back);
			} 
		}
		$details['auth'] = $_POST['authority'];
	}

	if(isset($_POST['directory']))
	{
		$details['dir'] = trim($_POST['directory']);
	}

	if(isset($_POST['yes'])) //检查区域状态值
	{
		if(!in_array($_POST['yes'],['0','1']))
		{
			$back['err'] = '提供了一个无效的区域状态值';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['yes'] = $_POST['yes'];
	}
	
	if($editor) //修改记录
	{
		//如果更新区域名称 确认此名称在同区域下不存在
		if(isset($details['named']))
		{
			$exist = DBC::selected(SQL::GetCountFromPointsRegionsByIdAndName, 
					 [':id'=>$_arr[1],':named'=>$details['named']],['one'=>TRUE]);
			if($exist['total'] > 0)
			{
				$back['err'] = '指定的区域已经存在！';
				points::jan($back);
			}
		}
		//更新记录
		$SQL = 'UPDATE ' . SQL::TblRegion . ' SET  ';
		$update = []; $str = '';
		foreach($details AS $k=>$v)
		{
			$str .= $k . '=' . ':' . $k . ',';
			$update[':' . $k] = $v;
		}
		$SQL .= trim($str,',') . ' WHERE id = :id';
		$update[':id'] = $_arr[1];
		$stmt = DBC::PDO()->prepare($SQL);
		if($stmt->execute($update))
		{
			$back['status'] = 1;
			$back['err'] = '修改成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '修改失败，请检查输入是否有误！'; }

	}else //新建记录
	{
		//是否存在此区域
		$exists = DBC::selected(SQL::GetCountFromPointsRegionsByRegionAndName,
			      [':region'=>$details['region'],':named'=>$details['named']],['one'=>TRUE]);
		if($exists['total'] > 0)
		{
			$back['err'] = '指定的区域已经存在！';
			points::jan($back);
		}
		$inserts = [];
		foreach($details AS $k=>$v){ $inserts[':' . $k] = $v;	}  
		if(DBC::modified(SQL::NewRegionInPointsRegions,$inserts))
		{
			$back['status'] = 1;
			$back['err'] = '新建区域成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '新建区域失败，检查网络和服务器'; }
	}
	points::jan($back);



	
	
	