<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $variableId = isset($_GET['vid']) ? $_GET['vid'] : '';
    if($variableId && !ctype_digit($variableId)){exit('Exception access violation');}
    $title = "存储新变量";  $murl = ''; $status = ''; $note = '';
    $name = ''; $value = ''; $text = ''; $rule = ''; $isUser = '1'; $type = 'text';
    if($variableId) //如果用户编辑类别
    {
        $title = "编辑变量[ID:<label id=\"id\">$variableId</label>]";
        $var = new vars(array('id'=>$variableId));
        $vars = $var->get(array('name','value','url','note','text','rule','isUserControl','status','type'));
        $murl = $vars['url'][0];
        $status = $vars['status'][0];
        $note = $vars['note'][0];
        $name = $vars['name'][0];
        $value = $vars['value'][0];
        $text = $vars['text'][0];
        $rule = $vars['rule'][0];
        $isUser = $vars['isUserControl'][0];
        $type = $vars['type'][0];
    }
?>
<!DCOTYPE html>
<html>
    <head>
       <?php echo points::head(false); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="css/variable.oper.css" />
       <script src="js/variable.oper.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1><?php echo $title; ?></h1></div>
            <div id="variable">
                <div id="dv-murl">
                    <label>变量应用于：</label><input type="text" id="murl" value="<?php echo $murl; ?>" />
                    <span>
                        <label>状态：</label>
                        <select id="status">
                            <option value="1" <?php if($status == '1'){ echo 'selected'; }?>>用户的变量</option>
                            <option value="2" <?php if($status == '2'){ echo 'selected'; }?>>系统的变量</option>
                            <option value="0" <?php if($status == '0'){ echo 'selected'; }?>>废弃的变量</option>
                        </select>
                    </span>
                    <span>
                        <label>是否用户可控制：</label>
                        <select id="isuser">
                            <option value="1" <?php if($isUser == '1'){ echo 'selected';} ?> >用户可控</option>
                            <option value="0" <?php if($isUser == '0'){ echo 'selected';} ?> >用户不可控</option>
                        </select>
                    </span>
                    <p class="desc">声明此变量应用的URL(此URL即在类别管理页所申请的URL，也是唯一识别ID),可以通过某些方法快速获取这个URL下的变量.</p>
                </div>
                <div id="dv-note">
                    <label>变量描述：</label><input type="text" id="note" value="<?php echo $note; ?>" />
                    <span class="desc">变量的描述可以方便查找及区分不同变量,请确保此描述符合变量的声明.</span>
                </div>
                <div id="dv-name">
                    <label>变量名称：</label><input type="text" id="named" value="<?php echo $name; ?>" />
                    <span class="desc">变量的名称必须是大小写字母或下划线开头和数字或字母的组合.</span>
                </div>
                <div id="dv-val">
                    <label>变量的值：</label><input type="text" id="val" value="<?php echo $value; ?>" />
                    <span id="rule">
                        <label>变量值校验规则：</label>
                        <select id="rules">
                            <option value="text" <?php if($rule == 'text'){ echo 'selected'; } ?>>普通短文本</option>
                            <option value="digit" <?php if($rule == 'digit'){ echo 'selected'; } ?>>数字字符</option>
                            <option value="digits" <?php if($rule == 'digits'){ echo 'selected'; } ?>>用英文逗号分开的数字序列</option>
                            <option value="datetime" <?php if($rule == 'datetime'){ echo 'selected'; } ?>>规范的时间格式</option>
                            <option value="int" <?php if($rule == 'int'){ echo 'selected'; } ?>>正整数</option>
                            <option value="boolean" <?php if($rule == 'boolean'){ echo 'selected'; } ?>>布尔0或1</option>
                            <option value="limit" <?php if($rule == 'limit'){ echo 'selected'; } ?>>整数范围</option>
                            <option value="decimal" <?php if($rule == 'decimal'){ echo 'selected'; } ?>>小数</option>
                            <option value="telephone" <?php if($rule == 'telephone'){ echo 'selected'; } ?>>电话号码</option>
                            <option value="mobile" <?php if($rule == 'mobile'){ echo 'selected'; } ?>>手机号码</option>
                            <option value="email" <?php if($rule == 'email'){ echo 'selected'; } ?>>EMAIL地址</option>
                            <option value="url" <?php if($rule == 'url'){ echo 'selected'; } ?>>完整URL地址</option>
                            <option value="postcode" <?php if($rule == 'postcode'){ echo 'selected'; } ?>>邮编号码</option>
                        </select>
                    </span>
                    <span>
                        <label>变量的显示类型：</label>
                        <select id="type">
                            <option value="text" <?php if($type == 'text'){ echo 'selected'; } ?>>文本</option>
                            <option value="checkbox" <?php if($type == 'checkbox'){ echo 'selected'; } ?>>多选</option>
                            <option value="radio" <?php if($type == 'radio'){ echo 'selected'; } ?>>单选</option>
                            <option value="textarea" <?php if($type == 'textarea'){ echo 'selected'; } ?>>字段域</option>
                        </select>
                    </span>
                    <p class="desc">变量的值必须符合选择的校验规则,系统根据校验规则校验。不确定或者过长的变量值请用下面变量文本选项。</p>
                </div>
                <div id="dv-txt">
                    <label>变量的文本：</label>
                    <textarea id="txt"><?php echo $text; ?></textarea>
                </div>
                <div id="apply"><span id="err"></span><a id="applied">应用</a></div>
            </div>            
        </div>
        <div id="announce">增加或者修改变量根据用户的权限而定且某些变量只能由系统用户操作</div>
    </body>
</html>