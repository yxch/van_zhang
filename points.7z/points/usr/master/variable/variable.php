<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
?>
<!DOCTYPE html>
<html>
    <head>
       <?php echo points::head(false); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="/points/usr/local/css/grids.css" />
       <script src="/points/usr/local/js/paging.js"></script>
       <script src="/points/usr/local/js/f.js"></script>
       <script src="js/variable.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1>变量管理</h1><span id="err"></span></div>
            <div id="tip">
                <p class="first">友情提示：顶部的搜索框可以按<strong>变量名</strong><strong>变量的描述</strong>的相关内容进行模糊搜索。输入搜索条件后可以按下回车<strong>ENTER</strong>键或者旁边的搜索小图标</p>
            </div>
            <table id="grids">
                <thead>
                    <tr>
                        <td class="width6">编号</td>
                        <td class="width8">变量名称</td>
                        <td>变量值</td>
                        <td class="width25">变量应用在</td>
                        <td>变量描述</td>
                        <td>变量文本</td>
                        <td class="width6">状态</td>
                        <td>创建时间</td>
                    </tr>
                </thead>
                <tbody>
                    <tr id="loading"><td colspan="8">loading data！please wait......</td></tr>
                </tbody>
                <tfoot><tr><td colspan="8"><span id="oper">&nbsp</span><span id="fpage">&nbsp</span></td></tr></tfoot>
            </table>
        </div>
    </body>
</html>