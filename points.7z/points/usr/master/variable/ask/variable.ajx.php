<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    $item = $_SESSION['points']['item']['id'];
    //返回的数据
    $back = array('page'=>$_POST['page'],'total'=>0,'size'=>6,'tbody'=>'');

	//校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }

	//获取数据并处理分页显示
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))  //用户搜索
    {
        $search = trim($_POST['searcher']);
      	$count = DBC::selected(SQL::CountFromPointsVariablesBySearch,
							   [':name'=>'%' . $search . '%',':note'=>'%' . $search . '%',':url'=>'%' . $search . '%'],
							   ['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		//分页查询数据
		$variable = DBC::selected(SQL::GetInfoFromPointsVariablesBySearcher,
								  [':name'=>'%' . $search . '%',
								   ':note'=>'%' . $search . '%',
								   ':url'=>'%' . $search . '%',
								   ':size'=>$back['size'],
								   ':page'=>($back['page'] - 1) * $back['size']]);
    }else
	{
		//获取符合条件的总数并处理分页
		$count = DBC::selected(SQL::CountFromPointsVariable,[],['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		//分页查询数据
		$variable = DBC::selected(SQL::GetPageFromPointsVariable,
								  [':size'=>$back['size'], ':page'=>($back['page'] - 1) * $back['size']]);
	}
	//字段显示映射集 $set的每个单元的第一个元素表示 表的别名 第二个元素表示显示的中文 第三个元素表示是否在初始化隐藏
	$set = [ ['id','表序列ID',0],['name','变量名称',0],['value','变量值',0],['rule','变量的校验规则',1],['url','变量访问路径',1],
		     ['note','变量说明',0],['text','变量描述',1],['status','当前状态',1],['isUsr','是否用户控制',1],
		     ['type','显示方式',1],['createTime','创建时间',1]];

	$variableLen = count($variable);
	if($variableLen > 0) //有可用于显示的内容
	{
		//打印内容
		$ul = '';
		for($i=0;$i<$variableLen;$i++)
		{
			$ul .= '<ul id="ul_' .$variable[$i][$set[0][0]] . '" class="page-lists">';
			for($j=0,$len=count($set);$j<$len;$j++)
			{
				//是否隐藏并确定是否有title内容
				$ul .= $set[$j][2] ? ($j == 0 ? '<li class="hide" title="点击这里选择">' : '<li class="hide">')
					               : ($j == 0 ? '<li title="点击这里选择">' : '<li>');
				$ul .= '<i>' . $set[$j][1]. '</i>';
				$ul .= '<span class="' . $set[$j][0] .  '">' . $variable[$i][$set[$j][0]] . '</span>';
				$ul .= '</li>';
			}
			$ul .= '<li class="more"><a title="查看更多">. . .</a></li>';
			$ul .= '</ul>';
		}
	}else //没有可用于显示的内容
	{
		$ul = '<ul class="page-lists empty">';
		$ul .= '<li><i></i><span></span></li>';
		$ul .= '<li><i></i><span>没有可用于显示的内容</span></li>';
		$ul .= '</ul>';
	}
	$back['tbody'] = $ul . '<script src="/points/cross/local/js/page-lists.js"></script> ';
    points::jan($back);