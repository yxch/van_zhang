<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
	define('ADMIN',$_SESSION['points']['user']['type'] == 9);

    $back = array('status'=>0,'tip'=>'');  
	$vars = []; //注意与表字段名一致	
	$bind = [];
	//必须提供管理标识符murl
    if(isset($_POST['murl']) && !empty($_POST['murl']))
    {
        $murls = points::SURL($_POST['murl'],1);
        if($murls['status'] == 0){ $back['tip'] = '提供的管理标识符murl不符合要求';  points::jan($back); }
    }else{ $back['tip'] = '必须提供管理标识符murl'; points::jan($back); }
    $vars['url'] = $_POST['murl'];
	$bind[':url'] = $_POST['murl'];
	$bind[':pos'] = $murls['md5'];
	
    //系统变量名集合
    $names = array('stime','etime','serial','psize','cached','shortid','limited','auxiliary','ssign','esign');
	
	$editor = false; $variable = '';
	if(isset($_POST['id']) && !empty($_POST['id'])) //是否提供了id字段 如果提供id则视为编辑否则为新增
	{
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
        if(!ctype_digit($_POST['id'])){ $back['tip'] = '提供的编辑ID可能错误'; points::jan($back); }
		$editor = TRUE;
		$variable = DBC::selected(SQL::GetVarsFromPointsVariablesById,[':id'=>$_POST['id']],['one'=>TRUE]);
	}
	if(!isset($_POST['status'])) //检查提供变量的范围标识符 
	{
		$back['tip'] = '必须提供变量的范围标识符'; points::jan($back);
	}else
	{
		if(!in_array($_POST['status'],array('0','1','2'))){ $back['tip'] = '提供的变量范围标识符可能有误'; points::jan($back); }
		//普通用只能指定变量的范围标识符为用户变量范围
		if(!ADMIN && $_POST['status'] == 1)
		{
			$back['tip'] = '当前用户不能指定变量的范围标识符为系统变量'; points::jan($back);
		}
		if(!ADMIN && $_POST['status'] != $variable['status'])
		{
			$back['tip'] = '当前用户不能改变变量的状态'; points::jan($back);
		}
		$vars['tag'] = $_POST['status'];
		$bind[':tag'] = $_POST['status'];
	}
	if(!$editor) //新增记录时必须提供isuser note value rule type内容
	{
		//当前用户是否有写入条目的权限
        if(!points::allowed($authority,'add')){ $back['tip'] = '用户权限请求'; points::jan($back); }
		
		if(!isset($_POST['note']))
		{ 
			$back['tip'] = '请指定变量描述'; points::jan($back);
		}
		if(!isset($_POST['value']) || $_POST['value'] == ' ')
		{
			$back['tip'] = '必须提供变量的值'; points::jan($back);
		}
		if(!isset($_POST['rule']) || empty($_POST['rule']))
		{
			$back['tip'] = '请指定变量的校验规则'; points::jan($back);
		}
		if(!isset($_POST['type']) || empty($_POST['type']))
		{
			$back['tip'] = '请指定变量的显示方式'; points::jan($back);
		}
		$bind[':text'] = isset($_POST['text']) ? trim($_POST['text']) : '';
	}
	
	if(isset($_POST['note'])) //检查变量的说明
	{
		if(empty($_POST['note'])){ $back['tip'] = '请指定变量描述内容'; points::jan($back); }
		if(!ADMIN && $_POST['note'] != $variable['note'])
		{
			$back['tip'] = '当前用户不能改变变量描述'; points::jan($back);
		}
		$vars['note'] = $_POST['note'];
		$bind[':note'] = $_POST['note'];
	}
	if(!isset($_POST['name']) || empty($_POST['name'])) //检查变量的名称
	{
		$back['tip'] = '必须提供变量的名称'; points::jan($back);
	}else
	{
		//无论是否是超级用户都不可以改变系统变量的名称
		if($editor && $variable['status'] == 1 && $_POST['name'] != $variable['name'])
		{
			$back['tip'] = '不能改变系统变量的名称'; points::jan($back);
		}
		if(!ADMIN && in_array($_POST['name'],$names))
		{
			$back['tip'] = '变量名已被系统使用'; points::jan($back);
		}
		$vars['named'] = $_POST['name'];
		$bind[':name'] = $_POST['name'];
	}
	if(isset($_POST['rule'])) //检查变量的规则
	{
		$rules = array('text','digit','digits','datetime','int','boolean','limit','decimal','telephone','mobile','email','url','postcode');
		if(!in_array($_POST['rule'],$rules))
		{
			$back['tip'] = '此校验规则尚未被定义'; points::jan($back);
		}
		$vars['rule'] = $_POST['rule'];
		$bind[':rule'] = $_POST['rule'];
	}
	if(isset($_POST['value'])) //检查变量的值
	{
		if(!STR::checkText($_POST['value'],$vars['rule']))
		{ 
			$back['tip'] = '当前值与选择的值的验证规则不符'; points::jan($back);
		}
		$vars['val'] = $_POST['value'];
		$bind[':value'] = $_POST['value'];
	}
	if(isset($_POST['type'])) //检查变量的显示方式
	{
		if(!in_array($_POST['type'],array('text','checkbox','radio','textarea')))
		{
			$back['tip'] = '此显示类型尚未被定义'; points::jan($back);
		}
		$vars['tye'] = $_POST['type'];
		$bind[':type'] = $_POST['type'];
	}
	if(isset($_POST['text']))
	{
		$vars['txt'] = $_POST['text'];
	}
	
	if($editor)  //编辑条目
	{
		//准备SQL
		$SQL = 'UPDATE ' . SQL::TblVariable . ' SET mtime = :mtime, ';
		$update = []; $str = '';
		foreach($vars AS $k=>$v)
		{
			$str .= $k . '=' . ':' . $k . ',';
			$update[':' . $k] = $v;
		}
		$SQL .= trim($str,',') . ' WHERE id = :id';
		$stmt = DBC::PDO() -> prepare($SQL);
		$vars[':mtime'] = date('Y-m-d H:i:s');
		$vars[':id'] = $_POST['id'];
		if($stmt->execute($vars))
		{
			$back['status'] = 1;
			$back['tip'] = '更新成功！';
		}else{ $back['tip'] = '更新失败！'; }
		
	}else  //新建条目
	{ 
		if(DBC::modified(SQL::NewVariablesInPointsVariables,$bind))
		{
			$back['status'] = 1;
			$back['tip'] = '新建条目成功！';
		}else{ $back['tip'] = '新建条目失败！'; }
	}
    //返回结果
    points::jan($back);
