<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $fid = isset($_GET['fid']) ? $_GET['fid'] : '';
    if(empty($fid)){ exit('Required parameter missing!');}
    if(!ctype_digit($fid)){exit('Exception access violation');}
    
    if($fid) //如果用户编辑类别
    {
        $title = "编辑数据过滤器[ID:<label id=\"id\">$fid</label>]";
        $filter = new filter(array('id'=>$fid));
        $filters = $filter->get(array('name','categoryId','searcher','fieldText','select','factor','rest')); 
        $fields = points::parseField($filters['fieldText'][0]);
        
        $cid = $filters['categoryId'][0]; //此过滤器所属类别id
        //显示全部类别以供用户选择 
        $category = new category(); 
        $categories = $category->get(array('id','title','MD5'));
        $sysurl = points::sysurl('md5'); //排除系统基本路径
        $categoryArr = array();
        for($i=0;$i<$category->iTotal();$i++)
        {
            if(!in_array($categories['MD5'][$i],$sysurl)){$categoryArr[$categories['id'][$i]] = $categories['title'][$i];}
        }
        $groups = array_chunk($categoryArr,3,true); //分组显示 每组显示3个，如果组数大于则第一组显示其余隐藏 用户点击更多时显示
        $li = '';
        $len = count($groups);
        for($j=0;$j<$len;$j++)
        {
            $li .= $j > 0 ? "<li id=\"dis{$j}\" style=\"display:none;\">" : '<li>';
            foreach($groups[$j] as $k=>$val)
            {
                $checked = $k == $cid ? 'checked' : '';
                $li .= "<label><input type=\"radio\" name=\"categories\" value=\"{$k}\" {$checked} />{$val}</label>";
            }
            //是否显示更多
            if($len > 0 && $j < $len - 1){ $n = $j + 1; $li .= "<label><a class=\"more\" id=\"more-{$n}\">更多>></a></label>"; }
            $li .= '</li>';
        }
    }
?>
<!DCOTYPE html>
<html>
    <head>
       <?php echo points::head(false); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="css/filters.oper.css" />
       <script src="js/filters.oper.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1><?php echo $title; ?></h1></div>
            <div id="filter">
                <div id="categories">
                    <label>为此数据过滤器指定所属类别【单选】：</label>
                    <ul><?php echo $li; ?></ul>
                </div>
                <div id="ftitle">
                    <label>为此数据过滤器定义一个标题：</label><input type="text" id="filter-title" value="<?php echo $filters['name'][0]; ?>" />
                    <span>
                        <label>过滤器状态:</label>
                        <select id="status">
                            <option value="1">启用</option>
                            <option value="0">废弃</option>
                        </select>
                    </span>
                    <p class="desc">标题可以识别此数据过滤器，易于用户在多个不同的数据过滤器之间切换，并根据标题来识别此数据过滤器的用途。</p>
                </div>
                <div id="field">
                    <p id="field-options">
                        <label>为此数据过滤器添加数据字段和显示字段及翻译设定：</label>
                        <span>
                            <select id="dbname">
                                <option value="1">活动数据库</option>
                                <option value="2">drupal基础数据库</option>
                            </select>
                            <label id="tname">表名：</label><input id="tablename" value="<?php echo $fields['tb']; ?>" />
                        </span>
                    </p>
                    <table id="fields">
                        <thead>
                            <tr>
                                <td>数据表字段</td>
                                <td>显示名</td>
                                <td>翻译设定</td>
                                <td>标识</td>
                                <td><a id="fadd">+</a><a id="fdelete">-</a></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($fields['field'] as $key=>$v){ ?>
                                <tr>
                                    <td><input type="text" value="<?php echo $key; ?>" /></td>
                                    <td><input type="text" value="<?php echo $v; ?>" /></td>
                                    <td><input type="text" value="<?php if(isset($fields['translator'][$key])){echo $fields['translator'][$key];} ?>" /></td>
                                    <td><input type="text" value="<?php if(isset($fields['flag'][$key])){echo $fields['flag'][$key];} ?>" /></td>
                                    <td><input type="checkbox" class="check" /></td>
                                </tr> 
                            <?php } ?>                           
                        </tbody>
                    </table>
                    <p class="desc">数据表字段必须与相关表的字段一致 (此处映射名将不可用，映射名无法在此条件下处理)，显示名在用户查询数据时显示，通常是表字段中文名称。翻译设定值是数组的单元通常是关联数组，比如：要将F显示成女，翻译字段内容填写为 'F':'女'多个翻译值用英文空格隔开。</p>
                </div>
                <div id="search">
                    <label>基于此过滤器的搜索设定：</label><input type="text" id="fsearch" value="<?php echo $filters['searcher'][0]; ?>" />
                    <p class="desc">设定此数据过滤器的搜索选项,如果多个搜索选项请用英文逗号分号,注意搜索选项必须在上面的字段中出现。</p>
                </div>
                <div class="sql">
                    <label>此数据过滤器SQL语句SELECT部分：</label>
                    <textarea id="select"><?php echo $filters['select'][0]; ?></textarea>
                    <p class="desc">提供此过滤器SQL语句的SELECT部分，可以不提供字段。但必须完整提供表名和剩余的部分。</p>
                </div>
                <div class="sql">
                    <label>此数据过滤器SQL语句WHERE部分：</label>
                    <textarea id="factor"><?php echo $filters['factor'][0]; ?></textarea>
                    <p class="desc">提供此过滤器SQL语句的WHERE子名部分,此方法可能不适用于太复杂的查询语句。请使用视图的方法来简化复杂查询。</p>
                </div>
                <div class="sql">
                    <label>　 此数据过滤器SQL语句其它部分 ：</label>
                    <textarea id="rest"><?php echo $filters['rest'][0]; ?></textarea>
                    <p class="desc">提供此过滤器SQL语句的其它部分。通常LIMIT由程序自动处理。</p>
                </div>
                <div id="apply"><span id="error"></span><a id="applied">保存</a></div>
            </div>
        </div>
        <div id="announce"></div>
    </body>
</html>