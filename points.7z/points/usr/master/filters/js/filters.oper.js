
$(document).ready(function(){
  //获取表的内容
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
				var html = '<li class="rows">';
				html +=	'<span class="most"><input class="field" /></span>';
				html += '<span class="most"><input class="alias" /></span>';
				html += '<span><input class="primary" type="checkbox" /></span>';
				html += '<span><input class="increment" type="checkbox" /></span>';
				html += '<span><input class="updated" type="checkbox" /></span>';
				html += '<span><input class="dated" type="checkbox" /></span>';
				html += '<span class="most"><input class="translator" /></span>';
				html += '<span><input class="select" type="checkbox" /></span>';
				html += '</li>';
				$('#filter ul .rows').empty();
				$('#filter ul #capital').after(html);
                return false;
            }
            $.post('/points/usr/master/category/ask/category.oper.filter.db.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){ //console.log(r);
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
					$('#filter ul .rows').remove();
					$('#filter ul #capital').after(j.tbody);
					$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
					var rows = getTableInfo();
					var fields = rows.fields.split('|').join(',');
					$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
                }
            });
        }
    });  
	//获取表信息
	function getTableInfo()
	{
		var rows = $('#filter ul .rows');
		var fields = [],comment = [],primary = [],increment = [],updated = [],dated = [],translator = [],err = 0;
		var json = {"errNum":0};
		json.table = $.trim($('#tablename').val());
		rows.each(function(i,obj){
			var child = $(obj).children('span'),fname = '';
			child.each(function(j,obj){
				var input = $(obj).children('input');
				if(j == 0 && input.hasClass('field'))
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : fields.push(v);
					fname = v;
				}
				if(j == 1 && input.hasClass('alias'))	
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : comment.push(v);
				}
				if(j == 2 && input.hasClass('primary')){	if(input.is(':checked')){ primary.push(fname); }	}
				if(j == 3 && input.hasClass('increment')){	if(input.is(':checked')){ increment.push(fname); }	}
				if(j == 4 && input.hasClass('updated')){	if(input.is(':checked')){ updated.push(fname); }	}
				if(j == 5 && input.hasClass('dated')){	if(input.is(':checked')){ dated.push(fname); }	}
				if(j == 6 && input.hasClass('translator'))
				{	
					if(!$.trim(input.val()).empty()){ translator.push(fname + '=' + $.trim(input.val())); }	
				}
			});
		});
		json.fields = fields.join('|');
		json.comment = comment.join('|');
		json.primary = primary.join('|');
		json.increment = increment.join('|');
		json.updated = updated.join('|');
		json.dated = dated.join('|');
		json.translator = translator.join('|');
		json.errNum = err;
		return json;
	}
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
		var selected = $('#filter ul li .select');
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked'))
			{
				check.removeAttr('checked');
				var parent = check.parent().parent();
				parent.after(parent.clone());
				$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
			}
		});
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
    });
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){    
		var selected = $('#filter ul li .select'); 
		var selects = $('#filter ul .rows').length; 
		if($('#filter ul li .select:checked').length == selects){ return false; } //不能全部删除
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked')){	check.parent().parent().remove(); }
		});
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
    });
	$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
	//用户更正字段名称
	function selectUpdate()
	{
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
	}

	//保存过滤器
	$('#save-filter').click(function(e){
		var filter = {}; 

		var id = $('#id').text();
		if(id.empty() || !global.positive(id))
		{
			global.tip('必须提供编辑过滤器的id');return false;
		}
		filter.id = id; 

		var cid = $('input[name="categories"]:checked').val(); 
		if(cid.empty() || !global.positive(cid))
		{
			global.tip('需要类别ID来限定过滤器的作用域【通常情况下先保存类别然后从类别列表界面来编辑】');return false;
		}
		filter.cid = cid; 
		
		var title = $.trim($('#ftitle').val());
		if(title.empty())
		{
			global.tip('必须指定过滤器的标题【标题有利于识别管理标识符murl下不同的过滤器】');return false;
		}
		filter.title = title; //保存过滤器的标题

		filter.status = $('#yes').val();
		
		var tb = getTableInfo();
		if(parseInt(tb.errNum) > 0)
		{
			global.tip('必须指定字段和标题名');return false;
		}
		filter.fields = tb.fields;
		filter.alias = tb.comment;
		filter.primary = tb.primary;
		filter.increment = tb.increment;
		filter.updated = tb.updated;
		filter.dated = tb.dated;
		filter.translator = tb.translator;
		filter.tblname = tb.table;

		filter.searcher = $.trim($('#fsearch').val());
		
		var select = $.trim($('#select').val());
		if(select.empty())
		{
			global.tip('必须指定SQL的查询部分');return false;
		}
		filter.select = select;
		
		filter.factor = $.trim($('#factor').val());
		filter.rest = $.trim($('#rest').val());
		
		$.post('ask/filters.edit.ajx.php',filter,function(r){ //console.log(r);
			var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
		});
	});
    
    //用户点击更多
    $('.more').click(function(){ 
        var id = $(this).attr('id').split('-')[1]; 
        if ($(this).hasClass('extend'))
        {
            $('#dis' + id).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + id).fadeIn();
            $(this).text('折叠>>');
        }
    });

});