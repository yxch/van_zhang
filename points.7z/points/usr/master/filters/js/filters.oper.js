
$(document).ready(function(){
  //获取表的内容
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
				$('#filter ul .rows').remove();
				$('#filter ul #capital').after($('#clone .rows').clone());
                return false;
            }
            $.post('/points/usr/master/category/ask/category.oper.filter.db.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){ 
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
					$('#filter ul .rows').remove();
					$('#filter ul #capital').after(j.tbody);
					$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
					selectUpdate();
                }else
				{
					$('#filter ul .rows').remove();
					$('#filter ul #capital').after($('#clone .rows').clone());
					$('#totalize').val('');
					$('#statement').val('');
					$('#condition').val('');
				}
            });
        }
    });  
	//获取表信息
	function getTableInfo()
	{
		var rows = $('#filter ul .rows');
		var fields = [],comment = [],primary = [],increment = [],updated = [],fsearch = [],dated = [],translator = [],err = 0;
		var json = {"errNum":0};
		json.table = $.trim($('#tablename').val());
		rows.each(function(i,obj){
			var child = $(obj).children('span'),fname = '';
			child.each(function(j,obj){
				var input = $(obj).children('input');
				if(j == 0 && input.hasClass('field'))
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : fields.push(v);
					fname = v;
				}
				if(j == 1 && input.hasClass('alias'))	
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : comment.push(v);
				}
				if(j == 2 && input.hasClass('primary')){	if(input.is(':checked')){ primary.push(fname); }	}
				if(j == 3 && input.hasClass('increment')){ if(input.is(':checked')){ increment.push(fname); }	}
				if(j == 4 && input.hasClass('updated')){	if(input.is(':checked')){ updated.push(fname); }	}
				if(j == 5 && input.hasClass('fsearch')){ if(input.is(':checked')){ fsearch.push(fname); }	}
				if(j == 6 && input.hasClass('dated')){ if(input.is(':checked')){ dated.push(fname); }	}
				if(j == 7 && input.hasClass('translator'))
				{	
					if(!$.trim(input.val()).empty()){ translator.push(fname + '=' + $.trim(input.val())); }	
				}
			});
		});
		json.fields = fields.join('|');
		json.comment = comment.join('|');
		json.primary = primary.join('|');
		json.increment = increment.join('|');
		json.updated = updated.join('|');
		json.fsearch = fsearch.join('|');
		json.dated = dated.join('|');
		json.translator = translator.join('|');
		json.errNum = err;
		return json;
	}
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
		var selected = $('#filter ul li .select');
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked'))
			{
				check.removeAttr('checked');
				var parent = check.parent().parent();
				parent.after(parent.clone());
				$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
			}
		});
		selectUpdate();
    });
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){    
		var selected = $('#filter ul li .select'); 
		var selects = $('#filter ul .rows').length; 
		if($('#filter ul li .select:checked').length == selects){ return false; } //不能全部删除
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked')){	check.parent().parent().remove(); }
		});
		selectUpdate();
    });
	$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
	//用户更正字段名称
	function selectUpdate()
	{
		var rows = getTableInfo();
		//var fields = rows.fields.split('|').join(',');
		$('#totalize').val('SELECT COUNT(*) AS total ' + (rows.table.empty() ? '' : ' FROM ' + rows.table) + ' :WHERE');
		$('#statement').val('SELECT ' + ' :FIELDS ' + (rows.table.empty() ? '' : ' FROM ' + rows.table ) + ' :WHERE');
	}

	//保存过滤器
	$('#save-filter').click(function(e){
		var filter = {}; 

		var fid = $('#id').text();
		if(fid.empty() || !global.positive(fid))
		{
			global.tip('必须提供编辑过滤器的id');return false;
		}
		filter.fid = fid; 

		var id = $('input[name="categories"]:checked').val(); 
		if(id.empty() || !global.positive(id))
		{
			global.tip('需要类别ID来限定过滤器的作用域【通常情况下先保存类别然后从类别列表界面来编辑】');return false;
		}
		filter.id = id; 
		
		var title = $.trim($('#ftitle').val());
		if(title.empty())
		{
			global.tip('必须指定过滤器的标题【标题有利于识别管理标识符murl下不同的过滤器】');return false;
		}
		filter.title = title; //保存过滤器的标题

		filter.status = $('#yes').val();
		
		var tb = getTableInfo();
		if(parseInt(tb.errNum) > 0)
		{
			global.tip('必须指定字段和标题名');return false;
		}
		filter.fields = tb.fields;
		filter.alias = tb.comment;
		filter.primary = tb.primary;
		filter.increment = tb.increment;
		filter.updated = tb.updated;
		filter.fsearch = tb.fsearch;
		filter.dated = tb.dated;
		filter.translator = tb.translator;
		filter.tblname = tb.table;
		
		var totalize = $.trim($('#totalize').val());
		if(totalize.empty())
		{
			global.tip('必须提供计算符合条件的记录SQL');return false;
		}
		filter.totalize = totalize;
		var statement = $.trim($('#statement').val());
		if(statement.empty())
		{
			global.tip('必须指定SQL的查询部分');return false;
		}
		filter.statement = statement;
		filter.condition = $.trim($('#condition').val()); 
		
		$.post('/points/usr/master/category/ask/category.oper.filter.ajx.php',filter,function(r){
			var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
		});
	});
    
    //用户点击更多
    $('.more').click(function(){ 
        var id = $(this).attr('id').split('-')[1]; 
        if ($(this).hasClass('extend'))
        {
            $('#dis' + id).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + id).fadeIn();
            $(this).text('折叠>>');
        }
    });

});