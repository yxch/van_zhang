$(document).ready(function(){
    var ask = 'ask/filters.ajx.php';
    grid(ask,{"page":1});

	//新建数据过滤器
	$('#add').click(function(){
		global.tip('过滤器隶属于某个类别，你可能需要从类别管理器的列表界面开始处理！','warning');
		return false;
	});
    
    //编辑过滤器
    $('#edit').click(function(){ 
        var id = $('#' + local.id).find('.id').text();
        id ? window.location.href="filters.oper.php?fid=" + id : global.tip('没有可用于编辑的内容！');
    });
    
    //删除过滤器
    $('#delete').click(function(){
       if(local.empty)
		{
			global.tip('不能删除一个空的条目！','warning');
		}else
		{
			var ar = [],selects = [],id = '';
			for(var p in local.select){ ar.push(p); }
			if(ar.length > 0) //用户至少选择了一个要删除的条目
			{
				for(var i=0;i<ar.length;i++){ selects.push(ar[i].split('_')[1]); }
				id = selects.join('|');
			}else
			{
				if(local.id)
				{
					id = local.id.split('_')[1];
				}else
				{
					global.tip('请选择要删除的条目【在要删除的条目上单击即可】！','error');
					return FALSE;
				}
			}
			if(id.empty()){ global.tip('发生错误，没有任何内容被选择！','error'); return FALSE; }
			$.post('ask/filters.delete.ajx.php',{'id':id},function(r){ console.log(r);
				var j = $.parseJSON(r);
				if(j.status == 0){		global.tip(j.err);
				}else{					global.tip(j.err,'success'); 	grid(ask,{"page":1});	}
			});
		}
    });
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
    
    function grid(url,json)
    {
        $.post(url,json,function(r){ //console.log(r);
            var j = $.parseJSON(r);
            if (j.tbody)
            {
                $('#ul').html(j.tbody);
				local.page = j.page;
				$('#paging span').html(paging(j).show());
				local.empty = parseInt(j.total) == 0 ? true : false;
            }
        });
    }
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v,"page":1});}
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v,"page":1});
    });    

});
