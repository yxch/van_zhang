<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];    
    
    //返回的数据
    $back = array('status'=>0,
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15,
                  'tbody'=>'',
                  'operations'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取符合条件的总数并处理分页
    $filter = new filter();
    $back['total'] = $filter->rows();
    $limit = $back['size'] . ' OFFSET ' . ($back['page'] - 1) * $back['size'];
    
    //搜索设置
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))
    { 
        $search = trim($_POST['searcher']);  $where = "name LIKE '%{$search}%'";
        
    }else{ $where = ''; }
    
    //获取数据
    $filter = new filter($where,array('order'=>'createTime DESC','limit'=>$limit));
    $filters  = $filter->get(array('id','name','fieldText','searcher','select','factor','rest','status','createTime'));
    
    //准备显示的内容
    $tbody = '';
    for($i=0;$i<$filter->iTotal();$i++)
    {
        $tbody .= '<tr><td class="width6">' . $filters['id'][$i] . '<label class="selected"></label></td>';
        $tbody .= '<td class="hidden" title="' . $filters['name'][$i] . '">' . $filters['name'][$i] . '</td>';
        $title = $filters['fieldText'][$i];
        $tbody .= "<td class=\"hidden\" title={$title}>" . $filters['fieldText'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $filters['searcher'][$i].  '">' . $filters['searcher'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $filters['select'][$i].  '">' . $filters['select'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $filters['factor'][$i].  '">' . $filters['factor'][$i] . '</td>';
        $tbody .= '<td class="hidden" title="' . $filters['rest'][$i].  '">' . $filters['rest'][$i] . '</td>';
        $tbody .= '<td>' . $filters['status'][$i] . '</td>';
        $tbody .= '<td>' . $filters['createTime'][$i] . '</td></tr>';   
    }
    
    if($filter->iTotal() > 0) //有可用数据提供显示
    {
        $back['status'] = 1;
        $back['tbody'] = $tbody;
        $operations = array('add','apply','import','export');
    }else
    {
        $back['status'] = 2;
        $operations = array('edit','add','delete','apply','import','export');
    }
    
    $back['operations'] = points::authorized($_SESSION['points']['category'][$item]['authority'],$operations);
    if(empty($back['operations'])){ $back['operations'] = '&nbsp;'; }
    points::jan($back);
