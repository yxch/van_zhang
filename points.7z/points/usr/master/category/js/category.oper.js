$(document).ready(function(){
	
	$('h2').click(function(){
		var parent = $(this).parent();
		if(parent.hasClass('show'))
		{
			parent.removeClass('show');
			parent.children('.row').hide();
		}else
		{
			parent.addClass('show');
			parent.children('.row').show();
		}
	});

	//===============类别=====================
	//保存category的初始值
	var category = getCategory();
	function getCategory()
	{
		return { "murl":$('#murl').val(), "pos":$('#pos').val(),"title":$('#title').val(),
				 "rid":$('#regions').val(),"tid":$('#template').val(),"status":$('#status').val()	};
	}
	$('#save-category').click(function(e){
		e.stopPropagation();
		var categories = getCategory(),submit = false,modified = {};
		for(var p in categories)
		{
			if(categories[p] != category[p]){ submit = true; modified[p] = categories[p]; }
		}
		if(!submit)
		{ 
			global.tip('没有可用于提交的内容,检查输入是否有误！','warning');
			return false; 
		}
		modified['id'] = $('#id').text();
		modified['murl'] = $.trim($('#murl').val());
		modified['rid'] = $('#regions').val();
		modified['tid'] = $('#template').val();
		$.post('ask/category.oper.ajx.php',modified,function(r){ 
			var json = $.parseJSON(r);
			if(json.status == 1)
			{
				global.tip(json.err,'success');
			}else{ global.tip(json.err,'error'); }
			category = getCategory(); //更新值列表
		});
	});
	
	/**
    var user = users();
    //用户指派
    $('#save-user').click(function(){
        $('#user-err').text('');
        var j = users(); //获取新值
        //基本校验
        if (j.murl.empty()) { $('#user-err').text('必须指定管理URL'); return false; }
        if (j.uid.empty() && j.username.empty()){$('#user-err').text('必须有用户指派'); return false; }
        if (!j.username.empty())
        {
            if ((!j.pwd1.empty() || !j.pwd2.empty()) && j.pwd1 != j.pwd2)
            {
                $('#user-err').text('两次输入的密码不一致,如果为空，则使用默认的密码'); return false;
            }
        }
        $('#user-err').text('');
        //是否允许提交
        var allowed = false;
        for(var p in j){ if(j[p] != user[p]){ allowed = true; break;}}
        if (!allowed){ $('#user-err').text('没有可用于提交的内容!'); return false; }
        
        var json = {"murl":j.murl,  "rid":j.rid, "status":j.status,
                    "uid":j.uid,    "username":j.username,
                    "alias":j.alias,"type":j.type        };
        if(!j.pwd1.empty()){ json.password = j.pwd1; }
        
        $.post('../users/ask/users.save.ajx.php',json,function(r){  //提交内容
            var jn = $.parseJSON(r);
            if(jn.status == '1')
            {
                user = users();
                $('#username').val('');
                $('#alias').val('');
                $('#password').val('');
                $('#pwd').val();
            }
            $('#user-err').text(jn.err);
        });
    });
    
    $('#user #lists .more').click(function(){
        var serial = $(this).attr('id').split('-')[1];
        if ($(this).hasClass('extend'))
        {
            $('#dis' + serial).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + serial).fadeIn();
            $(this).text('折叠>>');
        }
    });
    
    function users()
    {
        var user = document.getElementsByName('user');
        var selects = [];
        for(var i=0;i<user.length;i++){ if(user[i].checked){selects.push(user[i].value); } }
        
        return {"murl":$.trim($('#murl').val()),
                "rid":$('#regions').val(),
                "status":$('#status').val(),
                "uid":selects.join('|'),
                "username":$.trim($('#username').val()),
                "alias":$.trim($('#alias').val()),
                "type":$('#type').val(),
                "pwd1":$('#password').val(),
                "pwd2":$('#pwd').val()                      };
    } */

	//===============变量=====================
	 //为空值对象提供默认值
    $('#stime,#etime,#serial').focus(function(){
        var date = new Date();
        var v = $.trim($(this).val());
        if (v.empty())
        {
            var arr = [];
            arr.push(date.getFullYear(),String(date.getMonth() + 1).doubled(),String(date.getDate()).doubled());
            var time = [];
            time.push(String(date.getHours()).doubled(),String(date.getMinutes()).doubled(),String(date.getSeconds()).doubled());
            if ($(this).attr('id') == 'serial')
            {
                $(this).val(arr.join('') + time.join(''));
            }else{ $(this).val(arr.join('-') + ' ' + time.join(':'));}
        }
    });
	//保存初始值
	var variable = getVariable();
	function getVariable()
	{
		return {"stime":$.trim($('#stime').val()),    "etime":$.trim($('#etime').val()),
				"serial":$.trim($('#serial').val()),		"psize":$.trim($('#psize').val()),
				"cached":$.trim($('#cached').val()),	"shortid":$.trim($('#shortid').val()),
				"ssign":$.trim($('#ssign').val()),		"esign":$.trim($('#esign').val()),
				"limited":$.trim($('#limited').val()),	"auxiliary":$.trim($('#auxiliary').val())		};
	}
	
	$('#save-variable').click(function(e){
		e.stopPropagation();
		var variables = getVariable(),submit = false,modified = {},vcount = 0;
		for(var p in variables)
		{
			if(variables[p] != variable[p])
			{ 
				submit = true;
				modified[p] = variables[p];
				vcount += 1;
			}
		}
		if(vcount == 0 ||!submit){ global.tip('没有可用于提交的内容，请检查输入','warning');return false; }
		if(modified.serial && isNaN(parseInt(modified.serial)))
		{ 
			global.tip('标准类别序列号只能是数字','warning');
			return false;
		}
		if(modified.psize && isNaN(parseInt(modified.psize)))
		{ 
			global.tip('用户数据分页值只能是数字','warning');
			return false;
		}
		if(modified.cached && isNaN(parseInt(modified.cached)))
		{ 
			global.tip('缓存有效时间值只能是数字','warning');
			return false;
		}
		if(modified.auxiliary && isNaN(parseInt(modified.auxiliary)))
		{ 
			global.tip('附加信息标识符只能是一个数字','warning');
			return false;
		}
		modified.murl = $.trim($('#murl').val());
		if(modified.murl.empty())
		{
			global.tip('变量必须指定在相关的类别管理标识符murl下','warning');
			return false;
		}
		//提交内容
        $.post('ask/category.oper.vars.ajx.php',modified,function(r){ console.log(r);
            var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
			variable = getVariable(); //更新值列表
        });    
	});
	
	//===============用户过滤器=====================
    //获取表的内容
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
				var html = '<li class="rows">';
				html +=	'<span class="most"><input class="field" /></span>';
				html += '<span class="most"><input class="alias" /></span>';
				html += '<span><input class="primary" type="checkbox" /></span>';
				html += '<span><input class="increment" type="checkbox" /></span>';
				html += '<span><input class="updated" type="checkbox" /></span>';
				html += '<span><input class="dated" type="checkbox" /></span>';
				html += '<span class="most"><input class="translator" /></span>';
				html += '<span><input class="select" type="checkbox" /></span>';
				html += '</li>';
				$('#filter ul .rows').empty();
				$('#filter ul #capital').after(html);
                return false;
            }
            $.post('ask/category.oper.filter.db.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){ //console.log(r);
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
					$('#filter ul .rows').remove();
					$('#filter ul #capital').after(j.tbody);
					$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
					var rows = getTableInfo();
					var fields = rows.fields.split('|').join(',');
					$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
                }
            });
        }
    });  
	//获取表信息
	function getTableInfo()
	{
		var rows = $('#filter ul .rows');
		var fields = [],comment = [],primary = [],increment = [],updated = [],dated = [],translator = [],err = 0;
		var json = {"errNum":0};
		json.table = $.trim($('#tablename').val());
		rows.each(function(i,obj){
			var child = $(obj).children('span'),fname = '';
			child.each(function(j,obj){
				var input = $(obj).children('input');
				if(j == 0 && input.hasClass('field'))
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : fields.push(v);
					fname = v;
				}
				if(j == 1 && input.hasClass('alias'))	
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : comment.push(v);
				}
				if(j == 2 && input.hasClass('primary')){	if(input.is(':checked')){ primary.push(fname); }	}
				if(j == 3 && input.hasClass('increment')){	if(input.is(':checked')){ increment.push(fname); }	}
				if(j == 4 && input.hasClass('updated')){	if(input.is(':checked')){ updated.push(fname); }	}
				if(j == 5 && input.hasClass('dated')){	if(input.is(':checked')){ dated.push(fname); }	}
				if(j == 6 && input.hasClass('translator'))
				{	
					if(!$.trim(input.val()).empty()){ translator.push(fname + '=' + $.trim(input.val())); }	
				}
			});
		});
		json.fields = fields.join('|');
		json.comment = comment.join('|');
		json.primary = primary.join('|');
		json.increment = increment.join('|');
		json.updated = updated.join('|');
		json.dated = dated.join('|');
		json.translator = translator.join('|');
		json.errNum = err;
		return json;
	}
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
		var selected = $('#filter ul li .select');
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked'))
			{
				check.removeAttr('checked');
				var parent = check.parent().parent();
				parent.after(parent.clone());
				$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
			}
		});
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
    });
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){    
		var selected = $('#filter ul li .select'); 
		var selects = $('#filter ul .rows').length; 
		if($('#filter ul li .select:checked').length == selects){ return false; } //不能全部删除
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked')){	check.parent().parent().remove(); }
		});
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
    });
	$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
	//用户更正字段名称
	function selectUpdate()
	{
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#select').val('SELECT ' + fields + ' FROM ' + rows.table);
	}

	//保存过滤器
	$('#save-filter').click(function(e){ 
		e.stopPropagation();
		var filter = {}; 

		var id = $('#id').text();
		if(id.empty() || !global.positive(id))
		{
			global.tip('需要类别ID来限定过滤器的作用域【通常情况下先保存类别然后从类别列表界面来编辑】');return false;
		}
		filter.id = id;
		
		var title = $.trim($('#ftitle').val());
		if(title.empty())
		{
			global.tip('必须指定过滤器的标题【标题有利于识别管理标识符murl下不同的过滤器】');return false;
		}
		filter.title = title; //保存过滤器的标题
		
		var tb = getTableInfo();
		if(parseInt(tb.errNum) > 0)
		{
			global.tip('必须指定字段和标题名');return false;
		}
		filter.fields = tb.fields;
		filter.alias = tb.comment;
		filter.primary = tb.primary;
		filter.increment = tb.increment;
		filter.updated = tb.updated;
		filter.dated = tb.dated;
		filter.translator = tb.translator;
		filter.tblname = tb.table;

		filter.searcher = $.trim($('#fsearch').val());
		
		var select = $.trim($('#select').val());
		if(select.empty())
		{
			global.tip('必须指定SQL的查询部分');return false;
		}
		filter.select = select;
		
		filter.factor = $.trim($('#factor').val());
		filter.rest = $.trim($('#rest').val());
		
		$.post('ask/category.oper.filter.ajx.php',filter,function(r){ //console.log(r);
			var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
		});
	});
	
});
