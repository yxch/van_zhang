$(document).ready(function(){   
    var ask = 'ask/category.ajx.php';    
    grid(ask,{"page":1});
   
    //编辑类别
	$('#edit').click(function(){ 
		var id = $('#' + local.id).find('.id').text(); 
		id ? window.location.href="category.oper.php?cid=" + id : 	global.showError('没有可用于编辑的内容！');
	});
    
    //增加类别
	$('#add').click(function(){ 
		window.location.href="category.oper.php";
	});
    
    //删除类别
	$('#delete').click(function(){ //console.log(local);
		if(local.empty)
		{
			global.showError('不能删除一个空的条目！','warning') ;
		}else
		{
			var ar = [], selects = [],id = '';
			for(var p in local.select){ ar.push(p); }
			if(ar.length > 0)
			{
				for(var i=0;i<ar.length;i++){ selects.push(ar[i].split('_')[1]); }
				id = selects.join('|');
			}else
			{ 
				if(local.id)
				{
					id = local.id.split('_')[1];
				}else
				{ 
					global.showError('请选择要删除的条目【在要删除的条目上单击即可】！','error') ;
					return false;
				}
			} 
			if(id.empty()){  global.showError('发生错误，没有任何内容被选择！'); return false; }
			$.post('ask/category.delete.ajx.php',{"id":id},function(r){ 
				var j = $.parseJSON(r);
				if(j.status == 0)
				{
					global.showError(j.err);
				}else
				{ 
					global.showError(j.err,'success'); 
					//更新当前页面内容
					grid(ask,{"page":1});
				}
			});
		}
	});
	
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
   
	//获取显示数据并给全局变量赋值的函数
    function grid(url,json)
    {
        $.post(url,json,function(r){   //console.log(r);
            var j = $.parseJSON(r);  //返回的结果
            if (parseInt(j.status) == 1)
            {
                $('#ul').html(j.tbody);
				local.page = j.page;
				$('#paging span').html(paging(j).show());
				local.empty = parseInt(j.total) == 0 ? true : false;
            }
        });
    }
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v,"page":1});}
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v,"page":1});
    });
});
