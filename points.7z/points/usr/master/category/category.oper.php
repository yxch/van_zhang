<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //require_once ACCESSIBLED; //确认当前页面是否可正常访问
	//获取全部模板文件以供选择
	$templates = DBC::selected(SQL::GetTemplatesFromPointsTemplate,[]);
	//categogryId确认
    $categoryId = isset($_GET['cid']) ? $_GET['cid'] : '';
    if($categoryId && !ctype_digit($categoryId)){exit('Exception access violation');}
	//获取所有区域内容以供选择
	$regions = DBC::selected(SQL::GetRegionsFromPointsRegions,[]);
    //处理成id=>'用户数据-招商信诺'形式
    $settles = points::regions(); 
    
    //查询指定id的category信息
    $title = "增加类别";$murl = '';$name = '';$aurl = ''; $pos = ''; $rid = ''; $yes = 1;
    if($categoryId) //如果用户编辑类别
    {
        $title = "编辑类别[ID:<label id=\"id\">$categoryId</label>]";
        $categories = DBC::selected(SQL::GetCategoryFromPointsCategoryById,[':id'=>$categoryId],['one'=>TRUE]);
        $murl = $categories['managingURL'];
		$tid = $categories['templateId'];
        $name = $categories['title'];
        $pos = $categories['position'];
        $rid = $categories['regionId'];        
        $yes = $categories['status'];
    }    
    
    //显示全部用户以供选择 
    $user = new users(); 
    $users = $user->get(array('id','username','alias')); 
    $usersArr = array();
    for($i=0;$i<$user->iTotal();$i++)
    {
        $alias = $users['alias'][$i] ? '[' . $users['alias'][$i] . ']' : '';
        $usersArr[$users['id'][$i]] = $users['username'][$i] .$alias;
    }
    $groups = array_chunk($usersArr,3,true); //分组显示 每组显示3个，如果组数大于则第一组显示其余隐藏 用户点击更多时显示
    $li = '';
    $len = count($groups);
    for($j=0;$j<$len;$j++)
    {
        $li .= $j > 0 ? "<li id=\"dis{$j}\" style=\"display:none;\">" : '<li>';
        foreach($groups[$j] as $k=>$val)
        {
            $li .= "<label><input type=\"checkbox\" name=\"user\" value=\"{$k}\" />{$val}</label>";
        }
        //是否显示更多
        if($len > 0 && $j < $len - 1){ $n = $j + 1; $li .= "<label><a class=\"more\" id=\"more-{$n}\">更多>></a></label>"; }
        $li .= '</li>';
    }
?>
<!DCOTYPE html>
<html>
<head>
   <?php echo points::head(false); ?>
   <link rel="stylesheet" href="css/category.oper.css" />
   <script src="js/category.oper.js"></script>
   <script src="/points/cross/local/js/frame.js"></script>
</head>
<body>
	<h1><?php echo $title; ?></h1>
	<div id="category" class="show">
		<h2>
			<span class="title">为此类别指定管理URL参数<span>
			<a id="save-category"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a>
		</h2>
		<div class="row">                        
			<label>管理路径：</label><input type="text" id="murl" value="<?php echo $murl; ?>" />
			<label>隶属于：</label>
			<select id="pos">
				<option value="1" <?php echo $pos == 1 ? 'selected' : ''; ?>>前端显示页面</option>
				<option value="2" <?php echo $pos == 2 ? 'selected' : ''; ?>>后端管理页面</option>
			</select>
			<p class="desc">输入要管理的URL。如：http://www.test.org/aaaa/bbbb/ccc/.请确保输入没有空白且符合url规范。可以为不同的目录下的文件管理不同的类别内容。</p>
		</div>
		<div class="row">
			<label>类别的中文显示名：</label><input type="text" id="title" value="<?php echo $name; ?>" />
			<p class="desc">为此类别确定一个描述性中文显示名，这有助于与其它类别明确地区分开。</p>
		</div>
		<div class="row">
			<label>类别的显示区域：</label>
			<select id="regions">
				<?php for($j=0,$regionLen=count($regions);$j<$regionLen;$j++){ ?>
					<option dir="<?php echo $regions[$j]['directory'];?>" value="<?php echo $regions[$j]['id'];?>" <?php echo isset($rid) && $rid == $regions[$j]['id'] ? 'selected' : ''; ?>><?php echo $regions[$j]['name']; ?></option>
				<?php } ?>
			</select>

			<label>选择该类别使用的模板文件：</label>
			<select id="template">
				<?php for($i=0,$len=count($templates);$i<$len;$i++){ ?>
					<option value="<?php echo $templates[$i]['id'] ?>" title="<?php echo $templates[$i]['path'];?>" <?php echo isset($tid) && $tid == $templates[$i]['id'] ? 'selected' : ''; ?>><?php echo $templates[$i]['title']; ?></option>
				<?php } ?>
			</select>
			<p class="desc">提示：如果类别的模板文件没有显示在下拉列表中，请转到模板管理器注册指定的模板。在任何模板文件使用之前请先注册。在同一个类别中，同一个模板文件仅允许使用一次。</p>
		</div>
		<div class="row">
			<label>指定类别的状态：</label>
			<select id="status">
				<option value="1" <?php echo $yes == 1 ? 'selected' : ''; ?>>使用的类别</option>
				<option value="0" <?php echo $yes == 0 ? 'selected' : ''; ?>>废弃的类别</option>
			</select>
			<span class="desc">类别的状态决定当前类别是否被启用。如果废弃此类别相关内容将不会被检索到。</span>
		</div>
	</div>

	<div id="user">
		<h2>
			<span class="title">为此类别指定访问用户及相关权限<span>
			<a class="save"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a>
		</h2>
		<div class="row">
			<span class="opt grey">从用户表中选择用户</span>
			<ul id="lists"><?php echo $li; ?></ul>
			
			<span class="opt">
				<label class="grey">快速创建一个新用户</label>
				
				<label id="user-type">用户类型：</label>
				<select id="type">
					<option value="1">前端用户</option>
					<option value="2">后台用户</option>
					<option value="3">全局用户</option>
				</select>
			</span>
			<br />
			<label>用户名称：</label><input type="text" id="username" value="" />
			<label class="margin-left">用户显示名：</label><input type="text" id="alias" value="" />
			<label class="margin-left">用户密码：</label><input type="password" id="password" value="" />
			<label class="margin-left">确认此密码：</label><input type="password" id="pwd" value="" />
			<p class="desc">通常情况下，在为类别绑定用户时，使用从用户列表中选择用户或者快速创建一个新用户的一种方式即可。但如果为多个用户绑定类别并且一些用户并不存在则可结合两者来完成。</p>
		</div>
	</div>

	<div id="variable">
		<h2>
			<span class="title">为此类别初始化变量<span>
			<a id="save-variable"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a>
		</h2>
		<div class="row">
			<label>标准时间变量一[stime]：</label><input type="text" id="stime" value="" />
			<span class="desc">时间必须有效且格式为:2015-12-16 14:17:30,否则不能初始化</span>
		</div>
		<div class="row">
			<label>标准时间变量二[etime]：</label><input type="text" id="etime" value="" />
			<span class="desc">时间必须有效且格式为:2015-12-16 14:17:30,否则不能初始化</span>
		</div>
		<div class="row">
			<label>标准类别序列号[serial]：</label><input type="text" id="serial" value="" />
			<span class="desc">此变量的值为纯数字字符串，如：20151213171033。用户可以利用此变量来识别类别和程序流程判定。</span>
		</div>
		<div class="row">
			<label>用户数据分页值[psize]：</label><input type="text" id="psize" value="" />
			<span class="desc">如果初始化了此变量，则用户可以指定自定义的分页大小</span>
		</div>
		<div class="row">
			<label>缓存有效时间值[cached]:</label><input type="text" id="cached" value="" />
			<span class="desc">此变量可以定义缓存时间长度，请指定一个有效的时间值如86400秒。</span>
		</div>
		<div class="row">
			<label>类别变量短标识[shortid]:</label><input type="text" id="shortid" value="" />
			<span class="desc">此变量可以定义类别短标识符，此标识的长度不得超过8个字符。</span>
		</div>                    
		<div class="row">
			<label>启用起始标识符[ssign]:</label><input type="text" id="ssign" value="" />
			<span class="desc">此变量定义一个标识符通常是一个URL,其作用是在活动未开始时进入的页面地址。也可以用作其它用途。</span>
		</div>
		<div class="row">
			<label>启用终止标识符[esign]:</label><input type="text" id="esign" value="" />
			<span class="desc">此变量定义一个标识符通常是一个URL,其作用是在活动已结束时进入的页面地址。也可以用作其它用途。</span>
		</div>
		<div class="row">
			<label>类别范围变量值[limited]:</label><input type="text" id="limited" value="" />
			<span class="desc">此变量定义一个整型的范围，比如：0-100，请使用标准的分隔符，否则校验失败。</span>
		</div>
		<div class="row">
			<label>附加信息标识符[auxiliary]:</label><input type="text" id="auxiliary" value="" />
			<span class="desc">此变量定义一个0-9之间的任意值来标识附加信息是否启用以及启用类型。</span>
		</div>
	</div>

	<div id="filter">
		<h2>
			<span class="title">为此类别初始化用户数据过滤器<span>
			<a id="save-filter"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a>
		</h2>
		<div class="row">
			<label>为此数据过滤器定义一个标题：</label><input type="text" id="ftitle" value="" />
			<p class="desc">标题可以识别此数据过滤器，易于用户在多个不同的数据过滤器之间切换，并根据标题来识别此数据过滤器的用途。</p>
		</div>
		<div class="row">
			<label class="opt">为此数据过滤器添加数据字段和显示字段及翻译设定</label>
			<span id="dbinfo">
				<select id="dbname">
					<option value="1">活动数据库</option>
					<option value="2">drupal基础数据库</option>
				</select>
				<label id="tname">表名：</label><input id="tablename" value="" />
			</span>
		</div>
		<ul class="row">
			<li id="capital">
				<span class="most">数据表字段</span>
				<span class="most">显示标题名</span>
				<span>主键</span>
				<span>序列</span>
				<span>更正</span>
				<span>时间</span>
				<span class="most">翻译设定</span>
				<span>操作</span>
				<span class="plus"><a id="fadd"> + </a><a id="fdelete"> - </a></span>
			</li>
			<li class="rows">
				<span class="most"><input class="field" /></span>
				<span class="most"><input class="alias" /></span>
				<span><input class="primary" type="checkbox" /></span>
				<span><input class="increment" type="checkbox" /></span>
				<span><input class="updated" type="checkbox" /></span>
				<span><input class="dated" type="checkbox" /></span>
				<span class="most"><input class="translator" /></span>
				<span><input class="select" type="checkbox" /></span>
			</li>
		</ul>
		<div class="row">
			<p class="desc">必须提供字段名和字段的描述性文字。描述性文字将在数据导出时显示为表格的标题。如果主键被选定，这将为此过滤器记录此字段为主键;如果序列被选中，将记录为自动序列通常是id;如果更正被选中，标明此字段可以在一定条件下被用户手动更新其值;如果时间字段被选中，标明此字段是记录的创建的时间；翻译设定可以为此字段使用额外的函数。</p>
		</div>
		<div class="row">
			<label>基于此过滤器的搜索设定：</label><input type="text" id="fsearch" value="" />
			<p class="desc">设定此数据过滤器的搜索选项,如果多个搜索选项请用英文逗号分号,注意搜索选项必须在上面的字段中出现。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器的SQL语句：</label>　 <textarea id="select"></textarea>
			<p class="desc">提供此过滤器SQL语句的SELECT部分，可以不提供字段。但必须完整提供表名和剩余的部分。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器的预设部分[1]：</label><textarea id="factor"></textarea>
			<p class="desc">提供此过滤器SQL语句的WHERE子名部分,此方法可能不适用于太复杂的查询语句。请使用视图的方法来简化复杂查询。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器的预设部分[2] ：</label><textarea id="rest"></textarea>
			<p class="desc">提供此过滤器SQL语句的其它部分。通常LIMIT由程序自动处理。</p>
		</div>
	</div>
</body>
</html>