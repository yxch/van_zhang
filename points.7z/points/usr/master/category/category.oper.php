<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $categoryId = isset($_GET['cid']) ? $_GET['cid'] : '';
    if($categoryId && !ctype_digit($categoryId)){exit('Exception access violation');}
    
    $region = new regions(array('status'=>1),array('order'=>'region ASC,createTime DESC'));
    $regions = $region->get(array('id','name','region','directory')); 
    //处理成id=>'用户数据-招商信诺'形式
    $arr = array();
    $regionRelations = points::regions(); 
    for($i=0;$i<$region->iTotal();$i++){ $arr[$regions['id'][$i]] = $regionRelations[$regions['region'][$i]] . '=>' . $regions['name'][$i];}
    
    //变量定义
    $title = "增加类别";$murl = '';$name = '';$aurl = ''; $pos = ''; $rid = ''; $yes = 1;
    if($categoryId) //如果用户编辑类别
    {
        $title = "编辑类别[ID:<label id=\"id\">$categoryId</label>]";
        $category = new category(array('id'=>$categoryId));
        $categories = $category->get(array('regionId','title','managingURL','accessedURL','position','status')); 
        $murl = $categories['managingURL'][0];
        $name = $categories['title'][0];
        $aurl = strtr($categories['accessedURL'][0],array($regions['directory'][array_search($categories['regionId'][0],$regions['id'])]=>''));
        $pos = $categories['position'][0];
        $rid = $categories['regionId'][0];        
        $yes = $categories['status'][0];
    }    
    
    //显示全部用户以供选择 
    $user = new users(); 
    $users = $user->get(array('id','username','alias')); 
    $usersArr = array();
    for($i=0;$i<$user->iTotal();$i++)
    {
        $alias = $users['alias'][$i] ? '[' . $users['alias'][$i] . ']' : '';
        $usersArr[$users['id'][$i]] = $users['username'][$i] .$alias;
    }
    $groups = array_chunk($usersArr,3,true); //分组显示 每组显示3个，如果组数大于则第一组显示其余隐藏 用户点击更多时显示
    $li = '';
    $len = count($groups);
    for($j=0;$j<$len;$j++)
    {
        $li .= $j > 0 ? "<li id=\"dis{$j}\" style=\"display:none;\">" : '<li>';
        foreach($groups[$j] as $k=>$val)
        {
            $li .= "<label><input type=\"checkbox\" name=\"user\" value=\"{$k}\" />{$val}</label>";
        }
        //是否显示更多
        if($len > 0 && $j < $len - 1){ $n = $j + 1; $li .= "<label><a class=\"more\" id=\"more-{$n}\">更多>></a></label>"; }
        $li .= '</li>';
    }
?>
<!DCOTYPE html>
<html>
    <head>
       <?php echo points::head(false); ?>
       <link rel="stylesheet" href="/points/usr/local/css/master.css" />
       <link rel="stylesheet" href="css/category.oper.css" />
       <script src="js/category.oper.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic"><h1><?php echo $title; ?></h1><span id="err"></span></div>
            <div id="category">
                <div id="categories">
                    <p class="title"><a>为此类别指定管理URL参数</a></h2>
                    <div id="dv-url">                        
                        <p id="m-url">
                            <label>管理路径：</label><input type="text" id="murl" value="<?php echo $murl; ?>" />
                            <label>隶属于：</label>
                            <select id="pos">
                                <option value="1" <?php echo $pos == 1 ? 'selected' : ''; ?>>前端显示页面</option>
                                <option value="2" <?php echo $pos == 2 ? 'selected' : ''; ?>>后端管理页面</option>
                            </select>
                        </p>
                        <p class="desc">输入要管理的URL。如：http://www.test.org/aaaa/bbbb/ccc/.请确保输入没有空白且符合url规范。可以为不同的目录下的文件管理不同的类别内容。</p>
                    </div>
                    <div id="dv-title">
                        <label>类别的中文显示名：</label><input type="text" id="title" value="<?php echo $name; ?>" />
                        <span class="desc">为此类别确定一个描述性中文显示名，这有助于与其它类别明确地区分开。</span>
                    </div>
                    <div id="dv-region">
                        <p>
                            <label>类别的显示区域：</label>
                            <select id="regions">
                                <?php foreach($arr as $k=>$v){ ?>
                                    <option dir="<?php echo $regions['directory'][array_search($k,$regions['id'])]; ?>" value="<?php echo $k; ?>" <?php echo $rid == $k ? 'selected' : ''; ?>><?php echo $v; ?></option>
                                <?php } ?>
                            </select>
                            
                            <label>指定该类别的状态：</label>
                            <select id="status">
                                <option value="1" <?php echo $yes == 1 ? 'selected' : ''; ?>>数据列表类别</option>
                                <option value="2" <?php echo $yes == 2 ? 'selected' : ''; ?>>数据搜索类别</option>
                                <option value="0" <?php echo $yes == 0 ? 'selected' : ''; ?>>废弃的类别</option>
                            </select>
                        </p>
                        <p>
                            <label>指定该类别的访问路径：</label>
                            <label id="dir"></label>
                            <input type="text" id="aurl" value="<?php echo $aurl; ?>" />
                        </p>
                        <p class="desc">区域的目录与类别的访问路径组合成访问URL，即为此类别指定模块文件。</p>
                    </div>
                    <div class="apply"><span class="error" id="category-err"></span><a id="save-category" _id="<?php echo $categoryId; ?>">保存此类别</a></div>
               </div>
               
               <div id="user">
                    <p class="title"><a class="closed"><img src="/points/usr/local/images/plus.png" />  为此类别指定访问用户及相关权限</a></h2>
                    <div id="old-users">
                        <label>从用户表中选择用户：</label>
                        <ul id="lists"><?php echo $li; ?></ul>
                    </div>
                    <div id="new-user">
                        <label>快速创建一个新用户:</label>
                        <p>
                            <label>用户名称：</label><input type="text" id="username" value="" />
                            <label>用户显示名：</label><input type="text" id="alias" value="" />
                            <span id="sp-type">
                                <label>用户类型：</label>
                                <select id="type">
                                    <option value="1">前端用户</option>
                                    <option value="2">后台用户</option>
                                    <option value="3">全局用户</option>
                                </select>
                            </span>
                        </p>
                        <p><label>用户密码：</label><input type="password" id="password" value="" /><label>确认此密码：</label><input type="password" id="pwd" value="" /></p>
                        <p class="desc">通常情况下，在为类别绑定用户时，使用从用户列表中选择用户或者快速创建一个新用户的一种方式即可。但如果为多个用户绑定类别并且一些用户并不存在则可结合两者来完成。</p>
                    </div>
                    <div class="apply"><span class="error" id="user-err"></span><a id="save-user">用户指派</a></div>
               </div>
        
                <div id="variable">
                    <p class="title"><a class="closed"><img src="/points/usr/local/images/plus.png" />  为此类别初始化变量</a></p>
                    <div id="dv-time">
                        <label>标准时间变量一[stime]：</label><input type="text" id="stime" value="" />
                        <label>标准时间变量二[etime]：</label><input type="text" id="etime" value="" />
                        <p class="desc">如果初始化了时间变量，则此类别可以根据用户输入的时间值来确定某些活动有效时间范围。时间必须有效且格式为:2015-12-16 14:17:30,否则不能初始化</p>
                    </div>
                    <div id="dv-serial">
                        <label>标准类别序列号[serial]：</label>　<input type="text" id="serial" value="" />
                        <span class="desc">此变量的值为纯数字字符串，如：20151213171033。用户可以利用此变量来识别类别和程序流程判定。</span>
                    </div>
                    <div id="dv-psize">
                        <label>用户数据分页值[psize]：</label>　<input type="text" id="psize" value="" />
                        <span class="desc">如果初始化了此变量，则用户可以指定自定义的分页大小</span>
                    </div>
                    <div id="dv-cached">
                        <label>缓存有效时间值[cached]:</label>　<input type="text" id="cached" value="" />
                        <span class="desc">此变量可以定义缓存时间长度，请指定一个有效的时间值如86400秒。</span>
                    </div>
                    <div id="dv-shortid">
                        <label>类别变量短标识[shortid]:</label>　<input type="text" id="shortid" value="" />
                        <span class="desc">此变量可以定义类别短标识符，此标识的长度不得超过8个字符。</span>
                    </div>                    
                    <div id="dv-ssign">
                        <label>启用起始标识符[ssign]:</label>　　<input type="text" id="ssign" value="" />
                        <span class="desc">此变量定义一个标识符通常是一个URL,其作用是在活动未开始时进入的页面地址。也可以用作其它用途。</span>
                    </div>
                    <div id="dv-esign">
                        <label>启用终止标识符[esign]:</label>　　<input type="text" id="esign" value="" />
                        <span class="desc">此变量定义一个标识符通常是一个URL,其作用是在活动已结束时进入的页面地址。也可以用作其它用途。</span>
                    </div>
                    <div id="dv-limited">
                        <label>类别范围变量值[limited]:</label>　<input type="text" id="limited" value="" />
                        <span class="desc">此变量定义一个整型的范围，比如：0-100，请使用标准的分隔符，否则校验失败。</span>
                    </div>
                    <div id="dv-auxiliary">
                        <label>附加信息标识符[auxiliary]:</label>　<input type="text" id="auxiliary" value="" />
                        <span class="desc">此变量定义一个0-9之间的任意值来标识附加信息是否启用以及启用类型。</span>
                    </div>
                    <div class="apply"><span class="error" id="variable-err"></span><a id="save-var">初始化变量</a></div>
               </div>
                
               <div id="filter">
                    <p class="title"><a class="closed"><img src="/points/usr/local/images/plus.png" /> 为此类别初始化用户数据过滤器 </a></p>
                    <div id="ftitle">
                        <label>为此数据过滤器定义一个标题：</label><input type="text" id="filter-title" value="" />
                        <span class="desc">标题可以识别此数据过滤器，易于用户在多个不同的数据过滤器之间切换，并根据标题来识别此数据过滤器的用途。</span>
                    </div>
                    <div id="field">
                        <p id="field-options">
                            <label>为此数据过滤器添加数据字段和显示字段及翻译设定：</label>
                            <span>
                                <select id="dbname">
                                    <option value="1">活动数据库</option>
                                    <option value="2">drupal基础数据库</option>
                                </select>
                                <label id="tname">表名：</label><input id="tablename" value="" />
                            </span>
                        </p>
                        <table id="fields">
                            <thead>
                                <tr>
                                    <td>数据表字段</td>
                                    <td>显示名</td>
                                    <td>翻译设定</td>
                                    <td>标识符</td>
                                    <td><a id="fadd">+</a><a id="fdelete">-</a></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                     <td><input type="text" value="" /></td>
                                     <td><input type="text" value="" /></td>
                                     <td><input type="text" value="" /></td>
                                     <td><input type="text" value="" /></td>
                                     <td><input type="checkbox" class="check" /></td>
                                </tr> 
                            </tbody>
                        </table>
                        <p class="desc">数据表字段必须与相关表的字段一致 (不要写映射名，映射名无法在此条件下处理)，显示名在用户查询数据时显示，通常是表字段中文名称。翻译设定值是数组的单元通常是关联数组，比如：要将F显示成女，翻译字段内容填写为 'F':'女'多个翻译值用英文空格隔开。</p>
                    </div>
                    <div id="search">
                        <label>基于此过滤器的搜索设定：</label><input type="text" id="fsearch" value="" />
                        <p class="desc">设定此数据过滤器的搜索选项,如果多个搜索选项请用英文逗号分号,注意搜索选项必须在上面的字段中出现。</p>
                    </div>
                    <div class="sql">
                        <label>此数据过滤器SQL语句SELECT部分：</label><textarea id="select"></textarea>
                        <p class="desc">提供此过滤器SQL语句的SELECT部分，可以不提供字段。但必须完整提供表名和剩余的部分。</p>
                    </div>
                    <div class="sql">
                        <label>此数据过滤器SQL语句WHERE部分：</label><textarea id="factor"></textarea>
                        <p class="desc">提供此过滤器SQL语句的WHERE子名部分,此方法可能不适用于太复杂的查询语句。请使用视图的方法来简化复杂查询。</p>
                    </div>
                    <div class="sql">
                        <label>　 此数据过滤器SQL语句其它部分 ：</label><textarea id="rest"></textarea>
                        <p class="desc">提供此过滤器SQL语句的其它部分。通常LIMIT由程序自动处理。</p>
                    </div>
                    <div class="apply" ><span class="error" id="filter-err"></span><a id="save-filter">保存此过滤器</a></div>
               </div>
            </div>
        </div>
        <div id="announce"></div>
    </body>
</html>