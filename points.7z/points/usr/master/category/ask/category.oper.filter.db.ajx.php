<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $back = array('yes'=>0,'tbody'=>'','tip'=>'');
    
    //连接到测试或生产的drupal基础数据库
    $dbname = 'drupal_activity';
    if($_POST['db'] == '2')
    {
        $pdo = DBC::PDO('default','default');
        $dbname = 'drupal_cmb';
    }
    
    $table = DBC::selected('SHOW TABLES FROM ' . $dbname,[]); //获取指定数据库中的全部表
    $tables = array(); 
    for($i=0,$len=count($table);$i<$len;$i++){ $_tmp = array_values($table[$i]); $tables[] = $_tmp[0]; }
  
    //提供的表名是否有效    
    if(!in_array($_POST['tb'],$tables)){ $back['tip'] = '无效的表名'; points::jan($back);  }
    
    //获取表的字段及注释
    $column = DBC::selected('SHOW FULL COLUMNS FROM ' . $_POST['tb'],[]);
    for($j=0,$l=count($column);$j<$l;$j++)
    {
        $back['tbody'] .= '<li class="rows">';
		$back['tbody'] .= '<span class="most"><input class="field"  value="' . $column[$j]['Field'] . '" /></span>&nbsp;';
		$back['tbody'] .= '<span class="most"><input class="alias"  value="' . (empty($column[$j]['Comment']) ? $column[$j]['Field'] : $column[$j]['Comment']) . '" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="primary" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="increment" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="updated" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="fsearch" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="dated" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '<span class="most"><input class="translator" /></span>&nbsp;';
		$back['tbody'] .= '<span><input class="select" type="checkbox" /></span>&nbsp;';
		$back['tbody'] .= '</li>';
    }
    $back['yes'] = 1;
    points::jan($back);