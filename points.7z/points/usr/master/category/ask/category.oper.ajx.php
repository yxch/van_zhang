<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
	
	$back = ['status'=>0,'err'=>''];  //返回的结果

	$edit = false; $fields = []; //注意写入的键名与数据表字段名一致
	if(isset($_POST['id']) && !empty($_POST['id']))  //校验id
	{
		$edit = true;
		if(!ctype_digit($_POST['id'])){ $back['err'] = '提供的id不可用！';	points::jan($back);	}
	}
	if(isset($_POST['murl'])) //检查提供的管理 URL
	{
		$murls = points::SURL($_POST['murl'],true); 
		if(!$murls['status']){	$back['err'] = '无效的管理URL,请检查输入！'; points::jan($back); }
		$fields['murl'] = $murls['url'];
		$fields['md5'] = $murls['md5'];
		
	}else{  $back['err'] = '没有提供管理URL,请检查输入！'; points::jan($back); }
	
	if(isset($_POST['pos'])) //检查提供的位置标识符
	{
		if(!ctype_digit($_POST['pos'])){	$back['err'] = '位置不是一个有效值.'; points::jan($back); }
		$fields['pos'] = $_POST['pos'];
	}
	if(isset($_POST['title']))
	{
		if(empty($_POST['title'])){ $back['err'] = '标题不能为空.'; points::jan($back); }
		$fields['title'] = trim($_POST['title']);
	}
	if(isset($_POST['rid'])) //检查rid是否是有效的标识符
	{
		if(!ctype_digit($_POST['rid'])){ $back['err'] = '区域不是一个有效值.'; points::jan($back); }
		$fields['rid'] = $_POST['rid'];
	}else{ $back['err'] = '没有提供区域id'; points::jan($back); }
	
	if(isset($_POST['tid'])) //检查模板文件id
	{
		if(!ctype_digit($_POST['tid'])){ $back['err'] = '模板文件标识不是一个有效值.'; points::jan($back); } 
		$fields['tid'] = $_POST['tid'];
	}else{ $back['err'] = '没有提供模板id'; points::jan($back); }
	
	if(isset($_POST['status'])) //检查提供的类型标识符 用户的 系统的 废弃的
	{
		if(!ctype_digit($_POST['status'])){ $back['err'] = '类别类型标识不是一个有效值.'; points::jan($back); }
		$fields['yes'] = $_POST['status'];
	}
	$authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
	if($edit)
	{
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['err'] = '用户权限请求'; points::jan($back); }

		//同一murl下同一区域id只存在一个模板id
		$isExistCategory = DBC::selected(SQL::GetCategoryExistFromPointsCategory,
										[':id'=>$_POST['id'],
										':md5'=>$fields['md5'],
										':rid'=>$fields['rid'],
										':tid'=>$fields['tid'] ],	['one'=>TRUE]);
		if($isExistCategory['total'] > 0)
		{
			$back['err'] = '存在相同的类别条目';  points::jan($set);
		}
		
		$fields['mtime'] = date('Y-m-d H:i:s');
		$SQL = 'UPDATE  ' . SQL::TblCategory . ' SET ';
		$updates = ''; $bind = [];
		foreach($fields AS $k=>$v)
		{	
			$updates .= $k . '=:' . $k . ','; 	
			$bind[':'.$k] = $v;
		}
		$updates = trim($updates,',');
		$bind[':id'] = $_POST['id'];
		$SQL .= $updates . ' WHERE id=:id';
		$stmt = DBC::PDO()->prepare($SQL);
		if($stmt->execute($bind))
		{
			$back['status'] = 1;
			$back['err'] = '修改成功!';
		}else{ $back['err'] = '修改失败，请检查输入再重试!'; }
		points::jan($back);		
	}else
	{ 
		//当前用户是否有新增条目的权限
        if(!points::allowed($authority,'add')){ $back['err'] = '用户权限请求'; points::jan($back); }
		if(!isset($fields['title']) || empty($fields['title']))
		{ 
			$back['err'] = '提供的类别标题不能为空'; points::jan($back); 
		}
		//同一murl下同一区域id只存在一个模板id
		$isExistCategory = DBC::selected(SQL::GetAddCategoryExistFromPointsCategory,
										[':md5'=>$fields['md5'],
										':rid'=>$fields['rid'],
										':tid'=>$fields['tid'] ],	['one'=>TRUE]);
		if($isExistCategory['total'] > 0)
		{
			$back['err'] = '添加失败，存在相同的类别条目';  points::jan($back);
		}
		if(DBC::modified(SQL::NewCategoryInPointsCategory,$fields))
		{
			$back['status'] = 1;
			$back['err'] = '新建类别成功！';
		}else{ $back['err'] = '新建类别失败'; }
		points::jan($back);
	}