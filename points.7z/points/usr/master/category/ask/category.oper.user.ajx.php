<?php
	require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';    
	
	$authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    $userType = $_SESSION['points']['user']['type'];
	
	$back = ['status'=>0,'tip'=>'unkown error','type'=>'error']; //请求的结果响应
	
	//检查类别id
	if(!isset($_POST['id']) || !ctype_digit($_POST['id']))
	{
		$back['tip'] = '指派的用户必须在一个类别名称下，请先保存类别后再指派用户！';
		points::jan($back);
	}
	if(!isset($_POST['region']) || !ctype_digit($_POST['region']))
	{
		$back['tip'] = '没有选择区域，默认的用户权限根据选择的区域不同而不同！';
		points::jan($back);
	}
	//检查uid和用户名是否为空
	if(empty($_POST['uid']) && empty($_POST['name']))
	{
		$back['tip'] = '没有用户被指派！';
		points::jan($back);
	}
	$powers = [];  //uid集合
	//检查uid
	if(!empty($_POST['uid']))
	{
		$arr = explode('|',$_POST['uid']);
		for($i=0,$l=count($arr);$i<$l;$i++)
		{
			if(!ctype_digit($arr[$i]))
			{
				$back['tip'] = '异常的请求！';
				points::jan($back);
			}
			$powers[] = $arr[$i];
		}
	}
	//用户名不能是中文
	if(!empty($_POST['name']))
	{
		if(STR::isChinese($_POST['name']))
		{
			$back['tip'] = '用户名不能是中文';
			points::jan($back);
		}

		//用户别名不能超过16个字符
		if(!empty($_POST['alias']))
		{
			if(mb_strlen($_POST['alias'],'UTF-8') > 16)
			{
				$back['tip'] = '用户显示名太长！';
				points::jan($back);
			}
		}
		$username = trim($_POST['name']);
		//用户类型
		if(!isset($_POST['type']) || !ctype_digit($_POST['type']))
		{
			$back['tip'] = '异常请求！';
			points::jan($back);
		}

		$pwd = 'd847f5bbe427010efbf1e27934b8efcb';
		
		$exist = DBC::selected(SQL::GetCountsFromPointsUsersByUsername,
				  [':usr'=>$username],['one'=>TRUE]);
		if($exist['total'] > 0)
		{
			$back['tip'] = '用户名已存在';
			points::jan($back);
		}
		//新建用户
		$inserts = [':usr'=>$username,	':pwd'=>$pwd,
			        ':alias'=>trim($_POST['alias']),':email'=>'',':ppath'=>'',':tye'=>$_POST['type']];
		$lastInsertedId = DBC::modified(SQL::NewUserInPointsUsers,$inserts,['LID'=>TRUE]);
		if($lastInsertedId > 0)
		{	
			$powers[] = $lastInsertedId; // 保存插入的uid
		}else
		{
			$back['tip'] = '创建用户失败！';
			points::jan($back);
		}
	}
	//默认的权限
	$regions = DBC::selected(SQL::GetRegionsPowerFromPointsRegionsById,[':id'=>$_POST['region']],['one'=>TRUE]);
	//类别的id和标题
	$category = DBC::selected(SQL::GetCategoryTitleFromPointsCategoryById,[':id'=>$_POST['id']],['one'=>TRUE]);
	$powersIn = [];
	for($j=0,$len=count($powers);$j<$len;$j++)
	{
		$powersIn[$j][':uid'] = $powers[$j];
		$powersIn[$j][':cid'] = $_POST['id'];
		$powersIn[$j][':ctitle'] = $category['title'];
		$powersIn[$j][':auth'] = $regions['authority'];
	}
	
	//写入权限信息
	if(DBC::modified(SQL::NewPowerInPointsPower,$powersIn))
	{
		$back['tip'] = '权限指派成功，转到权限管理器可以修改默认的权限！';
		$back['type'] = 'success';
		points::jan($back);
		
	}else{ $back['tip'] = '权限指派失败,检查服务！'; }