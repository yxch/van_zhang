<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限

	$back = array('status'=>0,'tip'=>''); //响应请求的结果
	$inserts = []; //保存插入数据
	
	$editor = false;
	if(isset($_POST['fid']) && ctype_digit($_POST['fid']))
	{
		$editor = true;
		//当前用户是否有新增条目的权限
		if(!points::allowed($authority,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
		$inserts[':mtime'] = date('Y-m-d H:i:s');
		$inserts[':id'] = $_POST['fid'];
	}else
	{
		//当前用户是否有新增条目的权限
		if(!points::allowed($authority,'add')){ $back['tip'] = '用户权限请求'; points::jan($back); }
	}

	if(empty($_POST['id']) || !ctype_digit($_POST['id']))
	{
		$back['tip'] = '需要类别ID来限定过滤器的作用域【通常情况下先保存类别然后从类别列表界面来编辑】'; 
		points::jan($back);
	}
	$inserts[':cid'] = (int)$_POST['id'];
	
	if(empty($_POST['title'])) //检查过滤器的标题
	{
		$back['tip'] = '必须指定过滤器的标题【标题有利于识别管理标识符murl下不同的过滤器】'; points::jan($back);
	}
	$inserts[':name'] = trim($_POST['title']);
    
	$fields = []; //保存字段信息
	if(empty($_POST['fields'])) //检查字段
	{
		$back['tip'] = '必须指定过滤器字段'; points::jan($back);
	}
	$fields['fields'] = explode('|',trim($_POST['fields']));

	if(empty($_POST['alias'])) //检查字段的显示名
	{
		$back['tip'] = '必须指定过滤器字段的显示名'; points::jan($back);
	}
	$fields['alias'] = explode('|',trim($_POST['alias']));

	if(count($fields['fields']) != count($fields['alias'])) //字段与显示名必须一致
	{
		$back['tip'] = '字段与显示名不一致'; points::jan($back);
	}

	if(!empty($_POST['primary'])) //检查提供的主键信息
	{
		$fields['primary'] = explode('|',trim($_POST['primary']));
		if(count($fields['primary']) > 1)
		{
			$back['tip'] = '目前仅支持单一主键，不支持复合主键的处理方式！'; points::jan($back);
		}
	}else{ $fields['primary'] = []; }
	
	if(!empty($_POST['increment'])) //检查提供的序列信息
	{
		$fields['increment'] = explode('|',trim($_POST['increment']));
	}else{ $fields['increment'] = []; }

	if(!empty($_POST['updated'])) //检查提供的用户可更正信息
	{
		$fields['updated'] = explode('|',trim($_POST['updated']));
	}else{ $fields['updated'] = []; }

	if(!empty($_POST['fsearch'])) //检查提供的搜索字段
	{
		$fields['fsearch'] = explode('|',trim($_POST['fsearch']));
	}else{ $fields['fsearch'] = []; }
	
	if(!empty($_POST['dated'])) //如果提供记录创建时间信息
	{
		$fields['dated'] = explode('|',trim($_POST['dated']));
	}else{ $fields['dated'] = []; }

	if(!empty($_POST['translator'])) //如果提供额外的函数处理信息
	{
		$fields['translator'] = [];
		$translators = trim($_POST['translator']);
		$transExp = explode('|',$translators);
		for($i=0,$len=count($transExp);$i<$len;$i++)
		{
			$tmp = explode('=',$transExp[$i]);
			$fields['translator'][$tmp[0]] = $tmp[1];
		}
	}else{ $fields['translator'] = []; }
	
	if(!empty($_POST['tblname'])) //如果提供了表名信息
	{
		$fields['tbl'] = trim($_POST['tblname']);
	}else{ $fields['tbl'] = ''; }
	
	$inserts[':fields'] = json_encode($fields);

	$statements = [];
	if(empty($_POST['totalize']))
	{
		$back['tip'] = '必须指定过滤器计算条目总数的SQL语句！'; points::jan($back);
	}
	$statements['totalize'] = trim($_POST['totalize']);
	if(empty($_POST['statement']))
	{
		$back['tip'] = '必须指定过滤器的查询语句！'; points::jan($back);
	}
	$statements['statement'] = trim($_POST['statement']); 
	$statements['condition'] = trim($_POST['condition']);
	
	$inserts[':select'] = json_encode($statements);
	$inserts[':flag'] = md5($inserts[':fields'].$inserts[':select']);
	
	if($editor)
	{
		//查询此过滤是否已创建
		$count = DBC::selected(SQL::GetFilterFromPointsFiltersByFlagId,
			     [':cid'=>$inserts[':cid'],':flag'=>$inserts[':flag'],':id'=>$inserts[':id']],['one'=>TRUE]);
		if($count['total'] > 0)
		{
			$back['tip'] = '过滤器已存在【类别id和过滤器的表信息的签名确定了过滤器的唯一性】！'; points::jan($back);
		}
		if(!ctype_digit($_POST['status']) || !in_array($_POST['status'],['0','1']))
		{
			$back['tip'] = '提供了一个无效的过滤器状态值！'; points::jan($back);
		}
		$inserts[':status'] = $_POST['status'];
		if(DBC::modified(SQL::SetFilterInPointsFilterById,$inserts))
		{
			$back['status'] = 1;
			$back['tip'] = '更新过滤器成功！';
		}else{ $back['tip'] = '更新过滤器失败,可能是网络原因，请稍候重试!'; }
		
	}else
	{
		//查询此过滤是否已创建
		$count = DBC::selected(SQL::GetFilterFromPointsFiltersByFlag,[':cid'=>$inserts[':cid'],':flag'=>$inserts[':flag']],['one'=>TRUE]);
		if($count['total'] > 0)
		{
			$back['tip'] = '过滤器已存在【类别id和过滤器的表信息的签名确定了过滤器的唯一性】！'; points::jan($back);
		}
		if(DBC::modified(SQL::NewFilterInPointsFilters,$inserts))
		{
			$back['status'] = 1;
			$back['tip'] = '保存过滤器成功！';
		}else{ $back['tip'] = '保存过滤器失败,可能是网络原因，请稍候重试!'; }
	}
	
	points::jan($back);