<?php
    session_start();
    $categoryId = isset($_GET['cid']) ? $_GET['cid'] : '';
    if(!ctype_digit($categoryId) || empty($categoryId)){ exit('Require parameter error or missing'); }
    $_SESSION['points']['item']['id'] = $categoryId;
    
    //是否是访问此用户权限范围内的类别 如果不是跳转到登录页 请验证这个判断是否绝对可靠
    $request = explode('?',$_SERVER['REQUEST_URI']);
    $key = array_search($request[0],$_SESSION['points']['category'][$categoryId]);
    if(!$key){  echo '<script>window.top.document.location="/points/usr/login/"</script>'; exit;  }
?>

