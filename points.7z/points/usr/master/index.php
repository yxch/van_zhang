<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
	
    //是否正常登录或者用户切换到其它目录
    $isLogin = !isset($_SESSION['points']['user']['username']) ||
               !isset($_SESSION['points']['user']['id']) ||
               $_SESSION['points']['subrange']['directory'] != '/points/usr/master/';
               
    if($isLogin){  header("Location:/points/usr/login/"); exit; }

	$arr = array('head'=>array('title'=>$_SESSION['points']['region']['name']),
				'username'=>$_SESSION['points']['user']['username'],
				'status'=>'[' . $_SESSION['points']['user']['id'] . '] ' . $_SESSION['points']['user']['alias'] . ' online.',
				'group'=>$_SESSION['points']['region']['name']  );
	
	//是否已初始化系统
	$systemCategories = points::sysurl('md5');
	$category = DBC::limited(SQL::GetSystemCategoriesCountFromPointsCategory,$systemCategories,['one'=>TRUE]);
	$arr['item'] = array();
	if($category['total'] < count($systemCategories))
	{
		$arr['iframe'] = 'initialization.php';
	}else
	{
		$serial = 0;
		foreach($_SESSION['points']['category'] as $key=>$val)
		{
			$arr['item'][$serial]['id'] = $key;
			$arr['item'][$serial]['title'] = '【' . $_SESSION['points']['subrange']['name'] . '】  ' . $val['title'];
			//$arr['item'][$serial]['path'] = $val['aurl'];
			//默认显第一个可访问的类别 以后将改为默认访问全局菜单
			if($serial == 0)
			{
				$arr['iframe'] = '/points/usr/master/regions/regions.php'; //$val['aurl'] ;
				$_SESSION['points']['item']['id'] = $key;
			} 
			$serial++;
		}
	}
	$arr['head']['title'] = $_SESSION['points']['region']['name'] . '-' . $_SESSION['points']['subrange']['name'];
	points::shell($arr);
