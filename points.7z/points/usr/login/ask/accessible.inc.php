<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $request = explode('?',$_SERVER['REQUEST_URI']);
    
    if(stripos($request[0],$_SESSION['points']['subrange']['directory']) === false)
    {
        echo '<script>window.top.document.location="/points/usr/login/"</script>'; exit;
    }
    
    if($request[0] != $_SESSION['points']['subrange']['directory'] . 'index.php')
    {
        $arr = array();
        foreach($_SESSION['points']['category'] as $k=>$v){  $arr[] = $v['aurl'];  }
        
        $referer = strtr($request[0],array(basename($request[0])=>''));
        if(!in_array($request[0],$arr) && stripos($_SERVER['HTTP_REFERER'],$referer) === false)
        {
            echo '<script>window.top.document.location="/points/usr/login/"</script>'; exit;
        }
    }
   
   
