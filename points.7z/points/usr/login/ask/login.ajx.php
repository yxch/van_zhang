<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/points/loader.inc.php';

	//请求响应
    $back = ['status'=>0,'message'=>'','url'=>'']; //响应的结果集
    
    //验证码是否正确
    if(strtolower($_POST['valide']) != $_SESSION[TAG]['VCE'])
    {
        $back['message'] = '检查验证码,输入的验证码可能有误';
        points::jan($back);
    }
    //检查区域id
    if(!ctype_digit($_POST['region']))
    {
        $back['message'] = '异常访问，区域ID不正确';
        points::jan($back);
    }
    $relations = ['1'=>'用户数据','2'=>'控制台','3'=>'定制'];
    
    //缓存region
    $_SESSION[TAG]['region'] = [];
    $_SESSION[TAG]['region']['id'] = $_POST['region'];
    $_SESSION[TAG]['region']['name'] = $relations[$_POST['region']];
    
    //检查范围id
    if(!ctype_digit($_POST['subrange']))
    {
        $back['message'] = '异常访问，子区域ID不正确';
        points::jan($back);
    }
    if($_POST['subrange'] != '0') //超级用户的初始化操作被排除在外
    {
		$regions = DBC::selected(SQL::GetRegionsFromPointsRegionsById,[':id'=>$_POST['subrange']]);
        if(count($regions) == 0)
        {
            $back['message'] = '区域不可用，可能被管理员废弃。';
            points::jan($back);
        }
        //缓存子区域信息
        $_SESSION[TAG]['subrange']['name'] = $regions[0]['name'];
        $_SESSION[TAG]['subrange']['directory'] = $regions[0]['directory'];
    }
    
    $username = trim($_POST['username']); 
    if(empty($username)){ $back['message'] = '用户名不能为空'; points::jan($back); }
    
    $password = trim($_POST['password']);
    if(empty($password)){ $back['message'] = '密码不能为空'; points::jan($back); }
    $password = md5($password);
    
    //是否存在此用户
	$users = DBC::selected(SQL::GetUsersFromPointsUserByUsername,[':username'=>$username]); 
    if(count($users) == 1) //用户存在
    {
        if($users[0]['type'] == 1){ $back['message'] = '不允许此类用户在此处登录'; points::jan($back); }
        if($users[0]['status'] == 0){ $back['message'] = '用户已被锁定，请联系系统管理员处理！'; points::jan($back); }        
        if($password != $users[0]['password'])
		{
			$_SESSION[TAG]['error'] += 1;
			$back['message'] = '登录错误[' . $_SESSION[TAG]['error'] . '],不正确的用户名或者密码,三次登录错误用户将被锁定！'; 
			if($_SESSION[TAG]['error'] >= 3)
			{
				$_SESSION[TAG]['error'] = 0;
				//锁定此用户
				if(DBC::modified(SQL::SetUserLockedInPointsUserByUsername,[':id'=>$users[0]['id'],':username'=>$username]))
				{
					$back['message'] = '您已登录错误三次，用户已被锁定！'; 
				}else{ $back['message'] = '网络或服务异常，无法完成请求，请重试！'; }
			}
			points::jan($back);
		}
		$_SESSION[TAG]['error'] = 0; //重置登录错误记数
        $_SESSION[TAG]['user']['username'] = $username;
        $_SESSION[TAG]['user']['id'] = $users[0]['id'];
        $_SESSION[TAG]['user']['alias'] = $users[0]['alias'];
        $_SESSION[TAG]['user']['type'] = $users[0]['type'];
        
        //查找所有此子区域的类别条目
		$categories = DBC::selected(SQL::GetCategoriesFromPointsCategoryByRegionId,[':regionId'=>$_POST['subrange']]); 
		$categoriesLen = count($categories); 
        if($categoriesLen == 0)
        { 
            $back['message'] = '在此区域下没有可访问的条目';
            points::jan($back);
        }
        $_arr = array(); $_categoriesId = [];
        for($k=0;$k<$categoriesLen;$k++)
        {
            $_arr[$categories[$k]['id']]['title'] = $categories[$k]['title'];
            $_arr[$categories[$k]['id']]['tid'] = $categories[$k]['templateId'];
            $_arr[$categories[$k]['id']]['MD5'] = $categories[$k]['MD5'];
			$_categoriesId[] = $categories[$k]['id']; //所有类别id的集合
        }
        //缓存类别的一些信息
        if($users[0]['type'] == 9) //超级用户
        {
            foreach($_arr as $k=>$v)
            {
                $_SESSION[TAG]['category'][$k]['title'] = $v['title'];
                $_SESSION[TAG]['category'][$k]['tid'] = $v['tid'];
                $_SESSION[TAG]['category'][$k]['MD5'] = $v['MD5'];
                $_SESSION[TAG]['category'][$k]['authority'] = MAXAUTH;
            }
        }else //不是超级用户
        {
            $uid = $users[0]['id'];
            //从用户权限列表中查出所有此uid的访问条目
			$powers = DBC::selected(SQL::GetPowerListFromPointsPowersByUID,[':uid'=>$uid]);
			$_auth = array(); $_powersCID = [];
			$powersLen = count($powers);
            for($j=0;$j<$powersLen;$j++)
            {
                $_auth[$powers[$j]['categoryId']]['authority'] = $powers[$j]['authority'];
				$_powersCID[] = $powers[$j]['categoryId'];
            }
            //求$powers['categoryId'] 与 $categories['id']交集
            $intersect = array_intersect($_powersCID,$_categoriesId);  
            if(count(array_values($intersect)) == 0)
            {
                $back['message'] = '在此区域范围内此用户没有任何可访问的类别条目';
                points::jan($back);
            }
            foreach($intersect as $k=>$v)
            {
                $_SESSION[TAG]['category'][$v]['title'] = $_arr[$v]['title'];
                $_SESSION[TAG]['category'][$v]['tid'] = $_arr[$v]['tid'];
                $_SESSION[TAG]['category'][$v]['MD5'] = $_arr[$v]['MD5'];
                $_SESSION[TAG]['category'][$v]['authority'] = $_auth[$v]['authority'];
            }      
        }
        $back['status'] = 1;
        $back['url'] = PHOST . $_SESSION[TAG]['subrange']['directory'];
        points::jan($back);
		
    }else //如果用户不存在
    {
		if($_SESSION[TAG]['error'] >= 3)
		{
			$back['message'] = '输入错误超过三次，拒绝访问！'; 
			points::jan($back);
		}
        //是否是内置初始化用户 输入初始化配置文件
        $pointers = parse_ini_file(SYSINI . 'pointer.ini',true);
        if($username != $pointers['username'])
		{ 
			$_SESSION[TAG]['error'] += 1;
			$back['message'] = '不正确的用户名或者密码'; 
			points::jan($back); 
		}
        if($password != $pointers['password'])
		{ 
			$_SESSION[TAG]['error'] += 1;
			$back['message'] = '不正确的用户名或者密码'; 
			points::jan($back); 
		}
		$_SESSION[TAG]['error'] = 0;  //重置登录错误记数
        $_SESSION[TAG]['user']['username'] = $pointers['username'];
        $_SESSION[TAG]['user']['id'] = 0;
        $_SESSION[TAG]['user']['alias'] = $pointers['alias'];
        $_SESSION[TAG]['user']['type'] = $pointers['type'];
		$_SESSION[TAG]['subrange']['name'] = '设置中心';
		$_SESSION[TAG]['subrange']['directory'] = $pointers['directory'];
        
        $back['status'] = 1;
        $back['url'] = PHOST . $pointers['directory'];
        points::jan($back);
    }