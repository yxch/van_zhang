<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $back = array('status'=>0,'tip'=>'' );
    
    $dbUser = new users(array('id'=>$_SESSION['points']['user']['id']));
    $dbUsers = $dbUser->get(array('username','alias','email'));
    
    $updates = array();
    $username = trim($_POST['username']);
    
    $isReLogin = false; //是否需要重新登录 用户名和密码修改成功后需要重新登录
    //校验用户名
    if(!empty($username))
    {
        //登录名不能有中文
        $len = mb_strlen($username,'UTF-8');
        if($len > 13)
        {
            $back['tip'] = '登录名太长';
            points::jan($back);
        }
        for($i=0;$i<$len;$i++)
        {
            if(STR::isChinese($username[$i]))
            {
                $back['tip'] = '登录名不能包含中文';
                points::jan($back);
            }
        }
        
        //是否存在相同的登录名但id不是此id
        $user = new users('username= "' . $username . '" AND id != ' . $_SESSION['points']['user']['id']); 
        if($user->iTotal() > 0)
        {
            $back['tip'] = '此登录名[用户名]已被占用';
            points::jan($back);
        }
        $isReLogin = true;
        if($username != $dbUsers['username'][0]){ $updates['username'] = $username; }              
    }else
    {
        $back['tip'] = '登录名不能为空';
        points::jan($back);
    }
    
    //校验用户显示名
    $alias = trim($_POST['alias']);
    if($alias == $dbUsers['alias'][0]){ $alias = ''; }
    if(!empty($alias))
    {
        
        if(mb_strlen($alias,'UTF-8') > 13)
        {
            $back['tip'] = '显示名太长';
            points::jan($back);
        }
        $updates['alias'] = $alias;
    }
    
    //校验密码
    if(!empty($_POST['passwordLogin']))
    {
        if(empty($_POST['passwordEnsure']))
        {
            $back['tip'] = '必须填写确认密码';
            points::jan($back);
        }
        $pwd = STR::password($_POST['passwordLogin']);
        if($pwd['status'] == 0)
        {
            $back['tip'] = $pwd['err'];
            points::jan($back);
        }
        if($_POST['passwordLogin'] != $_POST['passwordEnsure'])
        {
            $back['tip'] = '两次输入的密码不一致';
            points::jan($back);
        }
        $isReLogin = true;
        $updates['password'] = $pwd['encrypt'];       
    }
    
    //检验电子邮箱地址
    $email = trim($_POST['email']);
    if($email == $dbUsers['email'][0]){ $email = ''; }     
    if(!empty($email))
    {
        if(!STR::email($email))
        {
            $back['tip'] = '电子邮箱地址的格式不正确';
            points::jan($back);
        }
        $updates['email'] = $email;
    }
    if(empty($updates))
    {
        $back['tip'] = '没有可用于提交的内容';
        points::jan($back);
    }
    
    $user = new users(array('id'=>$_SESSION['points']['user']['id']));
    if($user->set($updates))
    {
        $back['status'] = ($isReLogin) ? 1 : 2;
        if(!empty($alias)){ $_SESSION['points']['user']['alias'] = $alias; }
    }
    points::jan($back);
