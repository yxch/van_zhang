<?php
	require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //如果客户端的COOKIE开启，则清除COOKIE中的SESSION ID
    if(isset($_COOKIE[session_name()]))
    {
        //setcookie(session_name(),'',time()-3600,'/');
        setcookie(session_name(),session_id(),time()-3600,'/');
    }       
    //SSN::destroy();    //销毁session
	session_destroy();
    //用户注销后 销毁session_id 页面将跳转
    header("Location:/points/usr/login/index.php"); 
	exit;