
//自定义函数
String.prototype.empty = function(){ return this == '' || this == ' ' || typeof(this) == 'undefined'; };

$(document).ready(function(){
    
    var user = usersInfo();
    
    function usersInfo()
    {
         return {"username" : $.trim($('#username').val()),
                 "alias" : $.trim($('#alias').val()),
                 "passwordLogin" : $('#loginpassword').val(),
                 "passwordEnsure" : $('#ensurepassword').val(),
                 "email" : $.trim($('#email').val())  };
    }
    
    $('#ensure').click(function(){
        var users = usersInfo();
        $allowed = false;
        for(var p in users){ if(users[p] != user[p]){ $allowed = true; break; } }
        if ($allowed)
        {
            if (!users['passwordLogin'].empty())
            {
                if (users['passwordEnsure'].empty())
                {
					global.tip('必须提供确认密码');
                    return false;
                }
            }
            if (users['passwordLogin'] != users['passwordEnsure'])
            {
				global.tip('两次提供的密码不一致');
                return false;
            }
            
        }else
        {
			global.tip('没有可用于提交的内容，请检查输入!');
            return false;
        }
        
        //输入校验        
        $.post('ask/settings.ajx.php',users,function(r){
            var j = $.parseJSON(r);
            if (j.status == '1')
            {
                window.top.document.location = "/points/usr/login/";
            }else if( j.status == '2')
            {
				global.tip('更改设置成功','success');
				setTimeout(function(){
					window.top.document.location = window.top.document.location;
				},3000);
				
            }else{ global.tip(j.tip); }        
        });
        
    });
});