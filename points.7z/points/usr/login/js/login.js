$(document).ready(function(){
    
    $('#item a').click(function(){        
        $(this).addClass('used');
        $(this).siblings().removeClass('used');
        
        //使对应项出现或隐藏
        var items = ['data','master','custom'];
        var id = $(this).attr('id');
        $('#a-' + id).show();
        $('#a-' + id).children('select').addClass('subrange');
        for(var i=0;i<items.length;i++)
        {
            if(items[i] != id)
            {
                $('#a-' + items[i]).hide();
                $('#a-' + items[i]).children('select').removeClass('subrange');
            }
        }
    });
    
    //单击验证码，重新生成
    $('#img-vce').click(function(){
        var src = $(this).attr('src').split('?')[0];
        $(this).attr('src',src + '?ver=' + Math.random());    
    });
    
    //直接在输入框回车提交
    $('#username,#password,#valide').keydown(function(e){
        var ev = document.all ? window.event : e;
        if (ev.keyCode == 13){ checked(); }
    });
    
    //单击登录提交
    $('#logined').click(function(){ checked();  });
    function checked()
    {
        $('#tip').text('');
        var posts = {};
        posts.region = $('.used').attr('_region');
        posts.subrange = $('.subrange').val();
        posts.username = $.trim($('#username').val());
        if(posts.username.length == 0){ $('#tip').text('用户名不能为空'); return; }
        posts.password = $.trim($('#password').val());
        if(posts.password.length == 0){ $('#tip').text('密码不能为空'); return; }
        posts.valide = $.trim($('#valide').val());
        if(posts.valide.length == 0){ $('#tip').text('请输入验证码'); return; }
        $('#tip').text('');
        $.post('ask/login.ajx.php',posts,function(r){                         //console.log(r);
            var j = $.parseJSON(r);
            if (j.status == '1')
            {
                $('#username').val('');
                $('#password').val('');
                $('#valide').val('');
                window.location.href = j.url;                
            }else{  $('#tip').text(j.message);}
        });
    }
});