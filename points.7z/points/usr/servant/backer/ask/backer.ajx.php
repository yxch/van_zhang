<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
 
    $back = ['yes'=>0,'tip'=>'','type'=>'error'];
    
    if(!isset($_POST['serial']) || !ctype_digit($_POST['serial']))
    {
        $back['tip'] = '提供了无效的值';
        points::jan($back);
    }
    
    //当前用户是否有修改的权限
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];
    if(!points::allowed($auth,'edit')){ $back['tip'] = '用户权限请求'; points::jan($back); }
    
	//由id查询变量的校验规则
	$rule = DBC::selected(SQL::GetVarRuleFromPointsVariablesById,[':id'=>$_POST['serial']],['one'=>TRUE]);
    if(empty($rule['rule'])){ $back['tip'] = 'Exception newwork access.'; points::jan($back); }
    
    if(!STR::checkText($_POST['val'],$rule['rule'][0]))
    {
        $back['tip'] = '值的规则校验失败,请提供正确的值';
        points::jan($back);
    }
	//更新变量
	if(DBC::modified(SQL::SetVarInPointsVarablesById,[':val'=>trim($_POST['val']),':id'=>$_POST['serial']]))
	{
		$back['type'] = 'success';
		$back['tip'] = '更新成功';
	}else{ $back['tip'] = '更新失败'; }
	
    points::jan($back);
    