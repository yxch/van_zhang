<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $title = $_SESSION['points']['subrange']['name'] . ' ' . $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['title'];
    
    //找到当前类别的md5  查询此md5下所有用户可配置的变量及其相关信息
    $MD5 = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['MD5'];
    $vars = DBC::selected(SQL::GetVarsFromPointsVariableByMd5,[':pos'=>$MD5]);
	$varsLen = count($vars);  //是否存在用户可配置变量    
?>
<!DOCTYPE html>
<html>
<head>
	<?php echo points::head(0); ?>
	<link rel="stylesheet" href="css/backer.css" />
	<script src="/points/cross/local/js/points.js"></script>
	<script src="js/backer.js"></script>
</head>
<body>
	<h1><?php echo $title; ?></h1>
	<div id="settings">
		<?php if($varsLen > 0){ ?>
		<?php for($i=0;$i<$varsLen;$i++){ ?>
		<div>
			<label><?php echo $vars[$i]['note']; ?>：</label>
			<input class="settings" id="PUT-<?php echo $vars[$i]['id']; ?>" value="<?php echo $vars[$i]['value']; ?>" />
			<a class="set" id="S-<?php echo $vars[$i]['id']; ?>">更改设置</a>
			<p class="warning" title="<?php echo $vars[$i]['text']; ?>">
				<?php if(!empty($vars[$i]['text'])){ ?><i><img src="/points/cross/local/image/warning.png" /></i><?php } ?>
				<?php echo $vars[$i]['text']; ?>
			</p>
		</div>
		<?php } }else{ ?>
		<div id="none">没有设置选项</div>
		<?php } ?>
	</div>
</body>
</html>
