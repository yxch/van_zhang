<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';

    //是否正常登录或者用户切换到其它目录
    if(!isset($_SESSION[TAG]['user']['id']) || $_SESSION[TAG]['subrange']['directory'] != points::SERVANT)
    {  
		echo '<script>window.top.document.location="' . ACCESSIBLED . '"</script>'; 
		exit;
	}

	$arr = array('head'=>array('title'=>$_SESSION[TAG]['region']['name']),
				'username'=>$_SESSION[TAG]['user']['username'],
				'status'=>'[' . $_SESSION[TAG]['user']['id'] . '] ' . $_SESSION[TAG]['user']['alias'] . ' online.',
				'group'=>$_SESSION[TAG]['region']['name']  );
	
	//确认必要组件 category
	$vsys = points::vsys(); 
	$category = DBC::selected(SQL::GetExistFromPointsCatgoryByMd5,[':md5'=>md5($vsys['category']['murl'])],['one'=>TRUE]);
	
	$arr['item'] = [];
	if($category['total'] == 0)
	{
		$arr['iframe'] = '/points/cross/initialization.php';
	}else
	{
		$tid = [];
		foreach($_SESSION[TAG]['category'] AS $key=>$_ar){ $tid[] = $_ar['tid']; }
		$templates = DBC::limited(SQL::GetTemplatesFromPointsTemplateByIds,$tid);
		$_templates = [];
		for($i=0,$len=count($templates);$i<$len;$i++)
		{
			$_templates[$templates[$i]['id']] = $templates[$i]['path'];
		}
	
		$serial = 0;
		foreach($_SESSION['points']['category'] as $key=>$val)
		{
			$arr['item'][$serial]['id'] = $key;
			$arr['item'][$serial]['title'] = '【' . $_SESSION['points']['subrange']['name'] . '】  ' . $val['title'];
			$arr['item'][$serial]['path'] = $_templates[$val['tid']];
			//默认显第一个可访问的类别 以后将改为默认访问全局菜单
			if($serial == 0)
			{
				$arr['iframe'] = $_templates[$val['tid']];
				$_SESSION[TAG]['item']['id'] = $key;
			} 
			$serial++;
		}
	}
	$arr['head']['title'] = $_SESSION[TAG]['region']['name'] . '-' . $_SESSION[TAG]['subrange']['name'];
	points::shell($arr);
