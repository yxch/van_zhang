
$(document).ready(function(){
    var page = 1;
    var total = $('#pages').val();
    
    //初始化弹窗的大小和遮罩层的大小
    f.pop();
    $(window).resize(function(){  f.pop();  f.overlay(); });
    
    //导出按钮单击事件
    $('#export').click(function(){        
        f.overlay().fadeIn();
        $('#pop').show();
    });
    
    //export 的单击事件
    $(".export").click(function(){
        var exports = document.getElementsByName('export');
        for(var i=0;i<exports.length;i++)
        {
            if (exports[i].checked)
            {
                if (exports[i].value == '0')
                {
                    $('#stime').attr('disabled',false);
                    $('#etime').attr('disabled',false);
                }else
                {
                    $('#stime').attr('disabled','disabled');
                    $('#stime').val('');
                    $('#etime').attr('disabled','disabled');
                    $('#etime').val('');                      
                }
                if (exports[i].value == '1')
                {
                    $('#rows').attr('disabled',false);
                }else
                {
                    $('#rows').attr('disabled','disabled');
                    $('#rows').val('');
                }
            }
        }
        $('#tip').text('');
    });
    
    $('#stime,#etime').focus(function(){ if($(this).val().empty()){$(this).val(f.dateTime('date') + ' 23:59:59');} });
    
    //分页事件 首页 下一页 每一页 上一页 末页
    $('#grid tfoot').delegate('.first','click',function(){
        if (page != 1){ page = 1; rows('ask/searcher.ajx.php',{"page":page}); }
    });
    
    $('#grid tfoot').delegate('.next','click',function(){
        
        var i = page + 1;
        if (i <= parseInt(total)){ page = i; rows('ask/searcher.ajx.php',{"page":page});}
    });
    
    $('#grid tfoot').delegate('.page','click',function(){
        var id = $(this).attr('id').split('-')[1]; 
        rows('ask/searcher.ajx.php',{"page":id});
    });
    
    $('#grid tfoot').delegate('.last','click',function(){

        var i = page - 1; 
        if (i >= 1){ page = i;  rows('ask/searcher.ajx.php',{"page":page});}
    });
    
    $('#grid tfoot').delegate('.end','click',function(){
        if (page < parseInt(total)) { page = parseInt(total); rows('ask/searcher.ajx.php',{"page":page}); }
    });
    
    //用户数据搜索页面
    function rows(url,posts)
    {
        $.post(url,posts,function(r){/* console.log(r);*/
            var j = $.parseJSON(r);
            var yes = parseInt(j.yes);
            if (yes == 1)
            {
                page = j.page; //当前面
                $('#loading').hide();
                $('#grid tbody').html('');
                $('#grid tbody').html(j.tbody);
                $('#fpage').html('');
                $('#fpage').html(j.fpage);
            }
        });
    }
    
    //弹窗的确定按钮
    $('#ensure').click(function(){
        $('#tip').text('');
        var exports = document.getElementsByName('export'); 
        var v = 0;
        for(var i=0;i<exports.length;i++){ if(exports[i].checked){ v = exports[i].value; }}
        var param = '';
        if (v == 0)
        {
            var stime = $.trim($('#stime').val());
            if (stime.empty()) { $('#tip').text('开始时间不能为空');return false; }
            var etime = $.trim($('#etime').val());
            if (etime.empty()) { $('#tip').text('结束时间不能为空');return false; }
            param = '?t=0' + '&stime=' + stime + '&etime=' + etime;
        }
        if (v == 1)
        {
            var rows = $.trim($('#rows').val());
            if (rows.empty()) { $('#tip').text('必须指定一个大于0的数字');return false; }
            var iRows = parseInt(rows);
            if (iRows <= 0) { $('#tip').text('必须指定一个大于0的数字');return false; }
            param = '?t=1' + '&n=' + rows;
        }
        if (v == 2){  param = '?t=2'; }
        if (v == 3){  param = '?t=3' + '&p=' + page; }
        
        window.location.href = 'http://' + window.location.host + '/points/usr/servant/search/ask/exported.ajx.php' + param;
    });

});