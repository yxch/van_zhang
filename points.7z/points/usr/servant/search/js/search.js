function check(obj)
{
    if(obj.searcher.value.empty())
    {
        $('#err').text('必须提供查询条件的值');
        return false;
    }
    var select = [];
    $('.lb-select input').each(function(i,obj){
        var checkbox = $(obj);
        if (checkbox.is(":checked")) { select.push(checkbox.val()); }
    });
    if (select.length == 0) { $('#err').text('至少选择一个显示字段'); return false; }
    return select.length > 0;
}
$(document).ready(function(){
    
    document.getElementById('filters').onchange = function()
    {
        $('#err').text('');
        var v = this.value;
        $.post('ask/search.ajx.php',{"cid":v},function(r){
            var j = $.parseJSON(r);
            if (j.yes == '1')
            {
                $('#searches').html('');
                $('#searches').html(j.opt);
                $('#select').html('');
                $('#select').html(j.field);
            }else{ $('#err').text('此类别设置的搜索选项可能不可用或者没有设置有效值，请转到后台处理。'); }
        });
    }
});
