<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $back = array('yes'=>0,'page'=>1,'tbody'=>'','fpage'=>'');
    
    if(!isset($_POST['page']) && !ctype_digit($_POST['page'])){ points::jan($back); }
    $back['page'] = $_POST['page'];
    
    $limit = ' LIMIT ' . $_SESSION['points']['searcher']['psize'] . ' OFFSET ' . ($_POST['page'] - 1) * $_SESSION['points']['searcher']['psize'];    
    
    $result = DBC::execute($_SESSION['points']['searcher']['SQL'] . $limit);
    $length = count($result);
    
    $translators = $_SESSION['points']['searcher']['translators'];
    for($i=0;$i<$length;$i++)
    {
        $back['tbody'] .= '<tr>';
        foreach($result[$i] as $fieldName=>$v)
        { 
            $v = points::translator($fieldName,$v,$translators);
            $back['tbody'] .= '<td class="hidden" title="' . $v . '">' . $v . '</td>';
        }
        $back['tbody'] .= '</tr>';        
    }
    $back['fpage'] = points::fpage($_SESSION['points']['searcher']['pages'],$_POST['page'],$_SESSION['points']['searcher']['psize']);
    $back['yes'] = 1;
    points::jan($back);   
