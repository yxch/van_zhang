<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    $back = array('yes'=>0,'opt'=>'','field'=>'');
    if(!isset($_POST['cid']) || !ctype_digit($_POST['cid']))
    {
        $back['tip'] = '提供了不合法的类别ID.';
        points::jan($back);
    }
    
    $field = $_SESSION['points']['filters'][$_POST['cid']]['fields'];
    $search = $_SESSION['points']['filters'][$_POST['cid']]['searcher'];
    
    $fields = points::parseField($field); 
    $fieldNames = $fields['field']; $len = count($fields);
    
    //查询选项
    $counts = 0; $err = 0;
    if(!empty($search))
    {
        $searches = explode(',',$search);
        $counts = count($searches);
        for($k=0;$k<$counts;$k++){if(!isset($fields['field'][$searches[$k]])){ $err += 1; }}
    }
    if($len == 0 || $counts == 0 || $err > 0){ points::jan($back); }
    if($counts > 0)
    {
        for($j=0;$j<$counts;$j++)
        {
            if(isset($fieldNames[$searches[$j]])){  $back['opt'] .= '<option value="' . $searches[$j] . '">' . $fieldNames[$searches[$j]]. '</option>'; }
        }
    }
    
    //显示字段
    $arr = array_chunk($fieldNames,4,true);
    for($i=0,$l=count($arr);$i<$l;$i++)
    {
        $back['field'] .= '<p>';
        foreach ($arr[$i] as $key=>$name)
        {
            $back['field'] .= '<label class="lb-select"><input type="checkbox" name="fields[]" value="' . $key . '" checked="checked">' . $name .'</label>';
        }
        $back['field'] .= '</p>';
    };
    $back['yes'] = 1;
    points::jan($back);
