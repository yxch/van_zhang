<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $title = $_SESSION['points']['subrange']['name'] . ' ' . $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['title'];

	//查询此管理标识符下的所有可用数据过滤器
	$filters = DBC::selected(SQL::GetFilterFromPointsFiltersByCid,[':cid'=>$_SESSION['points']['item']['id']]);
	$filtersLen = count($filters);
?>
<!DOCTYPE html>
<html>
<head>
	<?php echo points::head(0); ?>
	<link rel="stylesheet" href="css/banker.css" />
	<script src="/points/cross/local/js/points.js"></script>
</head>
<body>
	<h1>
		<label><?php echo $title; ?></label>
		<span>
			<select id="filter">
				<?php for($j=0;$j<$filtersLen;$j++){ ?>
				<option value="<?php echo $filters[$j]['id']; ?>"><?php echo $filters[$j]['name']; ?></option>
				<?php } ?>
			</select>
		</span>
		<span><a id="opt">过滤选项<img alt="" src="/points/cross/local/image/gear.png" /></a></span>
	</h1>
	<h2>这里显示过滤条件</h2>
	<?php if($filtersLen > 0){ ?>
	<table id="grid">
		<thead><tr></tr></thead>
		<tbody><tr id="none"><td>正在加载数据......</td></tr></tbody>
		<tfoot>
			<tr>
				<td colspan="">
					<a id="export">导出</a>
					<label id="range"><input type="checkbox" id="ranges" checked="checked" />导出当前页</label>
					<span id="paging"> </span>
					<span id="totalize">总数：　<label></label></span>
				</td>
			</tr>
		</tfoot>
	</table>
	<?php }else{ ?>
	<div id="empty">
		<i>没有为此类别设置任何数据过滤器</i>
	</div>
	<?php } ?>

	<script src="/points/cross/local/js/paging.js"></script>
	<script src="js/banker.js"></script>
</body>
</html>
    