<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
	
    //确认用户是否有权限访问
	if(!isset($_SESSION[TAG]) || empty($_SESSION[TAG])){ echo '<script>window.top.document.location="' . ACCESSIBLED . '"</script>'; exit; }
	$servant = points::servant();
	$MD5 = md5($servant['banker']['murl']);
	$allowed = false;
	foreach($_SESSION[TAG]['category'] AS $k=>$ar){ if($ar['MD5'] == $MD5){ $allowed = true; break;}  }
	if(!$allowed){ echo '<script>window.top.document.location="' . ACCESSIBLED . '"</script>'; exit; }
    
    $title = $_SESSION['points']['subrange']['name'] . ' ' . $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['title'];

	//查询此管理标识符下的所有可用数据过滤器
	$filters = DBC::selected(SQL::GetFilterFromPointsFiltersByCid,[':cid'=>$_SESSION['points']['item']['id']]);
	$filtersLen = count($filters);
?>
<!DOCTYPE html>
<html>
<head>
	<?php echo points::head(0); ?>
	<link rel="stylesheet" href="css/banker.css" />
	<script src="/points/cross/local/js/points.js"></script>
</head>
<body>
	<h1>
		<label><?php echo $title; ?></label>
		<span>
			<select id="filter">
				<?php for($j=0;$j<$filtersLen;$j++){ ?>
				<option value="<?php echo $filters[$j]['id']; ?>"><?php echo $filters[$j]['name']; ?></option>
				<?php } ?>
			</select>
		</span>
		<span><a id="opt">过滤选项<img alt="" src="/points/cross/local/image/gear.png" /></a></span>
	</h1>
	<h2 id="h2"></h2>
	<?php if($filtersLen > 0){ ?>
	<table id="grid">
		<thead><tr></tr></thead>
		<tbody><tr id="none"><td>正在加载数据......</td></tr></tbody>
		<tfoot>
			<tr>
				<td colspan="">
					<a id="export">导出</a>
					<label id="exported"><input type="checkbox" id="exports" checked="checked" />导出当前页</label>
					<span id="paging"> </span>
					<span id="totalize">总数：　<label></label></span>
				</td>
			</tr>
		</tfoot>
	</table>
	<?php }else{ ?>
	<div id="empty">
		<i>没有为此类别设置任何数据过滤器</i>
	</div>
	<?php } ?>

	<div id="pop" style="display:none;">
		<ul id="where">
			<li id="range">
				<i>时间范围：</i>
				<span><label>从</label><input id="stime" /><label>到</label><input id="etime" /></span>
			</li>
			<li id="newests"><i>最新：</i><span><input id="newest" />条</span></li>
			<li id="section">
				<i>ID区间：</i>
				<span><label>从</label><input id="start" /><label>到</label><input id="ended" /></span>
			</li>
			<li id="condition">
				<i>其它条件：</i>
				<span>
					<select id="fsearch"></select>
					<label>值：</label><input id="search" />
				</span>
				<span id="oper">
					<label><input type="radio" name="oper" value="=" checked="checked" >等于[精确]</label>
					<label><input type="radio" name="oper" value="<">小于</label>
					<label><input type="radio" name="oper" value=">">大于</label>
					<label><input type="radio" name="oper" value="<=">小于等于</label>
					<label><input type="radio" name="oper" value=">=">大于等于</label>
					<label><input type="radio" name="oper" value="!=">不等于</label>
					<label><input type="radio" name="oper" value="LIKE">等于[模糊]</label>
				</span>
			</li>
		</ul>
		<p id="title">选择显示字段</p>
		<ul id="fields">	</ul>
		<p class="ensure"><a id="ensure">确定</a></p>
	</div>

	<script src="/points/cross/local/js/paging.js"></script>
	<script src="js/banker.js"></script>
	<script src="/points/cross/plugin/layer_2_2/layer.js"></script>
</body>
</html>
    