<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
   
    if(!isset($_POST['filter']) || !ctype_digit($_POST['filter'])){ exit('Exception Access!'); }
    if(!isset($_POST['page']) || !ctype_digit($_POST['page'])){ exit('Exception Access!'); }
    
    $filter = new filter(array('id'=>$_POST['filter'],'status'=>1));
    $filters = $filter->get(array('name','fieldText','searcher','select','factor','rest'));
    if($filter->iTotal() == 0){ exit('The filter invalid or be out of date'); }
    
    //用户请求响应
    $back = array('yes'=>0,
                  'tip'=>'',
                  'thead'=>'',
                  'tbody'=>'',
                  'tfoot'=>'',
                  'page'=>$_POST['page'],
                  'total'=>0,
                  'size'=>15      );
    
    
    //临时使用  调整登录后删除 -----开始
    //$titles 是用户数据过滤器提供的表字段 要根据当前cid从过滤器表中获得 
    $fields = parseField($filters['fieldText'][0]);
    if(!isset($fields['field']) || !isset($fields['translator'])){ points::jan($back); }
    $fieldArr = array_keys($fields['field']);
    $titleArr = array_values($fields['field']);
    $translators = $fields['translator'];
    $recorder = array_search('recorder',$translators);
    if($recorder === false){ points::jan($back); }
   
    function parseField($fields)
    {
        $arr = json_decode($fields,true);
        $field = array();
        for($i=0,$len=count($arr);$i<$len;$i++)
        {
            $field['field'][$arr[$i]['fname']] = $arr[$i]['dname'];
            if(isset($arr[$i]['translator']))
            {
                $field['translator'][$arr[$i]['fname']] = $arr[$i]['translator'];
            }
        }
        return $field;
    }
    
    /**
     *处理翻译设定的函数 用于数据过滤器
     */
    function translator($key,$v,array $translator)
    {
        if(!isset($translator[$key])){ return $v; } //如果没有设定此字段的翻译条件，立即返回字段的原始值
        $tran = $translator[$key];
        if(stripos($tran,'fun') !== false)
        {
            $trans = explode(':',$tran);
            eval("\$v = " . $trans[1] . ";");
            return $v; //返回翻译后的值
        }
        if(stripos($tran,'recorder') !== false){ return $v; }
        if(stripos($tran,'modifier') !== false){ return $v; }
        
        if(strpos($tran,',') !== false) // 1:男,2:女,3:保密
        {
            $arr = explode(',',$tran);
            for($i=0,$l=count($arr);$i<$l;$i++)
            {
                $_arr = explode(':',$arr[$i]);
                if($_arr[0] == $v){ return $_arr[1]; }
            }
        }
        return $v;
    }
    //临时使用  调整登录后删除 -----结束
    
    /*
    $fields = points::parseField($filters['fieldText'][0]);
    $fieldArr = array_keys($fields['field']);
    $titleArr = array_values($fields['field']);
    $translators = $fields['translator'];
    
    $recorder = '';
    if($fields['flag'] && array_search('recorder',$fields['flag']) !== false)
    {
        $recorder = array_search('recorder',$fields['flag']);
    } */
    
    //缓存这些值 导出数据时需要用到
    $_SESSION['points']['banker']['name'] = $filters['name'][0];
    $_SESSION['points']['banker']['fields'] = $fieldArr;
    $_SESSION['points']['banker']['titles'] = $titleArr;
    $_SESSION['points']['banker']['translators'] = $translators;
    $_SESSION['points']['banker']['recorder'] = $recorder;
    $_SESSION['points']['banker']['select'] = $filters['select'][0];
    $_SESSION['points']['banker']['factor'] = $filters['factor'][0];
    $_SESSION['points']['banker']['rest'] = $filters['rest'][0];
    
    //表格的标题内容
    $back['thead'] = '<tr>';
    $titleLen = count($titleArr);
    for($i=0;$i<$titleLen;$i++){ $back['thead'] .= '<td class="hidden" title="' . $titleArr[$i] .'">' . $titleArr[$i] . '</td>'; }
    $back['thead'] .= '</tr>';
    
    //获取数据 select部分可以不提供选择字段，由本程序处理。如果提供了select字段部分必须对应显示字段
    $SQL = stripos($filters['select'][0],'select') === false
           ? 'SELECT ' . implode(',',$fieldArr) . ' ' . $filters['select'][0] . ' ' . $filters['factor'][0] . ' ' . $filters['rest'][0]
           : $filters['select'][0] . ' ' . $filters['factor'][0] . ' ' . $filters['rest'][0];
    
    //获取设定条件的记录总数
    //if($fields['tb'] == 'none')
    //{
        $selects = explode(' ',$filters['select'][0]);
        $fromPosition = -1; //from关键字的位置 得到表名
        for($i=0,$l=count($selects);$i<$l;$i++){  if(strtolower($selects[$i]) == 'from'){ $fromPosition = $i; break;}  }
        $tableName = $selects[$fromPosition + 1];
        if(empty($tableName)){ points::jan($back); }
        
    //}else{ $tableName = $fields['tb']; }
    
    $_count = DBC::execute('SELECT count(*) AS total FROM ' . $tableName); //总记录数
    
    $back['total'] = $_count[0]['total'];
    $back['page'] = $_POST['page'];
    $limit = ' LIMIT ' . $back['size'] . ' OFFSET ' . ($_POST['page'] - 1) * $back['size'];  
 
    //分页显示
    $r = DBC::execute($SQL . $limit);
    $len = count($r);
    if($len > 0)
    {
        if($_count[0]['total'] > 0){ $count = $_count[0]['total']; }
        //表格的tfoot部分
        $oper = points::authorized($_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'],array('edit','delete','add','import'));
        if(empty($oper)){ $oper = '&nbsp;'; }
        for($i=0;$i<$len;$i++)
        {
            $back['tbody'] .= '<tr>';
            foreach($r[$i] as $k=>$v)
            {
                //$v = points::translator($k,$v,$translators);
                $v = translator($k,$v,$translators);
                $back['tbody'] .= '<td class="hidden" title="' . $v . '">' . $v . '</td>';
            }
            $back['tbody'] .= '</tr>';
        }
    }else{ $back['tbody'] = '<tr id="none"><td colspan="' . $titleLen . '">没有可用数据</td></tr>'; }
    $back['tfoot'] = '<tr><td colspan="' . $titleLen . '"><span id="oper">' . $oper . '</span><span id="fpage"></span><span id="counts">总记录数:' .  $count . '</span></td></tr>';
    $back['yes'] = 1;
    points::jan($back);