<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
	//页面请求响应
	$back = ['status'=>0,'tip'=>'','type'=>'error','page'=>1,'size'=>15,'condition'=>'','thead'=>'','tbody'=>'','total'=>0,'titles'=>0];
	
	if(!isset($_POST['filter']) || !ctype_digit($_POST['filter'])) //检查提供的过滤器
	{
		$back['tip'] = '没有提供可用的数据过滤器标识符！';
		points::jan($back);
	}
	//检查提供的页数
	$page = isset($_POST['page']) ? $_POST['page'] : '1';
	$back['page'] = $page;
	if(!ctype_digit($page))
	{
		$back['tip'] = '提供了一个无法识别的当前页标识符';
		points::jan($back);
	}
	//由过滤器id查询过滤器信息
	$filter = DBC::selected(SQL::GetFilterFromPointsFiltersById,[':id'=>$_POST['filter']],['one'=>TRUE]); 
	if(count($filter) == 0)
	{
		$back['tip'] = '异常的请求';
		points::jan($back);
	}
	$field = json_decode($filter['fields'],true);
	$fieldAlias = array_combine($field['fields'],$field['alias']); //字段与显示名的映射
	$statement = json_decode($filter['statement'],true); //计算总数及查询语句 totalize  statement condition
	
	//用户选择的显示字段
	$_title = isset($_POST['fields']) && !empty($_POST['fields']) ? explode('|',$_POST['fields']) : $field['fields']; 
	//确认字段是否是有效和表格标题
	$titles = []; $alias = [];
	for($k=0,$l=count($_title);$k<$l;$k++)
	{
		if(!in_array($_title[$k],$field['fields']))
		{
			$back['tip'] = '异常的请求';
			points::jan($back);
		}
		$titles[] = $_title[$k];
		$alias[] = $fieldAlias[$_title[$k]];
		$back['thead'] .= '<td title="' . $fieldAlias[$_title[$k]] . '">' . $fieldAlias[$_title[$k]] . '</td>';
	}
	$back['titles'] = count($titles);

	//选项内容 请求选项响应
	if(isset($_POST['opt']) && $_POST['opt'] == '1')
	{ 
		//是否显示序列选择选项
		$opt = ['section'=>0,'range'=>0,'fsearch'=>'','fsearchAlias'=>'','fields'=>'','alias'=>''];
		$opt['section'] = empty($field['increment']) ? 0 : 1;
		$opt['range'] = empty($field['dated']) ? 0 : 1;
		if(!empty($field['fsearch']))
		{ 
			$fsearchAlias = [];
			for($j=0,$fsearchLen=count($field['fsearch']);$j<$fsearchLen;$j++)
			{
				$fsearchAlias[] = $fieldAlias[$field['fsearch'][$j]];
			}
			$opt['fsearch'] = implode('|',$field['fsearch']);
			$opt['fsearchAlias'] = implode('|',$fsearchAlias);
		}else{ $field['fsearch'] = ''; }
		$opt['fields'] = json_encode(array_chunk($field['fields'],5));
		$opt['alias'] = json_encode(array_chunk($field['alias'],5)); 
		points::jan($opt);exit;
	}
	
	//为导出存储字段和显示名
	$_SESSION[TAG]['export']['fields'] = $titles;
	$_SESSION[TAG]['export']['alias'] = $alias;
	$_SESSION[TAG]['export']['page'] = $page;
	$_SESSION[TAG]['export']['size'] = $back['size'];
	if(!empty($field['dated']))
	{
		$_SESSION[TAG]['export']['order'] = $field['dated'][0];
	}else
	{
		$_SESSION[TAG]['export']['order'] = !empty($field['increment']) ? $field['increment'][0] : '';
	}

	//组合条件或默认条件
	$where = $statement['condition'];
	if(!empty($_POST['stime']) || !empty($_POST['etime']))
	{
		//检查时间值是否有效
		if(!empty($_POST['stime']) && !STR::timed($_POST['stime']))
		{
			$back['tip'] = '提供了一个无效的开始时间';
			points::jan($back);
		}
		if(!empty($_POST['etime']) && !STR::timed($_POST['etime']))
		{
			$back['tip'] = '提供了一个无效的结束时间';
			points::jan($back);
		}
		if(empty($field['dated']))
		{
			$back['tip'] = '异常请求,没有记录时间标识符';
			points::jan($back);
		}
		$ctime = $field['dated'][0];  //取第一个值
		if(!empty($_POST['stime']) && !empty($_POST['etime']))
		{
			$where .= empty($where) ? ' WHERE ' . $ctime . ' >= "' . $_POST['stime'] . '" AND ' . $ctime . ' <= "' . $_POST['etime'] . '"'
									: ' AND ' . $ctime . ' >= "' . $_POST['stime'] . '" AND ' . $ctime . ' <= "' . $_POST['etime'] . '"';
		}
		if(!empty($_POST['stime']) && empty($_POST['etime']))
		{
			$where .= empty($where) ? ' WHERE ' . $ctime . ' >= "' . $_POST['stime'] . '"'
									: ' AND ' . $ctime . ' >= "' . $_POST['stime'] . '"';
		}
		if(empty($_POST['stime']) && !empty($_POST['etime']))
		{
			$where .= empty($where) ? ' WHERE ' . $ctime . ' <= "' . $_POST['etime'] . '"'
									: ' AND ' . $ctime . ' <= "' . $_POST['etime'] . '"';
		}
		//两者皆为空时不处理
	}
	if(!empty($_POST['start']) || !empty($_POST['end']))
	{
		if(!empty($_POST['start']) && !ctype_digit($_POST['start']))
		{
			$back['tip'] = '提供了一个无效的开始区间值';
			points::jan($back);
		}
		if(!empty($_POST['end']) && !ctype_digit($_POST['end']))
		{
			$back['tip'] = '提供了一个无效的结束区间值';
			points::jan($back);
		}
		if(empty($field['increment']))
		{
			$back['tip'] = '异常请求,没有自增序列标识符';
			points::jan($back);
		}
		$increment = $field['increment'][0];
		if(!empty($_POST['start']) && !empty($_POST['end']))
		{
			$where .= empty($where) ? ' WHERE ' . $increment . ' >= ' . $_POST['start'] . ' AND ' . $increment . ' <= ' . $_POST['end']
									: ' AND ' . $increment . ' >= ' . $_POST['start'] . ' AND ' . $increment . ' <= ' . $_POST['end'];
		}
		if(!empty($_POST['start']) && empty($_POST['end']))
		{
			$where .= empty($where) ? ' WHERE ' . $increment . ' >= ' . $_POST['start']
									: ' AND ' . $increment . ' >= ' . $_POST['start'];
		}
		if(empty($_POST['start']) && !empty($_POST['end']))
		{
			$where .= empty($where) ? ' WHERE ' . $increment . ' <= ' . $_POST['end']
									: ' AND ' . $increment . ' <= ' . $_POST['end'];
		}
		//两者皆为空时不处理
	}
	if(!empty($_POST['fsearch']) && !empty($_POST['oper']) && !empty($_POST['search']))
	{
		if(!in_array($_POST['fsearch'],$field['fields']))
		{
			$back['tip'] = '异常请求,搜索条件有误!';
			points::jan($back);
		}
		if(!in_array($_POST['oper'],['=','<','>','<=','>=','!=','LIKE']))
		{
			$back['tip'] = '异常请求,搜索条件有误!';
			points::jan($back);
		}
		if($_POST['oper'] == 'LIKE')
		{
			$where .= empty($where) ? ' WHERE ' . $_POST['fsearch'] . ' ' . $_POST['oper'] . " '%" . trim($_POST['search']) . "%'"
									: ' AND ' . $_POST['fsearch'] . ' ' .  $_POST['oper'] . " '%" . trim($_POST['search']) . "%'";
		}else
		{
			$where .= empty($where) ? ' WHERE ' . $_POST['fsearch'] . ' ' .  $_POST['oper'] . '"' . trim($_POST['search']) . '"'
									: ' AND ' . $_POST['fsearch'] . ' ' .  $_POST['oper'] . '"' . trim($_POST['search']) . '"';
		}
	}

	$rest = '';
	if(!empty($_POST['newest']))
	{
		if(empty($field['dated']))
		{
			$back['tip'] = '异常请求,没有记录时间标识符';
			points::jan($back);
		}
		if(!ctype_digit($_POST['newest']))
		{
			$back['tip'] = '异常请求,提供了一个无效的记录限制值！';
			points::jan($back);
		}
		$rest = ' ORDER BY ' . $field['dated'][0] . ' DESC LIMIT ' . $_POST['newest'] . ' OFFSET 0';
	}
	
	//分页
	if(empty($rest))
	{
		$rows = ($page - 1) * $back['size'];
		$rest = ' LIMIT ' . $back['size'] . ' OFFSET ' . $rows;
	}
	$back['condition'] = empty($where) ? '默认的搜索条件' : $where;
	
	$totalize = strtr($statement['totalize'],[':WHERE'=>$where]); //替换计算总数SQL的 :WHERE
	$fields = implode(',',$titles);
	$selected = strtr($statement['statement'],[':FIELDS'=>$fields,':WHERE'=>$where]);//替换查询语句的 :WHERE

	$_SESSION[TAG]['export']['select'] = $selected; //为导出存储查询 注意不要ordery by 及其它部分
	
	$selected .= $rest;
	
	//执行查询是否有数据可用于显示
	$query = DBC::selected($totalize,[],['one'=>TRUE]); 
	$back['total'] = $query['total'];
	if($back['total'] == 0)
	{	
		$back['status'] = 1;
		points::jan($back);	
	}

	//执行查询 表格条目显示 注意这里没有处理翻译设定  以后再添加
	$slt = DBC::selected($selected,[]);

	$tbody = '';
	for($i=0,$length=count($slt);$i<$length;$i++)
	{
		$tbody .= '<tr>';
		for($j=0,$len=count($titles);$j<$len;$j++)
		{
			$tbody .= '<td title="' . $slt[$i][$titles[$j]] . '">' . $slt[$i][$titles[$j]] . '</td>';
		}
		$tbody .= '</tr>';
	}
	
	$back['status'] = 1;
	$back['tbody'] = $tbody;
	
	points::jan($back);