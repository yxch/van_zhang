<?php
    ob_start();
    header("content-Type:text/html;charset='utf-8'");
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    require $_SERVER['DOCUMENT_ROOT'] . '/points/plugins/PHPExcel/IOFactory.php'; //引入接口
    require $_SERVER['DOCUMENT_ROOT'] . '/points/plugins/PHPExcel/PHPExcel.php';
    
    //此用户是否有导出权限
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'export')){ exit('export authority requested');}
    
    $oExcel = new PHPExcel();	// 创建一个处理对象实例
    $oExcel->getProperties()->setTitle('Microsoft Office Excel Document');
    $oExcel->setActiveSheetIndex(0); //操作第一个工作表
    $objActSheet = $oExcel->getActiveSheet();
    $objActSheet->setTitle(iconv('gbk','utf-8','数据报表'));  
    $objWriter = PHPExcel_IOFactory::createWriter($oExcel, 'Excel5');
    ob_clean();
    
    //参数值校验
    if(!isset($_GET['f']) || !ctype_digit($_GET['f'])){ exit('The filter invalid'); }
    $filter = $_GET['f']; //过滤器id
  
    $fieldArr = $_SESSION['points']['banker']['fields'];
    $titleArr = $_SESSION['points']['banker']['titles'];
    $translators = $_SESSION['points']['banker']['translators'];
    $select = $_SESSION['points']['banker']['select'];
    $factor = $_SESSION['points']['banker']['factor'];
    $rest = $_SESSION['points']['banker']['rest'];
    $recorder = $_SESSION['points']['banker']['recorder'];
   
    if(!isset($_GET['t']) || !in_array($_GET['t'],array('0','1','2','3'))){ exit('incorrect export type'); }
    $type = $_GET['t']; //导出类型
    
    //获取数据 select部分可以不提供选择字段，由本程序处理。如果提供了select字段部分必须对应显示字段
    if(stripos($select,'select') === false){ $select = 'SELECT ' . implode(',',$fieldArr) . ' ' . $select; }
    
    ini_set('max_execution_time',600); //临时修改页面最大执行时间
    ini_set("memory_limit","1024M"); //临时修改内存分配
    
    //导出指定时间范围内的条目
    if($type == 0)
    {
        if(!isset($_GET['stime']) || empty($_GET['stime'])){ exit('The export type must be supported by the start time.'); }
        if(!STR::timed($_GET['stime'])){ exit('incorrect time format or time value.'); }
        if(!isset($_GET['etime']) || empty($_GET['etime'])){ exit('The export type must be supported by the end time.'); }
        if(!STR::timed($_GET['etime'])){ exit('incorrent time format or time value.'); }
        if(strtotime($_GET['stime']) > strtotime($_GET['etime'])){ exit('the start time is not greater than the end time.'); }
        
        if(empty($recorder)){ exit('missing parameter recorder'); }
        
        $factor = empty($factor) ? "WHERE {$recorder} >= '{$_GET['stime']}' AND {$recorder} <= '{$_GET['etime']}'"
                                 : " AND {$recorder} >= '{$_GET['stime']}' AND {$recorder} <= '{$_GET['etime']}'";
       
        $SQL = $select . ' ' . $factor . ' ' . $rest;        
    }
    
    //导出最新的x个条目
    if($type == 1)
    {
        if(!isset($_GET['n']) || (int)$_GET['n'] <= 0){ exit('The export type must be supported by the nowest value.'); }
        $rows = $_GET['n'];
        
        if(empty($recorder)){ exit('missing parameter recorder'); }
        
        if(empty($rest)){   $rest = " ORDER BY {$recorder} DESC LIMIT $rows OFFSET 0";
        }else{              $rest .= " LIMIT $rows OFFSET 0"; }
        
        $SQL = $select . ' ' . $factor . ' ' . $rest;
    }
    
    //导出全部 不推荐 因为记录过多需要调整php对于内存限制的配置
    if($type == 2){  $SQL = $select . ' ' . $factor . ' ' . $factor; }
    
    //导出当前页
    if($type == 3)
    {
        if(!isset($_GET['p']) || !ctype_digit($_GET['p'])){ exit('The export type must be supported by the current page'); }
        $pageSize = 15;
        $limit = " LIMIT $pageSize OFFSET " . ($_GET['p'] - 1) * $pageSize;
        $SQL = $select . ' ' . $factor . ' ' . $rest . ' ' . $limit;
    }
    
    //临时使用的函数 开始
    function translator($key,$v,array $translator)
    {
        if(!isset($translator[$key])){ return $v; } //如果没有设定此字段的翻译条件，立即返回字段的原始值
        $tran = $translator[$key];
        if(stripos($tran,'fun') !== false)
        {
            $trans = explode(':',$tran);
            eval("\$v = " . $trans[1] . ";");
            return $v; //返回翻译后的值
        }
        if(stripos($tran,'recorder') !== false){ return $v; }
        if(stripos($tran,'modifier') !== false){ return $v; }
        
        if(strpos($tran,',') !== false) // 1:男,2:女,3:保密
        {
            $arr = explode(',',$tran);
            for($i=0,$l=count($arr);$i<$l;$i++)
            {
                $_arr = explode(':',$arr[$i]);
                if($_arr[0] == $v){ return $_arr[1]; }
            }
        }
        return $v;
    }
    //临时使用的函数 结束
    
    //设置单元格的值
    $len = count($titleArr);
    for($i=0;$i<$len;$i++) //打印标题
    {
      $objActSheet->setCellValue( chr(65 + $i) . '1', $titleArr[$i]);
      $objActSheet->getColumndimension(chr(65 + $i))->setWidth(32);
    }
    
    $res = DBC::execute($SQL);  //查询数据
    $total = count($res); //总数
    
    for($j=0;$j<$total;$j++) //输出查询内容
    {
        for($k=0,$t=count($fieldArr);$k<$t;$k++)
        {
            //$v = points::translator($fieldArr[$k],$res[$j][$fieldArr[$k]],$translators);
            $v = translator($fieldArr[$k],$res[$j][$fieldArr[$k]],$translators);
            $postprefix = $j + 2;
            $objActSheet->setCellValueExplicit(chr(65 + $k) . $postprefix, $v ,PHPExcel_Cell_DataType::TYPE_STRING); //字符格式
        }
    }
    
    $filename = $_SESSION['points']['banker']['name'] . ".xls";
    if($type == 0){ $_SESSION['points']['banker']['name'] . '[' . $_GET['stime'] . '_' . $_GET['etime'] .']' . '.xls'; }
  
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control:must-revalidate, post-check = 0, pre-check = 0");
    header("Content-Type:application/force-download");
    header("Content-Type:application/vnd.ms-execl;charset=utf-8");
    header("Content-Type:application/octet-stream");
    header("Content-Type:application/download");
    header('Content-Type:application/x-msexecl;name="'. $filename . '"');
    header('Content-Disposition:inline;filename="'. $filename .'"');
    header("Content-Transfer-Encoding:binary");
    $objWriter->save('php://output');
    exit;
