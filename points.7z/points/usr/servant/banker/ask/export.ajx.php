<?php   
    ob_start();
    header("content-Type:text/html;charset='utf-8'");
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    require $_SERVER['DOCUMENT_ROOT'] . '/points/cross/plugin/PHPExcel/IOFactory.php'; //引入接口
    require $_SERVER['DOCUMENT_ROOT'] . '/points/cross/plugin/PHPExcel/PHPExcel.php';
    
    //此用户是否有导出权限
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'export')){ exit(STR::error('export authority requested')); }
    
    $oExcel = new PHPExcel();	// 创建一个处理对象实例
    $oExcel->getProperties()->setTitle('Microsoft Office Excel Document');
    $oExcel->setActiveSheetIndex(0); //操作第一个工作表
    $objActSheet = $oExcel->getActiveSheet();
    $objActSheet->setTitle(iconv('gbk','utf-8','数据报表'));  
    $objWriter = PHPExcel_IOFactory::createWriter($oExcel, 'Excel5');
    ob_clean();
  
    //ini_set('max_execution_time',600); //临时修改页面最大执行时间
    ini_set("memory_limit","512M"); //临时修改内存分配

	//检查必要参数
	if(!isset($_SESSION[TAG]['export']['fields']) || empty($_SESSION[TAG]['export']['fields']))
	{
		exit(STR::error('lack of necessary parameters'));
	}
	$fields = $_SESSION[TAG]['export']['fields'];
	
	if(!isset($_SESSION[TAG]['export']['alias']) || empty($_SESSION[TAG]['export']['alias']))
	{
		exit(STR::error('lack of necessary parameters'));
	}
	$alias = $_SESSION[TAG]['export']['alias'];
	
	if(!isset($_SESSION[TAG]['export']['select']) || empty($_SESSION[TAG]['export']['select']))
	{
		exit(STR::error('lack of necessary parameters'));
	}
	$select = $_SESSION[TAG]['export']['select'];

	//是否是导出当前页
	if(isset($_GET['range']) && $_GET['range'] == '1')
	{
		$page = isset($_SESSION[TAG]['export']['page']) ? $_SESSION[TAG]['export']['page'] : 1;
		$size = isset($_SESSION[TAG]['export']['size']) ? $_SESSION[TAG]['export']['size'] : 15;
		
		$rst = '';
		if(isset($_SESSION[TAG]['export']['order']) && !empty($_SESSION[TAG]['export']['order']))
		{
			$rst = 'ORDER BY ' . $_SESSION[TAG]['export']['order'] . ' DESC '; 
		}
		$rst .= 'LIMIT ' . $size . ' OFFSET ' . ($page - 1) * $size;
	}
	
	$res = DBC::selected($select . $rst,[]);
	$resLen = count($res);
	if($resLen == 0){ exit(STR::error('Queried Error,please check SQL!')); }
    
    //设置单元格的值
    $len = count($alias);
    for($i=0;$i<$len;$i++) //打印标题
    {
      $objActSheet->setCellValue( chr(65 + $i) . '1', $alias[$i]);
      $objActSheet->getColumndimension(chr(65 + $i))->setWidth(32);
    }
    
    for($j=0;$j<$resLen;$j++) //输出查询内容
    {
        for($k=0,$t=count($fields);$k<$t;$k++)
        {
            $v = $res[$j][$fields[$k]];
            $postprefix = $j + 2;
            $objActSheet->setCellValueExplicit(chr(65 + $k) . $postprefix, $v ,PHPExcel_Cell_DataType::TYPE_STRING); //字符格式
        }
    }
    
    $filename = $_SESSION[TAG]['category'][$_SESSION[TAG]['item']['id']]['title'] . ".xls";
  
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control:must-revalidate, post-check = 0, pre-check = 0");
    header("Content-Type:application/force-download");
    header("Content-Type:application/vnd.ms-execl;charset=utf-8");
    header("Content-Type:application/octet-stream");
    header("Content-Type:application/download");
    header('Content-Type:application/x-msexecl;name="'. $filename . '"');
    header('Content-Disposition:inline;filename="'. $filename .'"');
    header("Content-Transfer-Encoding:binary");
    $objWriter->save('php://output');
    exit;
