$(document).ready(function(){
	var ask = 'ask/banker.ajx.php';
	
	var j = {};
	var stime = $('#stime'),etime = $('#etime'),newest = $('#newest');
	var start = $('#start'),ended = $('#ended'),search = $('#search');
	
	j.stime = $.trim(stime.val());
	j.etime = $.trim(etime.val());
	j.newest = $.trim(newest.val());
	j.start = $.trim(start.val());
	j.end = $.trim(ended.val());
	j.fsearch = $('#fsearch').val();
	j.oper = $('input[name="oper"]:checked').val();
	j.search = $.trim(search.val());
	j.page = 1;
	
	grid(ask,j);
		
	function grid(url,json)
	{
		json.filter = $('#filter').val();
		var fields = [];
		$('#pop #fields li label input').each(function(i,obj){
			var o = $(obj);
			if(o.is(':checked')){ fields.push(o.val()); }
		});
		json.fields = fields.join('|');

		$.post(url,json,function(r){
			var jn = $.parseJSON(r);
			if(jn.status == '1')
			{
				if(parseInt(jn.total) > 0)
				{
					$('#h2').html(jn.condition);
					j.page = jn.page;
					$('#grid thead tr').html(jn.thead);
					$('#grid tbody').html('');
					$('#grid tbody').html(jn.tbody);
					$('#grid tfoot tr td').attr('colspan',jn.titles);
					$('#grid tfoot #paging').html(paging({"total":jn.total,"size":jn.size,"page":jn.page}).full());
					$('#grid tfoot #totalize label').text(jn.total);
					$('#grid tfoot').show();
					
				}else{	$('#grid tbody #none td').text('没有可用数据显示......');	}

			}else{	global.tip(jn.tip,jn.type); }
		});
	}

	//分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        $('#pager #fpage #goto').val(num);
		j.page = num;
        grid(ask,j);
    });
    $('#paging').delegate('#goto','keyup',function(e){
        var v = parseInt($(this).val());
		j.page = v;
        if(e.which == 13){ if(!isNaN(v)){ grid(ask,j); }  }
    });

	//过滤选项
	var layerIndex = '';
	$('#opt').click(function(){
		//获取显示内容
		var json = {"filter":$('#filter').val(),"opt":1};
		$.post('ask/banker.ajx.php',json,function(r){
			var j = $.parseJSON(r);
			if(j.range == 1) //填充时间范围
			{ 
				$('#pop #where #range').show(); 
				$('#pop #where #newests').show();
			}  
			if(j.section == 1){ $('#pop #where #section').show(); }  //填充ID区间
			if(!(j.fsearch.empty()))  //填充搜索
			{ 
				var fsearch = j.fsearch.split('|');
				var fsearchAlias = j.fsearchAlias.split('|');
				var options = '';
				for(var i=0;i<fsearch.length;i++)
				{
					options += '<option value="' + fsearch[i] +  '">' + fsearchAlias[i] + '</option>';
				}
				$('#fsearch').html(options);
				$('#pop #where #condition').show(); 
			}
			var fields = $.parseJSON(j.fields); //字段
			var alias = $.parseJSON(j.alias);   //显示名
			var li = '';
			for(var k=0;k<fields.length;k++)
			{
				li += '<li>';
				for(var m=0;m<fields[k].length;m++)
				{
					li += '<label><input type="checkbox" class="field" value="' + fields[k][m] + '" />' + alias[k][m] + '</label>';
				}
				li += '</li>';
			}
			$('#fields').html(li); //填充字段
			//显示对话框
			layerIndex = layer.open({
				type: 1,
				area:['600px','520px'],
				title:'组全条件和字段对话框',
				content: $('#pop')
			});
		});
	});
	
	//保存对话信息
	$('#ensure').click(function(){
		j.stime = $.trim(stime.val());
		j.etime = $.trim(etime.val());
		j.newest = $.trim(newest.val());
		j.start = $.trim(start.val());
		j.end = $.trim(ended.val());
		j.fsearch = $('#fsearch').val();
		j.oper = $('input[name="oper"]:checked').val();
		j.search = $.trim(search.val());
		j.page = 1;
		grid(ask,j);
		//关闭弹窗
		layer.close(layerIndex);
		stime.val(''),etime.val(''),newest.val(''),	start.val(''),ended.val(''),search.val('');
	});
	
	//时间输入框得到焦点
	$('#stime').focus(function(){
		if($(this).empty()){ $(this).val(global.dateTime('date') + ' 23:59:59'); 	}
	});
	$('#etime').focus(function(){
		if($(this).empty()){ $(this).val(global.dateTime('date') + ' 23:59:59'); 	}
	});

	//导出事件
	$('#export').click(function(){
		var range = $('#exports').is(':checked') ? '1' : '0';
		window.location.href = 'ask/export.ajx.php?range=' + range;
	});
});