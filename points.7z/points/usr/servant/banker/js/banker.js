$(document).ready(function(){
	var ask = 'ask/banker.ajx.php';
	grid(ask,{"page":1});

	function grid(url,json)
	{
		json.filter = $('#filter').val();
		$.post(url,json,function(r){
			var j = $.parseJSON(r);
			if(j.status == '1')
			{
				if(parseInt(j.total) > 0)
				{
					$('#grid thead tr').html(j.thead);
					$('#grid tbody').html('');
					$('#grid tbody').html(j.tbody);
					$('#grid tfoot tr td').attr('colspan',j.titles);
					$('#grid tfoot #paging').html(paging({"total":j.total}).full());
					$('#grid tfoot #totalize label').text(j.total);
					
				}else{	$('#grid tbody #none td').text('没有可用数据显示......');	}

			}else{	global.tip(j.tip,j.type); }
		});
	}


});