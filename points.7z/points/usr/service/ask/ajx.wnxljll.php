<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
       
    //产品到账户的映射
    $products = array('100000'=>points::accounts() );
     //校验产品编号
    if(!isset($products[$_POST['product']])){  exit; /**产品编号异常，可能不是正常访问*/ }
    $acc = $products[$_POST['product']]; 
    
    $page = $_POST['page']; //第几页 当前页
    //校验一下$page 必须为一个整数
    if(!ctype_digit($page)){ exit; /**异常的参数传入*/ }
    //返回的json_encode数组
    $collect = array('page'=>$page,'pageTotal'=>0,'plaid'=>'','fpage'=>'');
    
    //利率结算时间
    $year = $_POST['year'];
    $month = $_POST['month'];
    //验证时间值
    if(!empty($year))
    {
        if(!ctype_digit($year) || $year < 1900 || $year > 2999){ points::jan($collect); }
    }
    if(!empty($month))
    {
        if(!ctype_digit($month) || $month < 1 || $month > 12 ){ points::jan($collect); }
    }
    
    //生成确保账户状态为1的查询条件
    $keys = array_keys($acc);
    for($i=0,$l=count($keys);$i<$l;$i++){ $keys[$i] = "account = '" . $keys[$i] . "'"; }
    //确保账户状态为1才执行单位价格查询
    $accounts = new account('(' . implode(' OR ',$keys) . ')' . ' AND status = 1');
    $accountArr = $accounts->get(array('id','account'));
    $accRelation = array(); //账户id与名称如rate_year的映射数组 在年化率时仅显示两位小数，在展示数据时用到这个数组
    
    //table标题
    $header = '<tr><th class="n-head" width="20%"><span class="t-head">结算时间</span></th>';
    $empty = '<div id="empty">没有可用数据!</div>';
    //标题添加账户信息
    if($accounts->iTotal() > 0)
    {
        for($i=0;$i<$accounts->iTotal();$i++)
        {
            $header .= '<th class="t-head">' . $acc[$accountArr['account'][$i]] . '<i class="icon icon-table-arrow"></i></th>';
            //生成账户id与名称的映射
            $accRelation[$accountArr['id'][$i]] = $accountArr['account'][$i];
        }
        $header .= '</tr>';
        
    //查询账户的status都为0即都不可用
    }else{ $collect['plaid'] = $empty;  points::jan($collect);  }
    
    //获取表数据
    $pageSize = 10; //分页大小
    //查询条件
    $ids = implode(',',$accountArr['id']);
    $where = "accountId IN($ids) "; //注意有一个空白
    
    //如果结算月份为空则显示当前月份结算价值
    if(empty($year) && empty($month)){ $where .= ''; }
    if(!empty($year) && empty($month))
    {
        $where .= 'AND substring(settleTime,1,4)=' . $year;
    }
    if(!empty($year) && !empty($month))
    {
        $_time = $year . '-' . $month;
        $where .= "AND substring(settleTime,1,7)='{$_time}'";
    }
    if(empty($year) && !empty($month))
    {
        $where .= 'AND substring(settleTime,6,2)=' . $month;
    }
    
    //查出全部日期并排序分组
    $price = new prices($where);
    $dates = $price->get(array('settleTime')); 
    $settles = array_unique($dates['settleTime']); 
    rsort($settles); 
    $chunk = array_chunk($settles,$pageSize);
    $pageTotal = count($chunk); //总页数
    $collect['pageTotal'] = $pageTotal;
    
    //指定的当前页
    if(!isset($chunk[$page-1])){ $collect['plaid'] = $empty;  points::jan($collect); }
    $or = '';
    for($k=0,$l=count($chunk[$page-1]);$k<$l;$k++)
    {
        if($k == $l-1){ $or .= "substring(settleTime,1,7)='{$chunk[$page-1][$k]}'";
        }else{          $or .= "substring(settleTime,1,7)='{$chunk[$page-1][$k]}'". ' OR ';}
    }
    $where .= ' AND (' . $or . ')';
    //获取数据
    $prices = new prices($where,array('order'=>'settleTime DESC'));
    $pricesArr = $prices->get(array('accountId','price','settleTime'));
    
    //分组
    $ar = array();
    for($j=0;$j<$prices->iTotal();$j++)
    {
        $ar[$pricesArr['settleTime'][$j]][$pricesArr['accountId'][$j]] = $pricesArr['price'][$j];
    }      
    //var_dump($ar);exit;
    //展示数据
    if(count($ar) > 0)
    {
        $html = '';
        foreach($ar as $k=>$v)
        {
            $_arr = explode('-',$k);
            if($_arr[1] <= 9){ $_arr[1] = '0' . (int)$_arr[1]; }
            $_k = $_arr[0] . '年' . $_arr[1] . '月';
            $html .= '<tr><td>' . $_k . '</td>';
            for($k=0;$k<$accounts->iTotal();$k++)
            {
                if(isset($v[$accountArr['id'][$k]]))
                {
                    $_price = ($v[$accountArr['id'][$k]] / 100);
                    if($accRelation[$accountArr['id'][$k]] == 'rate_year') //年化率两位小数
                    {
                        $_v = sprintf("%.2f",$_price);
                        $html .= '<td>' . $_v . '%</td>';
                        
                    }else{ $html .= '<td>' . sprintf("%.6f",$_price) . '%</td>'; }
                    
                }else{ $html .= '<td>－</td>'; }
               
            }
            $html .= '</tr>';
        }
        //更新分页信息
        $collect['fpage'] = '<a href="javascript:void(0)" id="first">首页</a><a href="javascript:void(0)" id="previous">上一页</a><a href="javascript:void(0)" id="next">下一页</a><a href="javascript:void(0)" id="end">尾页</a><span>共' . count($settles) . '条</span><span>共' . $pageTotal . '页</span><span>每页' . $pageSize .'条</span><script type="text/javascript" src="/sites/default/themes/cigna_cmc/service/js/ajx.wnxljll.js"></script>';
        $collect['plaid'] = $header . $html;
        
    //没有可用内容
    }else{ $collect['plaid'] = $empty; }
    points::jan($collect);  

