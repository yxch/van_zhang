<?php
class regions extends DBO
{
    protected $id;
    protected $name;
    protected $region;
    protected $authority;
    protected $directory;
    protected $status;
	protected $modifiedTime;
    protected $createTime;
    
    protected function definedTableName(){ return 'tb_points_regions'; }
    protected function definedPrimaryKey(){ return 'id'; }
    protected function definedRelations()
    {
        return array('id'=>'id',
                     'named'=>'name',
                     'region'=>'region',
                     'auth'=>'authority',
                     'dir'=>'directory',
                     'yes'=>'status',
					 'mtime'=>'modifiedTime',
                     'ctime'=>'createTime'         );
    }
}
