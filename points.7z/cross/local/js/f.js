/**
 *适用于表格式处理的js文件
 *van_zhang
 */

var f = {};

f.dateTime = function(x)
{
    var y = x || '';
    var d = new Date();
    var date = d.getFullYear() + '-'
               + (d.getMonth() + 1 > 9 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-'
               + (d.getDate() > 9 ? d.getDate() : '0' + (d.getDate()));
    var time = (d.getHours() > 9 ? d.getHours() : '0' + (d.getHours())) + ':'
               + (d.getMinutes() > 9 ? d.getMinutes() : '0' + (d.getMinutes())) + ':'
               + (d.getSeconds() > 9 ? d.getSeconds() : '0' + (d.getSeconds()));
    if (y == 'date') { return date; }
    if (y == 'time') { return time; }
    return date + ' ' + time;
};

//设定#pop的大小函数
f.pop = function()
{
    var w = $(window).width(), h = $(window).height();
    var _w = $('#pop').width(),_h = $('#pop').height();        
    var left = Math.ceil((w - _w) / 2) + 'px',top = Math.ceil((h - _h) / 2) + 'px';        
    $('#pop').css({marginLeft:left,marginTop:top});
};

//表格的行的单击函数定义
f._trClick = function ()
{
    var obj = $(this).children('td:first-child');      
    if ($(this).hasClass('checked'))
    {
        $(this).removeClass('checked');
        obj.children('label').css('background','');
    }else
    {
        $(this).addClass('checked');
        obj.children('label').css('background','url(/points/usr/local/images/selected.png) no-repeat');
    }
};

$(document).ready(function(){
    
    $('#closed').click(function(){
        $('#error').html('');
        $('#pop').hide();
        f.overlay().hide();    
    });   
    
    $('#grid',window.top.document).click(function(){ f.overlay(); });
    $(window).resize(function(){ f.overlay(); });
});