
DROP TABLE IF EXISTS `tb_points_category`;

CREATE TABLE `tb_points_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `md5` char(32) DEFAULT NULL COMMENT '路径MD5值',
  `title` varchar(64) DEFAULT NULL COMMENT '类别中文标题',
  `rid` int(11) DEFAULT NULL COMMENT '区域id',
  `murl` varchar(254) DEFAULT NULL COMMENT '管理路径',
  `tid` int(11) unsigned DEFAULT NULL,
  `pos` char(1) DEFAULT '1' COMMENT '隶属于1:前端页面显示2:后台管理页面',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`),
  KEY `yes` (`yes`),
  KEY `md5` (`md5`),
  KEY `rid` (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=708 DEFAULT CHARSET=utf8;

insert  into `tb_points_category`(`id`,`md5`,`title`,`rid`,`murl`,`tid`,`pos`,`yes`,`mtime`,`ctime`) values (701,'95331b78d9c7fa01183b64b44ec89f38','类别管理器',601,'http://system.points.org/usr/master/category/',301,'2','1','2016-03-08 16:33:51','2016-02-24 17:33:26'),(702,'df729e298001a98034eed6e3c351afba','区域管理器',601,'http://system.points.org/usr/master/regions/',302,'2','1',NULL,'2016-02-24 17:33:26'),(703,'64677b4b7bea8fe9963df2c304d84c97','用户管理器',601,'http://system.points.org/usr/master/users/',303,'2','1','2016-03-08 16:19:36','2016-02-24 17:33:26'),(704,'455733af3200ffb5aaa8e7ad36c66e47','权限管理器',601,'http://system.points.org/usr/master/powers/',304,'2','1',NULL,'2016-02-24 17:33:26'),(705,'6d9d8b070083cb6a01264ca87699528c','数据过滤器',601,'http://system.points.org/usr/filters/',305,'2','1',NULL,'2016-02-24 17:33:26'),(706,'af3f4175c9160c46b4e2136b66e9aa51','变量管理器',601,'http://system.points.org/usr/master/variable/',306,'2','1',NULL,'2016-02-24 17:33:26');

DROP TABLE IF EXISTS `tb_points_filters`;

CREATE TABLE `tb_points_filters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '过滤器名称',
  `cid` int(11) DEFAULT NULL COMMENT '所属类别id',
  `flds` text COMMENT '字段设定',
  `scher` varchar(254) DEFAULT NULL COMMENT '探索设定',
  `slt` text COMMENT 'SQL语句select部分',
  `factor` text COMMENT 'SQL语句where部分',
  `rst` text COMMENT 'SQL语句的其它部分',
  `flag` char(32) DEFAULT NULL COMMENT '显示字段唯一标识',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '是否废弃 1使用 0废弃',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `flag` (`flag`),
  KEY `yes` (`yes`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8;

insert  into `tb_points_filters`(`id`,`named`,`cid`,`flds`,`scher`,`slt`,`factor`,`rst`,`flag`,`yes`,`mtime`,`ctime`) values (1005,'兴业银行数据分析表',707,'{\"fields\":[\"id\",\"event_no\",\"channel\",\"name\",\"gender\",\"birthday\",\"mobile\",\"city\",\"created_ip\",\"addtime\",\"idcard\"],\"alias\":[\"\\u8868\\u5e8f\\u5217\",\"\\u6d3b\\u52a8\\u6807\\u8bc6\\u7b26\",\"\\u6e20\\u9053\",\"\\u59d3\\u540d\",\"\\u6027\\u522b F:\\u5973 M\\uff1a\\u7537 \\u7a7a\\u503c\\u8868\\u793a\\u672a\\u77e5\",\"\\u751f\\u65e5\",\"\\u624b\\u673a\\u53f7\",\"\\u57ce\\u5e02\",\"\\u521b\\u5efaIP\",\"\\u6dfb\\u52a0\\u65f6\\u95f4\",\"\\u8eab\\u4efd\\u8bc1\\u53f7\"],\"primary\":[\"id\"],\"increment\":[\"id\"],\"updated\":[\"event_no\"],\"dated\":[\"addtime\"],\"tbl\":\"tb_cib_201507\"}','','SELECT id,event_no,channel,name,gender,birthday,mobile,city,created_ip,addtime,idcard FROM tb_cib_201507','','','8f868251767cd6728d3548a4228053cc','1',NULL,'2016-03-11 17:06:37');

DROP TABLE IF EXISTS `tb_points_powers`;
CREATE TABLE `tb_points_powers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `cid` int(11) DEFAULT NULL COMMENT '分类id',
  `ctle` varchar(128) DEFAULT NULL COMMENT '类别的标题',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '权限值',
  `yes` char(1) NOT NULL DEFAULT '1',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cid` (`cid`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

insert  into `tb_points_powers`(`id`,`uid`,`cid`,`ctle`,`auth`,`yes`,`mtime`,`ctime`) values (1,25,36,'不知道','1000000000','1',NULL,'2016-03-15 16:43:12'),(2,30,31,'测试二','1000000000','1',NULL,'2016-03-15 16:43:30');

DROP TABLE IF EXISTS `tb_points_regions`;

CREATE TABLE `tb_points_regions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '区域的中文显示名',
  `region` char(1) NOT NULL DEFAULT '1' COMMENT '1:用户数据2:控制台3:定制',
  `auth` char(10) NOT NULL DEFAULT '1000000000' COMMENT '区域的默认权限',
  `dir` varchar(254) DEFAULT NULL COMMENT '区域的默认目录',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '区域的默认状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '区域的创建时间',
  PRIMARY KEY (`id`),
  KEY `named` (`named`),
  KEY `dir` (`dir`),
  KEY `region` (`region`),
  KEY `yes` (`yes`)
) ENGINE=InnoDB AUTO_INCREMENT=603 DEFAULT CHARSET=utf8;

insert  into `tb_points_regions`(`id`,`named`,`region`,`auth`,`dir`,`yes`,`mtime`,`ctime`) values (601,'设置中心','2','1000000000','/points/usr/master/','1',NULL,'2016-02-24 17:33:26'),(602,'劳而无功','1','1000000000','/system/master/category/','1','2016-03-15 16:41:06','2016-03-02 16:08:11');

DROP TABLE IF EXISTS `tb_points_session`;

CREATE TABLE `tb_points_session` (
  `sid` char(32) NOT NULL,
  `mme` int(11) DEFAULT NULL COMMENT 'session的修改时间',
  `cip` char(15) DEFAULT NULL COMMENT '客户端的ipv4的地址',
  `txt` text COMMENT '用户写入session的自定义内容',
  `ctt` text COMMENT '其它的基于session id的内容(通常是json格式的)',
  `yes` char(1) DEFAULT '1' COMMENT '状态描述',
  `cme` int(11) DEFAULT NULL COMMENT '记录创建时间，访问时间',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert  into `tb_points_session`(`sid`,`mme`,`cip`,`txt`,`ctt`,`yes`,`cme`) values ('gbgrfm1eqk7ddnifn5i8pp5kv1',1458036656,'10.141.139.12','points|a:6:{s:4:\"item\";a:1:{s:2:\"id\";s:3:\"702\";}s:3:\"VCE\";s:4:\"emdp\";s:6:\"region\";a:2:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:9:\"控制台\";}s:8:\"subrange\";a:2:{s:4:\"name\";s:12:\"设置中心\";s:9:\"directory\";s:19:\"/points/usr/master/\";}s:4:\"user\";a:4:{s:8:\"username\";s:7:\"pointer\";s:2:\"id\";s:3:\"101\";s:5:\"alias\";s:9:\"魔法师\";s:4:\"type\";s:1:\"9\";}s:8:\"category\";a:6:{i:701;a:4:{s:5:\"title\";s:15:\"类别管理器\";s:3:\"tid\";s:3:\"301\";s:3:\"MD5\";s:32:\"95331b78d9c7fa01183b64b44ec89f38\";s:9:\"authority\";s:10:\"1111111111\";}i:702;a:4:{s:5:\"title\";s:15:\"区域管理器\";s:3:\"tid\";s:3:\"302\";s:3:\"MD5\";s:32:\"df729e298001a98034eed6e3c351afba\";s:9:\"authority\";s:10:\"1111111111\";}i:703;a:4:{s:5:\"title\";s:15:\"用户管理器\";s:3:\"tid\";s:3:\"303\";s:3:\"MD5\";s:32:\"64677b4b7bea8fe9963df2c304d84c97\";s:9:\"authority\";s:10:\"1111111111\";}i:704;a:4:{s:5:\"title\";s:15:\"权限管理器\";s:3:\"tid\";s:3:\"304\";s:3:\"MD5\";s:32:\"455733af3200ffb5aaa8e7ad36c66e47\";s:9:\"authority\";s:10:\"1111111111\";}i:705;a:4:{s:5:\"title\";s:15:\"数据过滤器\";s:3:\"tid\";s:3:\"305\";s:3:\"MD5\";s:32:\"6d9d8b070083cb6a01264ca87699528c\";s:9:\"authority\";s:10:\"1111111111\";}i:706;a:4:{s:5:\"title\";s:15:\"变量管理器\";s:3:\"tid\";s:3:\"306\";s:3:\"MD5\";s:32:\"af3f4175c9160c46b4e2136b66e9aa51\";s:9:\"authority\";s:10:\"1111111111\";}}}',NULL,'1',1457929180);

DROP TABLE IF EXISTS `tb_points_template`;

CREATE TABLE `tb_points_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL COMMENT '模板标题',
  `md5` char(32) DEFAULT NULL COMMENT '路径标识符',
  `path` varchar(255) DEFAULT NULL COMMENT '路径',
  `div` text COMMENT '使用的div',
  `tag` tinyint(2) DEFAULT '1' COMMENT '标识符',
  `mme` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `cme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `md5` (`md5`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8;

insert  into `tb_points_template`(`id`,`title`,`md5`,`path`,`div`,`tag`,`mme`,`cme`) values (301,'类别管理器列表','2320111fed2678f8b240c0ae5cfceb20','/points/usr/master/category/category.php',NULL,1,NULL,'2016-03-14 08:03:12'),(302,'区域管理器列表','f9f6415e850501da0c562027ddcf0117','/points/usr/master/regions/regions.php',NULL,1,NULL,'2016-03-14 08:07:29'),(303,'用户管理器列表','606073f79117c7b813163fe699ea485e','/points/usr/master/users/users.php',NULL,1,NULL,'2016-03-14 08:09:21'),(304,'权限管理器列表','001732af3ffefb30afabdf291cd48bf9','/points/usr/master/users/power.php',NULL,1,NULL,'2016-03-14 08:13:05'),(305,'数据过滤器列表','782300e071ca7ae471f452c829016e24','/points/usr/master/filters/filters.php',NULL,1,NULL,'2016-03-14 08:14:30'),(306,'变量管理器列表','82bbf409f15df18137a59903c73789f6','/points/usr/master/variable/variable.php',NULL,1,NULL,'2016-03-14 08:15:42');

DROP TABLE IF EXISTS `tb_points_users`;

CREATE TABLE `tb_points_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '表主键 id',
  `usr` varchar(64) DEFAULT NULL COMMENT '用户名',
  `pwd` char(32) DEFAULT NULL COMMENT '密码',
  `alias` varchar(64) DEFAULT NULL COMMENT '中文别名',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱地址',
  `ppath` varchar(254) DEFAULT NULL COMMENT '头像路径',
  `tye` char(1) NOT NULL DEFAULT '1' COMMENT '作用范围: 1前端页面 2后台页面 3通用',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_usr` (`usr`),
  KEY `passwd` (`pwd`),
  KEY `yes` (`yes`),
  KEY `usr` (`usr`),
  KEY `tye` (`tye`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

insert  into `tb_points_users`(`id`,`usr`,`pwd`,`alias`,`email`,`ppath`,`tye`,`yes`,`mtime`,`ctime`) values (101,'pointer','afdd0b4ad2ec172c586e2150770fbf9e','魔法师','vxzhan@cignacmb.com.cn','','9','1','2016-03-15 13:08:54','2016-03-15 13:09:13');

DROP TABLE IF EXISTS `tb_points_variables`;

CREATE TABLE `tb_points_variables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `named` varchar(64) DEFAULT NULL COMMENT '变量名',
  `val` varchar(254) DEFAULT NULL COMMENT '变量值',
  `pos` char(32) DEFAULT NULL COMMENT '变量应用在',
  `url` varchar(254) DEFAULT NULL COMMENT '应用路径',
  `note` varchar(254) DEFAULT NULL COMMENT '变量的描述',
  `txt` text COMMENT '变量文本',
  `yes` char(1) NOT NULL DEFAULT '1' COMMENT '状态 1:用户变量 2:系统变量 0:废弃',
  `rule` varchar(32) DEFAULT NULL COMMENT '校验规则',
  `isuser` char(1) NOT NULL DEFAULT '1' COMMENT '是否用户可控 0不可控 1可控',
  `tye` varchar(32) NOT NULL DEFAULT 'text' COMMENT 'input的显示类型',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`,`ctime`),
  KEY `pos` (`pos`),
  KEY `named` (`named`),
  KEY `yes` (`yes`),
  KEY `note` (`note`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

insert  into `tb_points_variables`(`id`,`named`,`val`,`pos`,`url`,`note`,`txt`,`yes`,`rule`,`isuser`,`tye`,`mtime`,`ctime`) values (44,'stime','2016-03-11 12:50:18','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','标准时间变量一','','2','datetime','0','text',NULL,'2016-03-11 12:51:27'),(45,'etime','2016-03-11 12:50:18','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','标准时间变量二','','2','datetime','0','text',NULL,'2016-03-11 12:51:27'),(46,'serial','20160311125019','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','标准系统序列号','','2','digit','0','text',NULL,'2016-03-11 12:51:27'),(47,'psize','6','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','用户数据分页值','','2','digit','0','text',NULL,'2016-03-11 12:51:27'),(48,'cached','43200','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','缓存有效时间值','','2','digit','0','text',NULL,'2016-03-11 12:51:27'),(49,'shortid','235O98R','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','类别变量短标识','','2','text','0','text',NULL,'2016-03-11 12:51:27'),(50,'ssign','http://start.points.org','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','启用起始标识符','','2','text','0','text',NULL,'2016-03-11 12:51:27'),(51,'esign','http://end.points.org','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','启用终止标识符','','2','text','0','text',NULL,'2016-03-11 12:51:27'),(52,'limited','0-25','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','类别范围变量值','','2','limit','0','text',NULL,'2016-03-11 12:51:27'),(53,'auxiliary','2','8a64dd6a53e7488f5645d64ffd0e56f3','http://system.points.org/usr/master/tester/','附加信息标识符','','2','digit','0','text',NULL,'2016-03-11 12:51:27');

