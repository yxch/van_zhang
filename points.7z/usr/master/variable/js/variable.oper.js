
$(document).ready(function(){
    var vs = valued();
    //应用按钮事件
    $('#applied').click(function(){
        $('#err').text('');
        var v = valued();
        //用户是否已修改了某个值 
        var modifed = false,json = {};
        for(var p in v)
		{
			if(v[p] != vs[p]){ modifed = true; json[p] = v[p]; }
		}
        if (!modifed) 
		{ 
			global.tip('没有可用提交的内容，请检查输入是否有效！'); 
			return false; 
		}
        //校验输入
        var id = $('#id').text();
        if(!id.empty()){ json.id = id; } 
		json.murl = v.murl;
		json.name = v.name;
		json.status = v.status;
		json.isuser = v.isuser;
		if(json.value)
		{
			json.rule = v.rule;
			json.type = v.type;
		}
        $.post('ask/variable.oper.ajx.php',json,function(r){  //console.log(r);
            var j = $.parseJSON(r);
			if(j.status == 1)
			{
				global.tip(j.tip,'success');
				vs = valued();
			}else{ global.tip(j.tip,'error'); }
        });     
    });
    
    function valued()
    {
        return {"murl":$.trim($('#murl').val()),   
			    "status":$('#status').val(),
                "isuser":$('#isuser').val(),         
				"note":$.trim($('#note').val()),
                "name":$.trim($('#named').val()),
				"value":$.trim($('#val').val()),
                "rule":$('#rules').val(),           
				"type":$('#type').val(),           
				"text":$.trim($('#txt').val()) };
    }
});