<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    
    $set = array('status'=>0,'tip'=>'');    
    if(!empty($_POST['murl']))
    {
        $murls = points::SURL($_POST['murl'],1);
        if($murls['status'] == 0){ $set['tip'] = '提供的管理URL不符合要求';  points::jan($set); }
    }else{ $set['tip'] = '必须提供管理URL'; points::jan($set); }
    
    $v = array();
    //系统变量名集合
    $names = array('stime','etime','serial','psize','cached','shortid','limited','auxiliary','ssign','esign');
    //变量名的验证
    $name = trim($_POST['name']);
    $md5 = $murls['md5'];
    if(isset($_POST['id'])) // 修改 系统变量校验
    {
        //当前用户是否有修改条目的权限以防止恶意写入        
        if(!points::allowed($authority,'edit')){ $set['tip'] = '用户权限请求'; points::jan($set); }
        if(!ctype_digit($_POST['id'])){ $set['tip'] = '提供的编辑ID可能错误'; points::jan($set); }
        $var = new vars(array('id'=>$_POST['id']));
        $vars = $var->get(array('name','status','isUserControl','note','value','rule','type','text'));
        
        //无论是否是超级用户都不可以改变系统变量的名称
        if($vars['status'][0] == 2 && $_POST['name'] != $vars['name'][0]){ $set['tip'] = '不可以改变系统变量的名称'; points::jan($set); }
        
        //确认除本身外是否还存在相同的变量名
        $where = 'id !=' . $_POST['id'] . " AND name = '{$name}' AND position = '{$md5}'";
        $var = new vars($where);
        if($var->iTotal() > 0){ $set['err'] = '在' . $murls['url'] . '下已经定义了此变量'; points::jan($set);}
        if($_POST['name'] != $vars['name'][0]){ $v['name'] = trim($_POST['name']); }
       
        if($vars['status'][0] == 2 && $_SESSION['points']['user']['type'] != 9)
        {
            if($_POST['status'] != $vars['status'][0]){ $set['tip'] = '当前用户不能改变变量的状态'; points::jan($set); }
            if($_POST['isuser'] != $vars['isUserControl'][0]){ $set['tip'] = '当前用户不能改变用户控制类型'; points::jan($set); }
            if($_POST['note'] != $vars['note'][0]){ $set['tip'] = '当前用户不能改变变量的描述'; points::jan($set); }
        }
        if($_POST['status'] == 2 && $vars['status'][0] != 2 && $_SESSION['points']['user']['type'] != 9){  $set['tip'] = '当前用户不能将变量状态切换为系统变量'; points::jan($set); }
        if($_POST['status'] != $vars['status'][0])
        {
            $v['status'] = $_POST['status'];
            if($_POST['status'] != '2' && in_array($_POST['name'],$names)){ $set['tip'] = '当前变量名与系统内置变量名重名'; points::jan($set); }
        }
        if($_POST['isuser'] != $vars['isUserControl'][0]){ $v['isUserControl'] = $_POST['isuser']; }
        if($_POST['note'] != $vars['note'][0]){ $v['note'] = trim($_POST['note']); }
        if($_POST['value'] != $vars['value'][0] || $_POST['rule'] != $vars['rule'][0])
        {
            $v['rule'] = $_POST['rule'];
            $v['value'] = trim($_POST['value']);
        }
        if($_POST['type'] != $vars['type'][0]){ $v['type'] = $_POST['type']; }
        if(md5($_POST['text']) != md5($vars['text'][0])){ $v['text'] = $_POST['text']; }
        $v['modifiedTime'] = date('Y-m-d H:i:s');
        
    }else
    {
        //当前用户是否有新增条目的权限以防止恶意写入
        if(!points::allowed($authority,'add')){ $set['tip'] = '用户权限请求'; points::jan($set); }
        
        $v['url'] = $murls['url'];
        $v['position'] = $md5;
        //检查新增变量名是否与系统变量同名
        if(in_array($_POST['name'],$names)){ $set['tip'] = '增加的变量与系统内置变量同名';points::jan($set);}
        
        $where = "name = '{$name}' AND position = '{$md5}'";
        $var = new vars($where);
        if($var->iTotal() > 0){ $set['tip'] = '在' . $murls['url'] . '下已经定义了此变量'; points::jan($set); }        
        $v['name'] = trim($_POST['name']);
        
        if($_POST['status'] == '2' && $_SESSION['points']['user']['type'] != 9){ $set['tip'] = '此用户不能增加系统变量'; points::jan($set); }        
        if($_POST['status'] == 2 && $_SESSION['points']['user']['type'] != 9){ $set['tip'] = '当前用户不能增加系统变量'; points::jan($set); }
        $v['status'] = $_POST['status'];
        $v['isUserControl'] = $_POST['isuser'];
        //校验变量的描述   ？？？？
        $v['note'] = trim($_POST['note']);
        $v['value'] = trim($_POST['value']);
        $v['rule'] = $_POST['rule'];
        $v['type'] = $_POST['type'];
        $v['text'] = $_POST['text'];
    }
    if(isset($v['status']) && !in_array($v['status'],array('0','1','2'))){ $set['tip'] = '提供的变量状态值可能有误'; points::jan($set); }
    if(isset($v['isUserControl']) && !in_array($v['isUserControl'],array('0','1'))){ $set['tip'] = '提供的变量控制类型值可能有误'; points::jan($set); }
    if(isset($v['note']) && empty($v['note'])){ $set['tip'] = '变量的描述非常重要，不能置为空'; points::jan($set); }
    if(isset($v['name']) && empty($v['name'])){ $set['tip'] = '变量的名称非常重要，不能置为空'; points::jan($set); }
    if(isset($v['value']) && empty($v['value'])){ $set['tip'] = '变量的值不能为空'; points::jan($set); }
    $rules = array('text','digit','digits','datetime','int','boolean','limit','decimal','telephone','mobile','email','url','postcode');
    if(isset($v['rule']) && (!in_array($v['rule'],$rules) || empty($v['rule']))){ $set['tip'] = '提供了无效的值验证规则'; points::jan($set); }
    if((isset($v['value']) || isset($v['rule'])) && !STR::checkText($v['value'],$v['rule'])){ $set['tip'] = '当前值与选择的值的验证规则不符'; points::jan($set); }    
    if(isset($v['type']) && !in_array($v['type'],array('text','checkbox','radio','textarea'))){ $set['tip'] = '提供了无效的显示类型'; points::jan($set); }
            
    //提交编辑    
    $name = trim($_POST['name']);  
    if(isset($_POST['id']))
    {
        $var = new vars(array('id'=>$_POST['id']));
        if($var->set($v)){  $set['status'] = 1;  $set['tip'] = '更新成功';}      
        else{ $set['tip'] = '更新失败';}   
    
    }else //提交新增   
    {
        $var = new vars();
        if($var->set($v)){  $set['status'] = 1; $set['tip'] = '保存成功';}            
        else{ $set['tip'] = '保存失败'; }
    }
    //返回结果
    points::jan($set);
