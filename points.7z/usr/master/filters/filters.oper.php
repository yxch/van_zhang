<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    //require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    if(!isset($_GET['fid']) || !ctype_digit($_GET['fid'])){ exit('Required parameter missing!');}
    
	$title = '编辑数据过滤器[ID:<label id="id">' . $_GET['fid'] . '</label>]';
	//由id获取过滤器信息
	$filters = DBC::selected(SQL::GetFitlerFromPointsById,[':id'=>$_GET['fid']],['one'=>TRUE]);
	
	//显示全部类别但排除系统类别以供用户选择
	$sysurl = points::sysurl('md5'); //排除系统基本路径
	$categories = DBC::limited(SQL::GetCategoriesFromPointsCategory,$sysurl);
	$groups = array_chunk($categories,4); //分组显示 每组显示4个
	
	$li = '';
	$len = count($groups);
	for($j=0;$j<$len;$j++)
	{
		$li .= $j > 0 ? "<li id=\"dis{$j}\" style=\"display:none;\">" : '<li>';
		for($k=0,$L=count($groups[$j]);$k<$L;$k++)
		{
			$checked = $groups[$j][$k]['id'] == $filters['cid'] ? 'checked' : '';
			$li .= '<label><input type="radio" name="categories" value="' . 
				   $groups[$j][$k]['id'] .'"'  . $checked . '/>' . 
				   $groups[$j][$k]['title'] . '</label>';
		}
		//是否显示更多
		if($len > 0 && $j < $len - 1){ $n = $j + 1; $li .= "<label><a class=\"more\" id=\"more-{$n}\">更多>></a></label>"; }
		$li .= '</li>';
	}
	$tbl = json_decode($filters['fields'],true);
	$slt = json_decode($filters['statement'],true);
	$fieldLen = count($tbl['fields']);
?>
<!DCOTYPE html>
<html>
<head>
	<?php echo points::head(false); ?>
	<link rel="stylesheet" href="css/filters.oper.css" />
	<script src="/points/cross/local/js/points.js"></script>
</head>
<body>
	<div id="topic"><h1><?php echo $title; ?></h1></div>
	<div id="filter">
		<h2><a id="save-filter"><img title="保存" src="<?php echo IMAGE;?>save.png" /></a></h2>
		<div class="row">
			<label>为此数据过滤器指定所属类别：</label>
			<ul id="category"><?php echo $li; ?></ul>
		</div>
		<div class="row">
			<label>为此数据过滤器定义一个标题：</label><input type="text" id="ftitle" value="<?php echo $filters['name']; ?>" />
			<span id="status">
				<label>过滤器状态:</label>
				<select id="yes">
					<option value="1" <?php echo $filters['status'] == 1 ?'selected' : '';?>>启用</option>
					<option value="0" <?php echo $filters['status'] == 0 ?'selected' : '';?>>废弃</option>
				</select>
			</span>
			<p class="desc">标题可以识别此数据过滤器，易于用户在多个不同的数据过滤器之间切换，并根据标题来识别此数据过滤器的用途。</p>
		</div>
		<div class="row">
			<label class="opt">为此数据过滤器添加数据字段和显示字段及翻译设定</label>
			<span id="dbinfo">
				<select id="dbname">
					<option value="1">活动数据库</option>
					<option value="2">drupal基础数据库</option>
				</select>
				<label id="tname">表名：</label><input id="tablename" value="<?php  echo $tbl['tbl']; ?>" />
			</span>
		</div>
		<ul class="row">
			<li id="capital">
				<span class="most">数据表字段</span>
				<span class="most">显示标题名</span>
				<span>主键</span>
				<span>序列</span>
				<span>更正</span>
				<span>搜索</span>
				<span>时间</span>
				<span class="most">翻译设定</span>
				<span>操作</span>
				<span class="plus"><a id="fadd"> + </a><a id="fdelete"> - </a></span>
			</li>
			<?php for($i=0;$i<$fieldLen;$i++){ ?>
			<li class="rows">
				<span class="most"><input class="field" value="<?php echo $tbl['fields'][$i]; ?>" /></span>
				<span class="most"><input class="alias" value="<?php echo $tbl['alias'][$i]; ?>" /></span>
				<span><input class="primary" type="checkbox" <?php echo in_array($tbl['fields'][$i],$tbl['primary']) ? 'checked' : ''; ?> /></span>
				<span><input class="increment" type="checkbox" <?php echo in_array($tbl['fields'][$i],$tbl['increment']) ? 'checked' : ''; ?> /></span>
				<span><input class="fsearch" type="checkbox" <?php echo in_array($tbl['fields'][$i],$tbl['fsearch']) ? 'checked' : ''; ?> /></span>
				<span><input class="updated" type="checkbox" <?php echo in_array($tbl['fields'][$i],$tbl['updated']) ? 'checked' : ''; ?> /></span>
				<span><input class="dated" type="checkbox" <?php echo in_array($tbl['fields'][$i],$tbl['dated']) ? 'checked' : ''; ?> /></span>
				<span class="most"><input class="translator" value="<?php if(isset($tbl['translator'][$tbl['fields'][$i]])){ echo $tbl['translator'][$tbl['fields'][$i]]; } ?>" /></span>
				<span><input class="select" type="checkbox" /></span>
			</li>
			<?php } ?>
		</ul>
		<div class="row">
			<p class="desc">必须提供字段名和字段的描述性文字。描述性文字将在数据导出时显示为表格的标题。如果主键被选定，这将为此过滤器记录此字段为主键;如果序列被选中，将记录为自动序列通常是id;如果更正被选中，标明此字段可以在一定条件下被用户手动更新其值;如果时间字段被选中，标明此字段是记录的创建的时间；翻译设定可以为此字段使用额外的函数。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器的TOTALIZE语句：</label><textarea id="totalize"><?php echo $slt['totalize']; ?></textarea>
			<p class="desc">提供此过滤器计算符合条件的记录总数的SQL语句，注意WHERE子句用:WHERE替代。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器SELECT语句部分：</label><textarea id="statement"><?php echo $slt['statement']; ?></textarea>
			<p class="desc">提供此过滤器SQL语句查询具体记录详情部分,此处可能不适合太复杂的查询语句。请使用视图的方法来简化复杂查询。</p>
		</div>
		<div class="row">
			<label class="top">基于此过滤器的WHERE子句 ：</label><textarea id="condition"><?php echo $slt['condition']; ?></textarea>
			<p class="desc">提供此过滤器WHEE子句部分，将替换上面的:WHERE标识处的内容。</p>
		</div>
	</div>
	<div id="clone">
		<li class="rows">
			<span class="most"><input class="field" /></span>
			<span class="most"><input class="alias" /></span>
			<span><input class="primary" type="checkbox" /></span>
			<span><input class="increment" type="checkbox" /></span>
			<span><input class="updated" type="checkbox" /></span>
			<span><input class="fsearch" type="checkbox" /></span>
			<span><input class="dated" type="checkbox" /></span>
			<span class="most"><input class="translator" /></span>
			<span><input class="select" type="checkbox" /></span>
		</li>
	</div>
	<div id="announce"></div>
	<script src="js/filters.oper.js"></script>
</body>
</html>