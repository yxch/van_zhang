<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];    
    //返回的数据
    $back = array('page'=>$_POST['page'],'size'=>6,'total'=>0,'tbody'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
	
    //获取数据
	$oper = $_POST['displayer'] == '-1' ? ' >' : '=';
	$yes = ctype_digit($_POST['displayer']) ? (int)$_POST['displayer'] : 0;
    if(isset($_POST['searcher']) && !empty($_POST['searcher']))    
    {
        $search = trim($_POST['searcher']);
		$count = DBC::selected(SQL::SQLCategoryTotal($oper,TRUE),[':yes'=>$yes,':search'=>'%' . $search . '%'],['one'=>TRUE]);
		$back['total'] = $count['total'];
		//分页查询数据
		if($back['total'] > 0)
		{
			$category = DBC::selected(SQL::SQLCategoryList($oper,TRUE),[':yes'=>$yes,':search'=>'%' . $search . '%',
									  ':size'=>$back['size'], ':page'=>($back['page'] - 1) * $back['size']]); 
		}
    }else
	{ 
		//获取符合条件的总数并处理分页
		$count = DBC::selected(SQL::SQLCategoryTotal($oper),[':yes'=>$yes],['one'=>TRUE]);
		$back['total'] = $count['total'];
		//分页查询数据
		if($back['total'] > 0)
		{
			$category = DBC::selected(SQL::SQLCategoryList($oper),
			            [':yes'=>$yes,':size'=>$back['size'],':page'=>($back['page'] - 1) * $back['size']]);
		}
	}

	//字段显示映射集 $set的每个单元的第一个元素表示 表的别名 第二个元素表示显示的中文 第三个元素表示是否在初始化隐藏
	$set = [ ['id','表序列ID',0],['title','类别名称',0],['managingURL','管理URL',0],
		     ['templateId','访问模板文件',1],['regionId','区域ID',0],['position','位置',1],['status','当前状态',1],['createTime','创建时间',1] ];

	$tags = ['1'=>'系统的模板','0'=>'废弃的模板','2'=>'用户的模板'];
	$pos = ['1'=>'前端显示页面','2'=>'后端管理页面'];

	$categoryLen = isset($category) ? count($category) : 0;
	if($categoryLen > 0) //有可用于显示的内容
	{
		$ul = ''; 
		//打印内容
		for($i=0;$i<$categoryLen;$i++)
		{
			$ul .= '<ul id="ul_' .$category[$i][$set[0][0]] . '" class="page-lists">';
			for($j=0,$len=count($set);$j<$len;$j++)
			{
				//是否隐藏并确定是否有title内容
				$ul .= $set[$j][2] ? ($j == 0 ? '<li class="hide" title="点击这里选择">' : '<li class="hide">') 
					               : ($j == 0 ? '<li title="点击这里选择">' : '<li>');
				$ul .= '<i>' . $set[$j][1]. '</i>';
				$matter = '<span class="' . $set[$j][0] .  '">';
				if($set[$j][0] == 'status')
				{
					$matter .=  $tags[$category[$i][$set[$j][0]]];
				}else if($set[$j][0] == 'position')
				{
					$matter .=  $pos[$category[$i][$set[$j][0]]];
				}else
				{
					$matter .=  $category[$i][$set[$j][0]];
				}
				$ul .= $matter . '</span></li>';
			}
			$ul .= '<li class="more"><a title="查看更多">. . .</a></li>';
			$ul .= '</ul>';
		}
	}else //没有可用于显示的内容
	{
		$ul = '<ul class="page-lists empty">';
		$ul .= '<li><i></i><span></span></li>';
		$ul .= '<li><i></i><span>没有可用于显示的内容</span></li>';
		$ul .= '</ul>';
	}
	$back['tbody'] = $ul;
    points::jan($back);
