$(document).ready(function(){
	
	$('h2').click(function(){
		var parent = $(this).parent();
		if(parent.hasClass('show'))
		{
			parent.removeClass('show');
			parent.children('.row').hide();
		}else
		{
			parent.addClass('show');
			parent.children('.row').show();
		}
	});

	//===============类别=====================
	//保存category的初始值
	var category = getCategory();
	function getCategory()
	{
		return { "murl":$.trim($('#murl').val()), "pos":$('#pos').val(),"title":$('#title').val(),
				 "rid":$('#regions').val(),"tid":$('#template').val(),"status":$('#status').val()	};
	}
	$('#save-category').click(function(e){
		e.stopPropagation();
		var categories = getCategory(),submit = false,modified = {};
		for(var p in categories)
		{
			if(categories[p] != category[p]){ submit = true; modified[p] = categories[p]; }
		}
		if(!submit)
		{ 
			global.tip('没有可用于提交的内容,检查输入是否有误！','warning');
			return false; 
		}
		modified['id'] = $('#id').text();
		modified['murl'] = categories.murl;
		modified['pos'] = categories.pos;
		modified['rid'] = categories.rid;
		modified['tid'] = categories.tid;
		$.post('ask/category.oper.ajx.php',modified,function(r){  console.log(r);
			var json = $.parseJSON(r);
			if(json.status == 1)
			{
				global.tip(json.err,'success');
			}else{ global.tip(json.err,'error'); }
			category = getCategory(); //更新值列表
		});
	});

	//===============用户=====================
	$('.save-user').click(function(e){
		e.stopPropagation();
		//选择的用户
		var selected = [], posts = {};
		var selectables = $('#user #lists li label'); 
		selectables.each(function(i,o){
			var inputs = $(o).children('input');
			if(inputs.is(':checked')){ selected.push(inputs.val());}
		});
		posts.id = $('#id').text();
		posts.region = $('#regions').val();
		posts.uid = selected.join('|');
		posts.name = $.trim($('#username').val());
		posts.alias = $.trim($('#alias').val());
		posts.type = $('#type').val();
		if(posts.region.empty())
		{
			global.tip('没有选择区域，默认的用户权限根据选择的区域不同而不同！');
			return false;
		}
		if(posts.id.empty())
		{
			global.tip('指派的用户必须在一个类别名称下，请先保存类别后再指派用户！');
			return false;
		}
		if(posts.uid.empty() && posts.name.empty())  //选择或新建一个用户
		{
			global.tip('没有用户被指派！');
			return false;
		}
		$.post('ask/category.oper.user.ajx.php',posts,function(r){ 
			var j = $.parseJSON(r);
			global.tip(j.tip,j.type);
		});
	});

	 $(' .more').click(function(){
        var serial = $(this).attr('id').split('-')[1];
        if ($(this).hasClass('extend'))
        {
            $('#dis' + serial).fadeOut();
            $(this).removeClass('extend');
            $(this).text('更多>>');
        }else
        {
            $(this).addClass('extend');
            $('#dis' + serial).fadeIn();
            $(this).text('折叠>>');
        }
    });

	//===============变量=====================
	 //为空值对象提供默认值
    $('#stime,#etime,#serial').focus(function(){
        var date = new Date();
        var v = $.trim($(this).val());
        if (v.empty())
        {
            var arr = [];
            arr.push(date.getFullYear(),String(date.getMonth() + 1).doubled(),String(date.getDate()).doubled());
            var time = [];
            time.push(String(date.getHours()).doubled(),String(date.getMinutes()).doubled(),String(date.getSeconds()).doubled());
            if ($(this).attr('id') == 'serial')
            {
                $(this).val(arr.join('') + time.join(''));
            }else{ $(this).val(arr.join('-') + ' ' + time.join(':'));}
        }
    });
	//保存初始值
	var variable = getVariable();
	function getVariable()
	{
		return {"stime":$.trim($('#stime').val()),    "etime":$.trim($('#etime').val()),
				"serial":$.trim($('#serial').val()),		"psize":$.trim($('#psize').val()),
				"cached":$.trim($('#cached').val()),	"shortid":$.trim($('#shortid').val()),
				"ssign":$.trim($('#ssign').val()),		"esign":$.trim($('#esign').val()),
				"limited":$.trim($('#limited').val()),	"auxiliary":$.trim($('#auxiliary').val())		};
	}
	
	$('#save-variable').click(function(e){
		e.stopPropagation();
		var variables = getVariable(),submit = false,modified = {},vcount = 0;
		for(var p in variables)
		{
			if(variables[p] != variable[p])
			{ 
				submit = true;
				modified[p] = variables[p];
				vcount += 1;
			}
		}
		if(vcount == 0 ||!submit){ global.tip('没有可用于提交的内容，请检查输入','warning');return false; }
		if(modified.serial && isNaN(parseInt(modified.serial)))
		{ 
			global.tip('标准类别序列号只能是数字','warning');
			return false;
		}
		if(modified.psize && isNaN(parseInt(modified.psize)))
		{ 
			global.tip('用户数据分页值只能是数字','warning');
			return false;
		}
		if(modified.cached && isNaN(parseInt(modified.cached)))
		{ 
			global.tip('缓存有效时间值只能是数字','warning');
			return false;
		}
		if(modified.auxiliary && isNaN(parseInt(modified.auxiliary)))
		{ 
			global.tip('附加信息标识符只能是一个数字','warning');
			return false;
		}
		modified.murl = $.trim($('#murl').val());
		if(modified.murl.empty())
		{
			global.tip('变量必须指定在相关的类别管理标识符murl下','warning');
			return false;
		}
		//提交内容
        $.post('ask/category.oper.vars.ajx.php',modified,function(r){ console.log(r);
            var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
			variable = getVariable(); //更新值列表
        });    
	});
	
	//===============用户过滤器=====================
    //获取表的内容
	var clone = $('#filter ul .rows').clone();
    $('#tablename').keyup(function(e){
        if(e.which == 13)
        {
            var v = $.trim($(this).val());
            if(v.empty())
            {
				$('#filter ul .rows').empty();
				$('#filter ul #capital').after(clone);
                return false;
            }
            $.post('ask/category.oper.filter.db.ajx.php',{"db":$('#dbname').val(),"tb":v},function(r){ //console.log(r);
                var j = $.parseJSON(r);
                if(j.yes == 1)
                {
					$('#filter ul .rows').remove();
					$('#filter ul #capital').after(j.tbody);
					$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
					selectUpdate();
                }
            });
        }
    });  
	//获取表信息
	function getTableInfo()
	{
		var rows = $('#filter ul .rows');
		var fields = [],comment = [],primary = [],increment = [],updated = [],fsearch = [],dated = [],translator = [],err = 0;
		var json = {"errNum":0};
		json.table = $.trim($('#tablename').val());
		rows.each(function(i,obj){
			var child = $(obj).children('span'),fname = '';
			child.each(function(j,obj){
				var input = $(obj).children('input');
				if(j == 0 && input.hasClass('field'))
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : fields.push(v);
					fname = v;
				}
				if(j == 1 && input.hasClass('alias'))	
				{
					var v = $.trim(input.val());
					v.empty() ? err += 1 : comment.push(v);
				}
				if(j == 2 && input.hasClass('primary')){	if(input.is(':checked')){ primary.push(fname); }	}
				if(j == 3 && input.hasClass('increment')){	if(input.is(':checked')){ increment.push(fname); }	}
				if(j == 4 && input.hasClass('updated')){	if(input.is(':checked')){ updated.push(fname); }	}
				if(j == 5 && input.hasClass('fsearch')){	if(input.is(':checked')){ fsearch.push(fname); }	}
				if(j == 6 && input.hasClass('dated')){	if(input.is(':checked')){ dated.push(fname); }	}
				if(j == 7 && input.hasClass('translator'))
				{	
					if(!$.trim(input.val()).empty()){ translator.push(fname + '=' + $.trim(input.val())); }	
				}
			});
		});
		json.fields = fields.join('|');
		json.comment = comment.join('|');
		json.primary = primary.join('|');
		json.increment = increment.join('|');
		json.updated = updated.join('|');
		json.fsearch = fsearch.join('|');
		json.dated = dated.join('|');
		json.translator = translator.join('|');
		json.errNum = err;
		return json;
	}
    //过滤器 增加字段设定 + 的单击事件
    $('#fadd').click(function(){
		var selected = $('#filter ul li .select');
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked'))
			{
				check.removeAttr('checked');
				var parent = check.parent().parent();
				parent.after(parent.clone());
				$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
			}
		});
		selectUpdate();
    });
    //过滤器 增加字段设定 - 的单击事件
    $('#fdelete').click(function(){    
		var selected = $('#filter ul li .select'); 
		var selects = $('#filter ul .rows').length; 
		if($('#filter ul li .select:checked').length == selects){ return false; } //不能全部删除
		selected.each(function(i,obj){
			var check = $(obj);
			if(check.is(':checked')){	check.parent().parent().remove(); }
		});
		selectUpdate();
    });
	$('#filter ul .rows span .field').keyup(function(){ selectUpdate(); });
	//用户更正字段名称
	function selectUpdate()
	{
		var rows = getTableInfo();
		var fields = rows.fields.split('|').join(',');
		$('#totalize').val('SELECT COUNT(*) AS total ' + (rows.table.empty() ? '' : ' FROM ' + rows.table) + ' :WHERE');
		$('#statement').val('SELECT ' + fields + (rows.table.empty() ? '' : ' FROM ' + rows.table ) + ' :WHERE');
	}

	//保存过滤器
	$('#save-filter').click(function(e){ 
		e.stopPropagation();
		var filter = {}; 

		var id = $('#id').text();
		if(id.empty() || !global.positive(id))
		{
			global.tip('需要类别ID来限定过滤器的作用域【通常情况下先保存类别然后从类别列表界面来编辑】');return false;
		}
		filter.id = id;
		
		var title = $.trim($('#ftitle').val());
		if(title.empty())
		{
			global.tip('必须指定过滤器的标题【标题有利于识别管理标识符murl下不同的过滤器】');return false;
		}
		filter.title = title; //保存过滤器的标题
		
		var tb = getTableInfo();
		if(parseInt(tb.errNum) > 0)
		{
			global.tip('必须指定字段和标题名');return false;
		}
		filter.fields = tb.fields;
		filter.alias = tb.comment;
		filter.primary = tb.primary;
		filter.increment = tb.increment;
		filter.updated = tb.updated;
		filter.fsearch = tb.fsearch;
		filter.dated = tb.dated;
		filter.translator = tb.translator;
		filter.tblname = tb.table;
		var totalize = $.trim($('#statement').val());
		var statement = $.trim($('#statement').val());
		if(totalize.empty())
		{
			global.tip('必须提供计算符合条件的记录SQL');return false;
		}
		filter.totalize = totalize;
		if(statement.empty())
		{
			global.tip('必须提供查询SQL语句');return false;
		}
		filter.statement = statement;
		
		filter.condition = $.trim($('#condition').val());
		
		$.post('ask/category.oper.filter.ajx.php',filter,function(r){
			var j = $.parseJSON(r);
			if(j.status == 1){		global.tip(j.tip,'success');
			}else{					global.tip(j.tip,'error'); }
		});
	});
	
});
