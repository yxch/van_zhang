$(document).ready(function(){
	var ask = 'ask/banker.ajx.php';
	grid(ask,{"page":1});

	function grid(url,json)
	{
		json.filter = $('#filter').val();
		$.post(url,json,function(r){      console.log(r);
			var j = $.parseJSON(r);
			if(j.status == '1')
			{
				if(parseInt(j.total) > 0)
				{
					$('#grid thead tr').html(j.thead);
					$('#grid tbody').html('');
					$('#grid tbody').html(j.tbody);
					$('#grid tfoot tr td').attr('colspan',j.titles);
					$('#grid tfoot #paging').html(paging({"total":j.total}).full());
					$('#grid tfoot #totalize label').text(j.total);
					$('#grid tfoot').show();
					
				}else{	$('#grid tbody #none td').text('没有可用数据显示......');	}

			}else{	global.tip(j.tip,j.type); }
		});
	}

	//过滤选项
	var layerIndex = '';
	$('#opt').click(function(){
		//获取显示内容
		var json = {"filter":$('#filter').val(),"page":1,"opt":1};
		$.post('ask/banker.ajx.php',json,function(r){ console.log(r); 
			var j = $.parseJSON(r);
			if(j.range == 1){ $('#pop #where #range').show(); }
			if(j.section == 1){ $('#pop #where #section').show(); }
			if(!(j.fsearch.empty()))
			{ 
				var fsearch = j.fsearch.split('|');
				var fsearchAlias = j.fsearchAlias.split('|');
				var options = '';
				for(var i=0;i<fsearch.length;i++)
				{
					options += '<option value="' + fsearch[i] +  '">' + fsearchAlias[i] + '</option>';
				}
				$('#fsearch').html(options);
				$('#pop #where #condition').show(); 
			}
			if(!(j.fields.empty()))
			{
				var fields = j.fields.split('|');
				var alias = j.alias.split('|');
				var label = '';
				for(var j=0;j<fields.length;j++)
				{
					
				}
				
			}


			if(j.status == '1')
			{
				layerIndex = layer.open({
					type: 1,
					area:['600px','520px'],
					title:'组全条件和字段对话框',
					content: $('#pop')
				});
			}
		});
	});
	
	$('#ensure').click(function(){
		layer.close(layerIndex);
	});

});