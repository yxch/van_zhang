<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
	
	$back = ['status'=>0,'tip'=>'','type'=>'error','thead'=>'','tbody'=>'','total'=>0,'titles'=>0];
	
	if(!isset($_POST['filter']) || !ctype_digit($_POST['filter']))
	{
		$back['tip'] = '没有提供可用的数据过滤器标识符！';
		points::jan($back);
	}

	if(!isset($_POST['page']) || !ctype_digit($_POST['page']))
	{
		$back['tip'] = '提供了一个无法识别的当前页标识符';
		points::jan($back);
	}

	//由过滤器id查询过滤器信息
	$filter = DBC::selected(SQL::GetFilterFromPointsFiltersById,[':id'=>$_POST['filter']],['one'=>TRUE]); 
	if(count($filter) == 0)
	{
		$back['tip'] = '异常的请求';
		points::jan($back);
	}
	$field = json_decode($filter['fields'],true);
	$fieldAlias = array_combine($field['fields'],$field['alias']); //字段与显示名的映射
	$statement = json_decode($filter['statement'],true); //计算总数及查询语句
	
	//用户选择的显示字段
	$_title = isset($_POST['fields']) && !empty($_POST['fields']) ? explode('|',$_POST['fields']) : $field['fields']; 
	//确认字段是否是有效的及显示表格标题
	$titles = []; $alias = [];
	for($k=0,$l=count($_title);$k<$l;$k++)
	{
		if(!in_array($_title[$k],$field['fields']))
		{
			$back['tip'] = '异常的请求';
			points::jan($back);
		}
		$titles[] = $_title[$k];
		$alias[] = $fieldAlias[$_title[$k]];
		$back['thead'] .= '<td title="' . $fieldAlias[$_title[$k]] . '">' . $fieldAlias[$_title[$k]] . '</td>';
	}
	$back['titles'] = count($titles);

	//选项内容
	if(isset($_POST['opt']) && $_POST['opt'])
	{
		//是否显示序列选择选项
		$opt = ['section'=>0,'range'=>0,'fsearch'=>'','fsearchAlias'=>'','fields'=>'','alias'=>''];
		if(!empty($field['increment'])){ $opt['section'] = 1; }
		if(!empty($field['dated'])){ $opt['range'] = 1; }
		if(!empty($field['fsearch']))
		{ 
			$fsearchAlias = [];
			for($j=0,$fsearchLen=count($field['fsearch']);$j<$fsearchLen;$j++)
			{
				$fsearchAlias[] = $fieldAlias[$field['fsearch'][$j]];
			}
			$opt['fsearch'] = implode('|',$field['fsearch']);
			$opt['fsearchAlias'] = implode('|',$fsearchAlias);
		}
		$opt['fields'] = implode('|',$titles);
		$opt['alias'] = implode('|',$alias);
		$opt['status'] = 1;
		points::jan($opt);exit;
	}
	
	//为导出存储字段
	$_SESSION['points']['export']['fields'] = $titles;
	$_SESSION['points']['export']['alias'] = $alias;

	//组合条件或默认条件

	
	$totalize = strtr($statement['totalize'],[':WHERE'=>$statement['condition']]); //替换计算总数SQL的 :WHERE
	$selected = strtr($statement['statement'],[':WHERE'=>$statement['condition']]);//替换查询语句的 :WHERE
	$_SESSION['points']['export']['select'] = $selected; //为导出存储查询
	
	//执行查询是否有数据可用于显示
	$query = DBC::selected($totalize,[],['one'=>TRUE]); 
	$back['total'] = $query['total'];
	if($back['total'] == 0)
	{	
		$back['status'] = 1;
		points::jan($back);	
	}

	//执行查询 表格条目显示
	$slt = DBC::selected($selected,[]);

	$tbody = '';
	for($i=0,$length=count($slt);$i<$length;$i++)
	{
		$tbody .= '<tr>';
		for($j=0,$len=count($titles);$j<$len;$j++)
		{
			$tbody .= '<td title="' . $slt[$i][$titles[$j]] . '">' . $slt[$i][$titles[$j]] . '</td>';
		}
		$tbody .= '</tr>';
	}
	
	$back['status'] = 1;
	$back['tbody'] = $tbody;
	
	points::jan($back);