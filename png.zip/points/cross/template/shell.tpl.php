<!DOCTYPE html>
<html>
	<head>
	   <?php echo points::head(1,$page['head']);?>
	   <script type="text/javascript" src="/points/cross/local/js/shell.js"></script>
	</head>    
	<body>
		<div id="outset">
			<div id="left">
				<div id="logo">
					<div id="ico"><img src="<?php echo IMAGE; ?>logo.png" /></div>
					<label>招商信诺人寿保险有限公司 2016</label>
				</div>
				<div id="portraits">
					<span id="portrait"><img alt="我的头像" src="<?php echo IMAGE; ?>test.portrait.png" /></span>
					<span id="info">
						<p id="uname"><?php echo $page['username'];?></p>
						<p id="status"><?php echo $page['status'];?></p>
						<p><a id="settings">更改我的设置<img alt="设置" src="<?php echo IMAGE; ?>gear.png" /></a></p>
					</span>
				</div>
				<?php foreach($page['item'] as $k=>$arr){?>
				<div class="items">
					<a id="<?php echo $arr['id']; ?>" _href="<?php echo $arr['path']; ?>" class="categories"><?php echo $arr['title']; ?></a><label></label>
				</div>
				<?php } ?>
			</div>

			<div id="top">
				<div id="centered">
					<a id="dashboard" title="主菜单"></a>
					<a id="refresh" title="刷新"></a>
					<a id="grid" title="切换窗口"></a>
					<span id="search"><input type="text" id="searcher" /><a id="ico-search"></a></span>
					<span id="userinfo">
						<span id="user-portrait"><img alt="我的头像" src="<?php echo IMAGE; ?>test.portrait.png" /></span>
						<a id="user-status"><?php echo $page['status'];?></a>
					</span>
					<span id="screen">
						<a id="lock">锁屏</a>
						<a id="logout" href="/points/usr/login/ask/loginout.inc.php">注销</a>
						<span id="applied"><?php echo $page['group']; ?></span>
					</span>
				</div>
			</div>
		   <iframe id="viewer" name="viewer" src="<?php echo $page['iframe']; ?>"></iframe>
		</div>
		<div id="overlay"></div>
		<div id="err">
			<p><img width="30" height="30" id="err-ico" title="错误" src="" /><span id="message"></span></p>
			<p><a id="hide-err">关闭</a></p>
		</div>
		<div id="foot"><?php echo points::foot();?></div>
	</body>
</html>