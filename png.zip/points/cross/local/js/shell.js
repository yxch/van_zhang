$(document).ready(function(){
   
    //重置节点的高度
    resize();
    //默认显示
    $('.items').each(function(i,obj){
        if(i == 0){ $(obj).children('label').css('background','green'); }
    });
    
    //更改我的设置
    $('#settings,#user-status').click(function(){
        document.getElementById('viewer').src = '/points/usr/login/settings.php';
        $('.items a').siblings('label').css('background','');
    });
    
    $('.items a').click(function(){
        var id = $(this).attr('id');
        var href = $(this).attr('_href');
        var _this = $(this);
        
        $.post('/points/cross/navigation.ajx.php',{"item":id},function(r){  /*console.log(r);return;*/
            if (r == 1)
            {
                document.getElementById('viewer').src =  href;
                _this.siblings('label').css('background','green');
                _this.parent().siblings().children('label').css('background','transparent');
            }        
        });
    });
    
    //刷新按钮
    $('#refresh').click(function(){
        var src = $('#viewer').attr('src').split('?')[0];
        document.getElementById('viewer').src = src + '?ver=' + Math.random();  
    });
    
    //切换窗口
    $('#grid').click(function(){
        if ($(this).hasClass('full'))
        {
            $(this).removeClass('full');
            $('#left').show();
            $('#top').css('width','80%');
            $('#userinfo').hide();
            $('#viewer').css('width','80%');
        }else
        {
            $(this).addClass('full');
            $('#left').hide();
            $('#top').css('width','100%');
            $('#userinfo').show();
            $('#viewer').css('width','100%');
        }
    });
    
    //改变窗口时重置节点的高度
    $(window).resize(function(){ resize(); });
    
    function resize()
    {
        var _H = $(window).height(); //alert(_H);
		var _W = $(window).width();
        $('#outset').css('height',(_H - 50 - 4) + 'px');
        $('#left').css('height',(_H - 50 - 4) + 'px');
        $('#viewer').css('height',(_H - 50 - 62 - 4) + 'px');
		
		var _h = $(document).scrollTop();
		var _w = $(document).scrollLeft(); 
		//遮罩层的大小
		$('#overlay').css({"width": (_W + _w) + 'px',"height": (_H + _h) + 'px'});
    }

	$(window).scroll(function(){
		var h = $(window).height() + $(document).scrollTop() + 'px';
		var w = $(window).width() + $(document).scrollLeft() + 'px'; 
		//遮罩层的大小
		$('#overlay').css({"width":w,"height":h});
	});

});