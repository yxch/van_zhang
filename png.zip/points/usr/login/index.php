<?php
	require $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
	//当前可用的注册区域信息
	$subrange = DBC::selected(SQL::GetRegionsFromPointsRegions,[]);
	$subrangeLen = count($subrange);
	$arr = array();
	for($i=0;$i<$subrangeLen;$i++){ $arr[$subrange[$i]['region']][$subrange[$i]['id']] = $subrange[$i]['name']; }
	//用户数据option 选项
	$optionsData = '';
	if(isset($arr[1])){ foreach($arr[1] as $range=>$name){ $optionsData .= "<option value=\"{$range}\">{$name}</option>"; } }
	//控制台option 选项 在未初始化任何条目之前只能由超级用户来登录 此时控制台将必须有一个条目出现
	$optionsMaster = '';
	if(isset($arr[2]))
	{
		foreach($arr[2] as $range=>$name){ $optionsMaster .= "<option value=\"{$range}\">{$name}</option>"; }
	}else{ $optionsMaster .= '<option value="0">设置中心</option>'; }
	//定制option选项
	$optionCustom = '';
	if(isset($arr[3])){	foreach($arr[3] as $range=>$name){ $optionsCustom .= "<option value=\"{$range}\">{$name}</option>"; }}
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<?php echo points::head(false,array('title'=>'用户登录'));?>
		<link rel="stylesheet" href="css/login.css" />
		<link rel="stylesheet" href="/points/cross/local/css/foot.css" />
		<script type="text/javascript" src="js/login.js"></script>
</head>
<body>
	<div id="main">
		<div id="merchant">
			<img id="logo" src="/points/cross/local/image/logo.png" />
			<span id="title">用　户　登　录</span>
		</div>
		 <div id="item">
			<a class="used" id="data" _region="1">用 户 数 据</a>
			<a id="master" _region="2">控　制　台</a>
			<a id="custom" _region="3">定　　制</a>
		</div>
		<div  id="a-data" style="display:block;">
			<label>选择组类型:</label>
			<select class="subrange"><?php echo $optionsData; ?></select>
		</div>
		<div id="a-master">
			<label>选择组类型:</label>
			<select><?php echo $optionsMaster; ?></select>
		</div>
		 <div id="a-custom">
			<label>选择组类型:</label>
			<select><?php echo $optionCustom; ?></select>
		</div> 
		<div id="login">
			<div id="rows-username">
				<label>用　户　名：</label>
				<input type="text" id="username" name="username" value="<?php if(TEST){ echo 'pointer'; } ?>" placeholder="用户名"  />
			</div>
			<div id="rows-password">
				<label>密　　　码：</label>
				<input type="password" id="password" value="<?php if(TEST){ echo 'Aa123456'; } ?>" placeholder="输入您的密码" />
			</div>
			<div id="vce">
				<p>
					<label>验　证　码：</label>
					<input type="text" maxlength="4" id="valide" placeholder="输入下方验证码" />
				</p>
				<p id="imgvce"><img id="img-vce" src="/points/usr/login/ask/vce.inc.php" style="vertical-align: middle;"/></p>
			</div>
			<div id="tip"></div>
			<div id="butt"><input type="button" id="logined" value="登　录" /></div>
		</div>
		<div id="desc">
			<p>
				<span id="copyright">Copyright © 2016 招商信诺人寿保险有限公司. All Rights Reserved. 粤ICP备11053445号-2</span>
			</p>
		</div>
	</div>
</body>
</html>