<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/points/loader.inc.php';
    $back = array('status'=>0,'message'=>'','url'=>''); //响应的结果集
    
    //验证码是否正确
    if(strtolower($_POST['valide']) != $_SESSION['points']['VCE'])
    {
        $back['message'] = '检查验证码,输入的验证码可能有误';
        points::jan($back);
    }
    //检查区域id
    if(!ctype_digit($_POST['region']))
    {
        $back['message'] = '异常访问，区域ID不正确';
        points::jan($back);
    }
    $relations = array('1'=>'用户数据','2'=>'控制台','3'=>'定制');
    
    //缓存region
    $_SESSION['points']['region'] = array();
    $_SESSION['points']['region']['id'] = $_POST['region'];
    $_SESSION['points']['region']['name'] = $relations[$_POST['region']];
    
    //检查范围id
    if(!ctype_digit($_POST['subrange']))
    {
        $back['message'] = '异常访问，子区域ID不正确';
        points::jan($back);
    }
    if($_POST['subrange'] != '0') //超级用户的初始化操作被排除在外
    {
		$regions = DBC::selected(SQL::GetRegionsFromPointsRegionsById,[':id'=>$_POST['subrange']]);
        if(count($regions) == 0)
        {
            $back['message'] = '区域不可用，可能被管理员废弃。';
            points::jan($back);
        }
        //缓存子区域信息
        $_SESSION['points']['subrange']['name'] = $regions[0]['name'];
        $_SESSION['points']['subrange']['directory'] = $regions[0]['directory'];
    }
    
    $username = trim($_POST['username']); 
    if(empty($username)){ $back['message'] = '用户名不能为空'; points::jan($back); }
    
    $password = trim($_POST['password']);
    if(empty($password)){ $back['message'] = '密码不能为空'; points::jan($back); }
    $password = md5($password);
    
    //是否存在此用户
	$users = DBC::selected(SQL::GetUsersFromPointsUserByUsername,[':username'=>$username]); 
    if(count($users) == 1) //用户存在
    {
        if($users[0]['type'] == 1){ $back['message'] = '不允许此类用户在此处登录'; points::jan($back); }
        if($users[0]['status'] != '1'){ $back['message'] = '用户已被锁定'; points::jan($back); }        
        if($password != $users[0]['password']){$back['message'] = '不正确的用户名或者密码'; points::jan($back); }
        
        $_SESSION['points']['user']['username'] = $username;
        $_SESSION['points']['user']['id'] = $users[0]['id'];
        $_SESSION['points']['user']['alias'] = $users[0]['alias'];
        $_SESSION['points']['user']['type'] = $users[0]['type'];
        
        //查找所有此子区域的类别条目
		$categories = DBC::selected(SQL::GetCategoriesFromPointsCategoryByRegionId,[':regionId'=>$_POST['subrange']]);
		$categoriesLen = count($categories);
        if($categoriesLen == 0)
        {
            $back['message'] = '在此区域下没有可访问的条目';
            points::jan($back);
        }
        $_arr = array(); $_categoriesId = [];
        for($k=0;$k<$categoriesLen;$k++)
        {
            $_arr[$categories[$k]['id']]['title'] = $categories[$k]['title'];
            $_arr[$categories[$k]['id']]['tid'] = $categories[$k]['templateId'];
            $_arr[$categories[$k]['id']]['MD5'] = $categories[$k]['MD5'];
			$_categoriesId[] = $categories[$k]['id']; //所有类别id的集合
        }
        //缓存类别的一些信息
        if($users[0]['type'] == 9) //超级用户
        {
            foreach($_arr as $k=>$v)
            {
                $_SESSION['points']['category'][$k]['title'] = $v['title'];
                $_SESSION['points']['category'][$k]['tid'] = $v['tid'];
                $_SESSION['points']['category'][$k]['MD5'] = $v['MD5'];
                $_SESSION['points']['category'][$k]['authority'] = MAXAUTH;
            }
        }else //不是超级用户
        {
            $uid = $users[0]['id'];
            //从用户权限列表中查出所有此uid的访问条目
			$powers = DBC::selected(SQL::GetPowerListFromPointsPowersByUID,[':uid'=>$uid]);
			$_auth = array(); $_powersCID = [];
			$powersLen = count($powers);
            for($j=0;$j<$powersLen;$j++)
            {
                $_auth[$powers[$j]['categoryId']]['authority'] = $powers[$j]['authority'];
				$_powersCID[] = $powers[$j]['categoryId'];
            }
            //求$powers['categoryId'] 与 $categories['id']交集
            $intersect = array_intersect($_powersCID,$_categoriesId);  
            if(count(array_values($intersect)) == 0)
            {
                $back['message'] = '在此区域范围内此用户没有任何可访问的类别条目';
                points::jan($back);
            }
            foreach($intersect as $k=>$v)
            {
                $_SESSION['points']['category'][$v]['title'] = $_arr[$v]['title'];
                $_SESSION['points']['category'][$v]['tid'] = $_arr[$v]['tid'];
                $_SESSION['points']['category'][$v]['MD5'] = $_arr[$v]['MD5'];
                $_SESSION['points']['category'][$v]['authority'] = $_auth[$v]['authority'];
            }      
        }
        $back['status'] = 1;
        $back['url'] = PHOST . $_SESSION['points']['subrange']['directory'];
        points::jan($back);
    }else //如果用户不存在
    {
        //是否是内置初始化用户
        $pointers = parse_ini_file(SYSINI . 'pointer.ini',true);
        if($username != $pointers['username'])
		{ 
			$back['message'] = '不正确的用户名或者密码'; points::jan($back); 
		}
        if($password != $pointers['password'])
		{ 
			$back['message'] = '不正确的用户名或者密码'; points::jan($back); 
		}
        
        $_SESSION['points']['user']['username'] = $pointers['username'];
        $_SESSION['points']['user']['id'] = 0;
        $_SESSION['points']['user']['alias'] = $pointers['alias'];
        $_SESSION['points']['user']['type'] = $pointers['type'];
		$_SESSION['points']['subrange']['name'] = '设置中心';
		$_SESSION['points']['subrange']['directory'] = $pointers['directory'];
        
        $back['status'] = 1;
        $back['url'] = PHOST . $pointers['directory'];
        points::jan($back);
    }