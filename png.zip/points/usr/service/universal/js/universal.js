
var posts = {"product":'100000',"page":1,"year":'',"month":''};
var cached = {}; //缓存
var pageTotal = 0; //页总数

var f = {};
f.grid = function()
{
    $.post('ask/universal.ajx.php',posts,function(r){  /*console.log(r);*/
        var j = $.parseJSON(r); 
        if(j.plaid)
        {
            pageTotal = j.pageTotal;
            posts.page = j.page;
            $('#plaid').html(j.plaid); 
            $('#loading').hide();
            
        }else{ $('#loading').show();  }        
    });
}

$(document).ready(function(){
    f.grid();
    
    var tip = $('#tip');
    //新增
    $('#add').click(function(){
        //一次只能新增一条记录，每个月一条记录
        if ($('.newly').length > 0) { tip.text('应用后再新增'); return;  }
        if ($('.modifying').length > 0) { tip.text('应用更改后再新增'); return; }
        tip.text('');
        posts.before = true;
        $.post('ask/universal.ajx.php',posts,function(r){
            var j = $.parseJSON(r);
            if (j.add){ $('#plaid').html(j.add); }
            if (j.append)
            {
                var tr0 = $('#plaid tbody').find('tr').get(0);
                $(tr0).before(j.append);
            }
            $(".newly").delegate(".time",'focus',function(){
                var date = new Date();
                if (!$('.time').val()){ $(this).val(date.getFullYear() + '-' + (parseInt(date.getMonth()) + 1)); }
            });
            posts.before = 0;
        });
    });
    
    //用户改变年份值
    document.getElementById('years').onchange=function(){   posts.year = this.value;  f.grid(); }
    
    //用户改变月份值
    document.getElementById('months').onchange=function(){  posts.month = this.value; f.grid(); }
    
    var tip = $('#tip'); //提示对象    
    var init = {};
    
    //编辑事件
    $('#grids').delegate('tbody .edit','click',function(){
        if ($('.newly').length > 0) { tip.text('应用新增后再编辑');return; }
        tip.text('');
        var parent = $(this).parent().parent();
        var child = parent.children('td');
        if(parent.hasClass('modifying')){ return; } //重复单击时返回
        parent.addClass('modifying');    //正在修改的行
        var date = '';
        child.each(function(i,n){
            var index = parseInt(i);
            var td = $(n);
            if(index == 0){ date = td.text();};
            if (index > 0 && index < child.length - 1)
            {               
                var v = parseInt(td.text()) >= 0 ? td.text() : '';
                var dataId = td.attr('data_id');
                var key = date + '-' + dataId; 
                if (typeof(init[key] != 'undefined')) { init[key] = v;  }
                td.text('');
                var input = '<input class="modified" value="' + v + '" />';
                td.append(input);
            }        
        });
    });
    //应用事件
    $('#grids').delegate('#apply', 'click',function(){ 
        var mod = [];
        if ($('.modifying').length > 0) //修改
        {   
            $('.modifying').each(function(i,n){
                var tr = $(n);
                var children = tr.children('td');            
                var date = '';
                children.each(function(j,name){                
                    var o = $(name);
                    var index = parseInt(j);
                    
                    if (index == 0) { date = o.text();}
                    if (index >= 1 && o.attr('data_id'))
                    {
                        var v = o.children('input').val();
                        var key = date + '-' + o.attr('data_id');
                        //是否修改了值
                        if (init[key] != v){  mod.push(date + ':' + o.attr('data_id') + '-' + v); }
                    }
                });          
            });
        }
        if ($('.newly').length > 0) //新增
        { 
            $('.newly').each(function(i,n){
                var tr = $(n);
                var children = tr.children('td');       
                var date = '';
                children.each(function(j,name){                
                    var o = $(name);
                    var index = parseInt(j);
                    if (index == 0) 
                    {
                        var _date = o.children('input').val();
                        if (_date){ date = _date; }
                    }
                    if (index >= 1 && o.attr('data_id'))
                    {
                        var v = o.children('input').val();
                        if(v){  mod.push(date + ':' + o.attr('data_id') + '-' + v); }
                    }
                });          
            });
        }
        if (mod.length > 0)
        {     
            $.post('ask/universal.edit.ajx.php',{"pdata":mod.join('|')},function(r){ /*console.log(r);*/
                var j = $.parseJSON(r);
                if(j.status)
                {
                    tip.text('');
                    f.grid();   
                }else{ tip.text(j.message); }
            });
        }else{ tip.text('没有可用于提交的内容'); }
    });
    
    $('#grids').delegate('tbody .del','click',function(){
        var child = $(this).parent().parent().children();
        var del = [];        
        child.each(function(i,n){
            var o = $(n);
            if (parseInt(i) < child.length - 1)
            {
                var text = o.attr('data_id') ? o.attr('data_id') + '-' + o.text() : o.text();
                del.push(text);
            }
        });
        $.post('ask/universal.del.ajx.php',{"data":del.join(',',del)},function(r){ 
            var j = $.parseJSON(r);
            if (j.status){  tip.text(j.message); f.grid(); }else{ tip.text(j.message);}
        });
    });
    
    //用户点击首页 上一页 下一页 尾页
    $('#grids').delegate('#fpage .first,#fpage .next,#fpage .last,#fpage .end').click(function(){
        var id = $(this).attr('id'); 
        var total = parseInt(pageTotal);
        var i = parseInt(posts.page);
        
        posts.year = $('#years').val();
        posts.month = $('#months').val();
        
        switch(id)
        {
            case 'first': //首页
                if (i != 1){ posts.page = 1; f.grid();;	/**更新表显示内容 这个函数在wnxljll.js中定义	*/ }
                break;
            case 'previous': //上一页
                if (i > 1 && i - 1 >= 1){  posts.page = i - 1; f.grid(); }
                break;
            case 'next': //下一页
                if(i <= total && i + 1 <= total){  posts.page = i + 1; f.grid(); }
                break;
            case 'end': //尾页
                if (i != total){  posts.page = total; f.grid(); }
                break;
        }    
    });
    //单击每一页
    $('#grids').delegate('#fpage .page','click',function(){
        posts.page = $(this).attr('id').split('-')[1];
        f.grid();    
    });  
});
