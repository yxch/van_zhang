<?php
    require $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    
    $pdata = $_POST['pdata'];
    $arr = explode('|',$pdata);
    
    $updates = array();
    //校验数据并准备填充更新的数组$updates 多维数组
    for($i=0,$l=count($arr);$i<$l;$i++)
    {
        $explodes = explode(':',$arr[$i]);
        $_date = explode('-',$explodes[0]);
        if($_date[0] < 1900 || $_date[0] > 2999){ echo points::jen(0,'年份可能输入错误');exit;}
        if($_date[1] <1 || $_date[1] > 12){ echo points::jen(0,'月份可能输入错误');exit; }
        if($_date[1] < 10){ $explodes[0] = $_date[0] . '-0' . (int)$_date[1]; } //格式化用户输入
        
        $prices = explode('-',$explodes[1]);
        $updates[$i]['where']['settleTime'] = $explodes[0];
        if(!ctype_digit($prices[0])){ echo points::jen(0,'提供了无效的账号ID');exit; }
        
        $updates[$i]['where']['accountId'] = $prices[0];
        
        if(!is_numeric($prices[1])){ echo points::jen(0,'价格或价值只接受数值，请保留相应小数位数');exit; }
        $updates[$i]['value']['price'] = $prices[1];       
    }
  
    $i = 0;
    //循环更新表内容 ??
    for($k=0,$len=count($updates);$k<$len;$k++)
    {
        $price = new prices($updates[$k]['where']);
        if($price->iTotal() > 0) //存在记录更新否则新增
        {
            if(!points::allowed($auth,'edit')){ echo points::jen(0,'用户权限请求');exit; }
            
            $updates[$k]['value']['modifiedTime'] = date('Y-m-d H:i:s');
            $updated = $price->set($updates[$k]['value']);
        }else
        {
            if($updates[$k]['value']['price']) //用户提供了值才插入新记录
            {
                if(!points::allowed($auth,'add')){ echo points::jen(0,'用户权限请求');exit; }
                
                $insert = new prices();
                $inserted = $insert->set(array_merge($updates[$k]['where'],$updates[$k]['value']));
            }
        }
        if((isset($updated) && $updated) || (isset($inserted) && $inserted)){ $i++; }
    }
    echo points::jen($i,'成功更新了' . $i .'个记录');
