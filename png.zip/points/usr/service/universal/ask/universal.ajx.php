<?php
    require $_SERVER['DOCUMENT_ROOT']  . '/points/loader.inc.php';
    $auth = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
       
    //产品到账户的映射
    $products = array('100000'=>points::accounts() );
    //校验产品编号
    if(!isset($products[$_POST['product']])){  exit; /**产品编号异常，可能不是正常访问*/ }
    $acc = $products[$_POST['product']]; 
   
    $page = $_POST['page']; //第几页 当前页
    //校验一下$page 必须为一个整数
    if(!ctype_digit($page)){ exit; /**异常的参数传入*/ }
    //返回的json_encode数组
    $collect = array('page'=>$page,'pageTotal'=>0,'plaid'=>'','fpage'=>'');
    
    //利率结算时间
    $year = $_POST['year'];
    $month = $_POST['month'];
    //验证时间值
    if(!empty($year))
    {
        if(!ctype_digit($year) || $year < 1900 || $year > 2999){ points::jan($collect); }
    }
    if(!empty($month))
    {
        if(!ctype_digit($month) || $month < 1 || $month > 12 ){ points::jan($collect); }
    }

    //生成确保账户状态为1的查询条件
    $keys = array_keys($acc);
    for($i=0,$l=count($keys);$i<$l;$i++){ $keys[$i] = "account = '" . $keys[$i] . "'"; }
    //确保账户状态为1才执行单位价格查询
    $accounts = new account('(' . implode(' OR ',$keys) . ')' . ' AND status = 1');
    $accountArr = $accounts->get(array('id','account'));
  
    //table标题
    $header = '<thead><tr><td class="left-border">结算时间</td>';
    $empty = '<div id="empty">没有可用数据!</div>';
    
    //标题添加账户信息
    if($accounts->iTotal() > 0)
    {
        for($i=0;$i<$accounts->iTotal();$i++){   $header .= '<td>' . $acc[$accountArr['account'][$i]] . '</td>'; }
        $header .= '<td>操作</td></tr></thead>';
        
    //查询账户的status都为0即都不可用
    }else{ $collect['plaid'] = $empty;  points::jan($collect);  }
    
    //用户允许的操作
    $opers = array();
    if($auth[1] == '1'){ $opers[] = '<a class="edit">编辑</a>';}
    if($auth[2] == '1'){ $opers[] = '<a class="del">删除</a>';}
    $oper = implode('<label style="margin-left:2px;margin-right:2px">|</label>',$opers);
    
    //获取表数据
    $pageSize = 15; //分页大小
    //查询条件
    $ids = implode(',',$accountArr['id']);
    $where = "accountId IN($ids) "; //注意有一个空白
    
    //如果结算月份为空则显示当前月份结算价值
    if(empty($year) && empty($month)){ $where .= ''; }
    if(!empty($year) && empty($month)){  $where .= 'AND substring(settleTime,1,4)=' . $year; }
    if(!empty($year) && !empty($month))
    {
        $_time = $year . '-' . $month;
        $where .= "AND substring(settleTime,1,7)='{$_time}'";
    }
    if(empty($year) && !empty($month)){  $where .= 'AND substring(settleTime,6,2)=' . $month; }
    
    //查出全部日期并排序分组
    $price = new prices($where);
    $dates = $price->get(array('settleTime'));
    $settles = array_unique($dates['settleTime']); 
    rsort($settles);
    $chunk = array_chunk($settles,$pageSize);
    $pageTotal = count($chunk); //总页数
    $collect['pageTotal'] = $pageTotal;
    
    //如果用户请求增加价值记录
    if(isset($_POST['before']) && $_POST['before'])
    {
        $add = array('append'=>'','add'=>'');
        $row = '<tr class="newly"><td class="left-border"><input class="modified time" value="" /></td>';
        for($i=0;$i<$accounts->iTotal();$i++){ $row .= '<td data_id="' .$accountArr['id'][$i] .'"><input class="modified" value="" /></td>'; }
        $row .= '<td>&nbsp;</td></tr>';
        if($price->iTotal() > 0)
        {            
            $add['append'] = $row; points::jan($add);
        }else
        {
            $add['add'] = $header . '<tbody>' . $row . '</tbody>';
            //分页
            $cols = $accounts->iTotal() + 2;
            $tfoot = '</tbody><tfoot><tr><td colspan="' . $cols . '">';
            if($auth[1] == '1' || $auth[3] == '1'){ $tfoot .= '<a id="apply">应用</a>'; }
            $tfoot .= '</td></tr></tfoot>';
            $add['add'] .= $tfoot;
            points::jan($add);
        }
    }
    
    //指定的当前页
    if(!isset($chunk[$page-1])){ $collect['plaid'] = $empty;  points::jan($collect); }
    $or = '';
    for($k=0,$l=count($chunk[$page-1]);$k<$l;$k++)
    {
        if($k == $l-1){ $or .= "substring(settleTime,1,7)='{$chunk[$page-1][$k]}'";
        }else{          $or .= "substring(settleTime,1,7)='{$chunk[$page-1][$k]}'". ' OR ';}
    }
    $where .= ' AND (' . $or . ')';
    
    $prices = new prices($where,array('order'=>'settleTime DESC'));
    $pricesArr = $prices->get(array('accountId','price','settleTime'));
    
    //分组
    $ar = array();
    for($j=0;$j<$prices->iTotal();$j++)
    {
        $ar[$pricesArr['settleTime'][$j]][$pricesArr['accountId'][$j]] = $pricesArr['price'][$j];
    }
    
    //分页显示
    $fpage = points::fpage($pageTotal,$_POST['page'],$pageSize);
    $fpages = empty($fpage) ? '&nbsp' : $fpage;
    
    if(count($ar) > 0)
    {
        $rows = '<tbody>';
        foreach($ar as $k=>$v)
        {
            $rows .= '<tr><td class="left-border">' . $k . '</td>';
            for($k=0;$k<$accounts->iTotal();$k++)
            {
                $rows .= isset($v[$accountArr['id'][$k]]) ?  '<td data_id="' . $accountArr['id'][$k] .  '">' . $v[$accountArr['id'][$k]] . '</td>' : '<td data_id="' . $accountArr['id'][$k] .  '">' . '－</td>';
            }
            $rows .= '<td>' . $oper . '</td>';
            $rows .= '</tr>';
        }
        $rows .= '</tbody>';
        //分页
        $tfoot = '<tfoot><tr><td colspan="' . ($accounts->iTotal() + 2) . '">';
      
        $tfoot .= '<span id="operations"></span>';
        $tfoot .= '<span id="fpage">'. $fpages . '<a id="apply">应用</a></span>';
        $tfoot .= '<span id="counts">总记录数:'. count($settles) . '</span>';
        $tfoot .= '</tr></tfoot>';
        
        $collect['plaid'] = $header . $rows . $tfoot;
        points::jan($collect);
        
    }else{ $collect['plaid'] = $empty; points::jan($collect); }
