<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    
    //账户代号到中文标题的映射集
    $accounts = array('xianFeng'=>'先锋A型账户',
                      'heXie'=>'和谐A型账户',
                      'tianLi'=>'添利A型账户',
                      'huoBi'=>'货币A型账户',
                      'lingDong'=>'灵动A型账户',
                      'ruiQu'=>'锐取A型账户',
                      'chengZhang'=>'成长型账户'       );
    
    //产品到账户的映射
    $products = array('100009'=>array('ruiQu','huoBi'),
                      '100008'=>array('ruiQu','tianLi','huoBi','lingDong'),
                      '100007'=>array('xianFeng','lingDong','huoBi'),
                      '100006'=>array('xianFeng','ruiQu','huoBi'),
                      '100005'=>array('xianFeng','tianLi'),
                      '100004'=>array('xianFeng','heXie','tianLi','huoBi'),
                      '100003'=>array('xianFeng','heXie','tianLi','huoBi'),
                      '100002'=>array('xianFeng','heXie','tianLi','huoBi','chengZhang'),
                      '100001'=>array('xianFeng','heXie','tianLi','huoBi')                      );
    //校验产品编号
    if(!isset($products[$_POST['product']])){  exit; /**产品编号异常，可能不是正常访问*/ }    
    //table标题
    $html = '<tr><th class="n-head" width="20%"><span class="unit">单位/元</span><span class="time">评估时间</span></th>';
    //形成标题账户信息
    $acc = $products[$_POST['product']];    $len = count($acc);
    $fields = array('postTime'); //必须查询的时间字段
    for($i=0;$i<$len;$i++)
    {
        $html .= '<th class="t-head">' . $accounts[$acc[$i]] . '<i class="icon icon-table-arrow"></i></th>';
        $fields[] = $acc[$i]; //压入要查询的账户
    }
    $html .= '</tr>';    
    $empty = '<div style="width:100%;height:120px;line-height:120px;text-align:center;font-size:20px;font-style:italic;color:#E5E5E5;border:1px solid #E5E5E5;">没有可用数据</div>'; //当查询为空时显示
    
    //开始时间和结束时间
    $stime = $_POST['stime'];
    $etime = $_POST['etime'];
    //验证时间值 
    if(strlen($stime) > 10 || strlen($etime) > 10){ exit; /** 输入的时间值不是2015-10-19的格式，长度过长可能有SQL注入的危险*/}
    
    $where = '';
    if(empty($stime) && empty($etime)) { $where .= ''; }//查询全部
    if(!empty($stime) && !empty($etime)){ $where .= "postTime >= '{$stime}' AND postTime <= '{$etime}'"; } //查询时间段内
    if(empty($stime) && !empty($etime)){ $where .= "postTime <= '{$etime}'"; } //只有结束时间
    if(!empty($stime) && empty($etime)){ $where .= "postTime >= '{$stime}'";} //只有开始时间
    
    $page = $_POST['page']; //第几页
    //校验一下$page 必须为一个整数
    if(!ctype_digit($page)){ exit; /**异常的参数传入*/}
 
    $pageSize = 10; //分页大小
    $limit = $pageSize . ' OFFSET ' . ($page-1) * $pageSize;
    
    //获取表数据
    $service = new service($where,array('order'=>'postTime DESC','limit'=>$limit));
    $services = $service->get($fields);  //echo json_encode($services);exit;    
    $pageTotal = ceil($service->rows() / $pageSize); //计算页数    
    //返回的json_encode数组
    $collections = array('page'=>$page,'pageTotal'=>$pageTotal,'fpage'=>'');
    
    //表内容
    if($service->iTotal() > 0)
    {
        for($i=0;$i<$service->iTotal();$i++)
        {
            $html .= '<tr><td>';
            $html .= $services['postTime'][$i];
            $html .= '</td>'; 
            for($k=0;$k<$len;$k++){ $html .= '<td>' . $services[$acc[$k]][$i] . '</td>';  }
            $html .= '</tr>';
        }
        //更新分页信息
        $collections['fpage'] = '<a href="javascript:void(0)" id="first">首页</a><a href="javascript:void(0)" id="previous">上一页</a><a href="javascript:void(0)" id="next">下一页</a><a href="javascript:void(0)" id="end">尾页</a><span>共' . $service->rows() . '条</span><span>共' . $pageTotal . '页</span><span>每页' . $pageSize .'条</span><script type="text/javascript" src="/sites/default/themes/cigna_cmc/service/js/ajx.tlxdwjgcx.js"></script>';
        //将账户名和当前页与$html组成数组一个关联单元
        $collections[$_POST['product'] . $stime . $etime . $page] = $html;        
        echo json_encode($collections); exit;
        
    }else //没有内容
    {
        $collections['page'] = 1;
        $collections['pageTotal'] = 0;
        $collections['fpage'] = '';
        $collections[$_POST['product'] . $stime . $etime . $page] = $empty;
        echo json_encode($collections); exit;
    }  
