$(document).ready(function(){
    
    //保存初始值    
    var set = {};
    
    var settings = $('.settings');
    settings.each(function(i,obj){
        var object = $(obj);
        set[object.attr('id')] =  $.trim(object.val());
    });
    
    //input输入框的得到焦点事件
    settings.focus(function(){ $(this).siblings('.err').text('');  });
    
    //input输入框键盘事件 按回车即提交
    settings.keyup(function(event){
        if (event.which == 13){ $(this).siblings('.set').trigger('click',_submit); }    
    });
    
    //更改设置提交事件
    $('.set').bind('click',_submit);
    function _submit()
    {
        var id = $(this).attr('id');
        var put = id.split('-')[1]; 
        var puts = $.trim($('#PUT-' + put).val());
        if (set['PUT-' + put] == puts)
        {
            $('#err-' + put ).text('没有可用于提交的内容，请检查输入');
            return false;
        }
        $('#err-' + put ).text('');
        $.post('ask/backer.ajx.php',{"serial":put,"val":puts},function(r){ console.log(r);
            var j = $.parseJSON(r);
            $('#err-' + put ).text(j.tip);
            if (j.yes == 1)
            {
                set['PUT-' + put] = puts;
                setTimeout(function(){ $('#err-' + put ).text(''); },5000);
            }
        });    
    }
});