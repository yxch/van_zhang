<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';
    require_once ACCESSIBLED; //确认当前页面是否可正常访问
    
    $title = $_SESSION['points']['subrange']['name'] . ' ' . $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['title'];
    
    $filter = new filter(array('categoryId'=>$_SESSION['points']['item']['id'],'status'=>1));
    $filters = $filter->get(array('id','name'));
    $options = '';
    for($i=0;$i<$filter->iTotal();$i++)
    {
        $options .= '<option value="' . $filters['id'][$i] . '">' . $filters['name'][$i] . '</option>';
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <?php echo points::head(0); ?>
        <link rel="stylesheet" href="css/banker.css" />
        <script src="/points/usr/local/js/f.js"></script>
        <script src="/points/usr/local/js/paging.js"></script>
        <script src="js/banker.js"></script>
    </head>
    <body>
        <div id="outset">
            <div id="topic">
                <h1><?php echo $title; ?></h1>
                <span id="sp-filters">
                    <select id="filters"><?php echo $options;?></select>
                </span>
            </div>
            <table id="grid">
                <thead></thead>
                <tbody></tbody>
                <tfoot></tfoot>
            </table>
            <div id="none"><p>loading data！please wait......</p></div>
        </div>
        <div id="pop">
            <div id="close"><a id="closed"><img title="关闭" src="/points/usr/local/images/close.png" /></a></div>
            <div class="pop">
                <div id="banker">
                    <p><label><input class="export" type="radio" name="export" value="0" />导出　从 </label><input id="stime" value="" /> </p>
                    <p>　　　　到 <input id="etime" value="" /></p>
                    <p><label><input class="export" type="radio" name="export" value="1" />导出最新 </label><input id="rows" value="" /></p>
                    <p><label><input class="export" type="radio" name="export" value="2" />导出全部(不推荐)</label></p>
                    <p><label><input class="export" type="radio" name="export" value="3" />导出当前页</label></p>
                    <p id="tip"></p>
                </div>                
            </div>
            <div id="oper"><a id="ensure">确定</a></div>
        </div>
        <div id="overlay"></div>
    </body>
</html>
    