
$(document).ready(function(){
	var ask = 'ask/variable.ajx.php';
    grid(ask,{"page":1});

	//获取显示列表
	function grid(url,json)
    {
        $.post(url,json,function(r){   
            var j = $.parseJSON(r);  //返回的结果
            if (j.tbody)
            {
                $('#ul').html(j.tbody);
				pagings.page = j.page;
				$('#paging span').html(paging(j).show());
				pagings.empty = parseInt(j.total) == 0 ? true : false;
            }
        });
    }

	//增加变量
    $('#add').click(function(){
        window.location.href = 'variable.oper.php';
    });

	//编辑变量
	$('#edit').click(function(){
		var id = $('#' + pagings.id).find('.id').text();
		id ? window.location.href="variable.oper.php?vid=" + id : 	global.tip('没有可用于编辑的内容！');
	});

	//删除变量
	$('#delete').click(function(){
		if(pagings.empty)
		{
			global.tip('不能删除一个空的条目！','warning');
		}else
		{
			var ar = [],selects = [],id = '';
			for(var p in pagings.select){ ar.push(p); }
			if(ar.length > 0) //用户至少选择了一个要删除的条目
			{
				for(var i=0;i<ar.length;i++){ selects.push(ar[i].split('_')[1]); }
				id = selects.join('|');
			}else
			{
				if(pagings.id)
				{
					id = pagings.id.split('_')[1];
				}else
				{
					global.tip('请选择要删除的条目【在要删除的条目上单击即可】！','error');
					return FALSE;
				}
			}
			if(id.empty()){ global.tip('发生错误，没有任何内容被选择！','error'); return FALSE; }
			$.post('ask/variable.delete.ajx.php',{'id':id},function(r){ 
				var j = $.parseJSON(r);
				if(j.status == 0){		global.tip(j.err);
				}else{					global.tip(j.err,'success'); 	grid(ask,{"page":1});	}
			});
		}
	});

	//分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});

	//搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v,"page":1});}
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v,"page":1});
    });
});