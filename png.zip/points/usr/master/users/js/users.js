$(document).ready(function(){
	
    var ask = 'ask/users.ajx.php';
    grid(ask,{"page":1});
	
	//获取显示内容
	function grid(url,json)
    {
        $.post(url,json,function(r){ 
            var j = $.parseJSON(r);  //返回的结果
            if (j.tbody)
            {
                $('#ul').html(j.tbody);
				//取消事件冒泡
				$('#ul ul li span').click(function(e){ e.stopPropagation(); });
				pagings.page = j.page;
				$('#paging span').html(paging(j).show());
				pagings.empty = parseInt(j.total) == 0 ? true : false;
            }
        });
    }

	//修改内容
	$('#ul').delegate('li .revisable','mouseover',function(){
		var w = $(this).offset().left + $(this).width() + 10;
		var h = $(this).offset().top;
		$('#editable').css({"left":w,"top":h}).fadeIn(); //出现修改和保存按钮
		var id = $(this).closest('ul').attr('id') + '_' + $(this).attr('name');
		$(this).parent().attr('id',id); //为对应的li设置一个id
		$('#editable').attr('_id',id); //为编辑和保存的父标签设置id
	});
	
	//当鼠标移到编辑和保存按钮时显示
	$('#editable').mouseover(function(){ $(this).show(); });
	
	//编辑按钮的单击事件
	$('#editor').click(function(e){
		e.stopPropagation(); //阻止事件冒泡
		var id = $('#editable').attr('_id');
		//如果没有点击编辑按钮
		if($('#' + id + ' span').children('.in-revisable').length == 0)
		{
			var name = id.split('_')[2],html = '';
			if(name == 'type')
			{
				html = '<select id="type" class="in-revisable">';
				html += '<option value="1">普通用户</option>';
				html += '<option value="2">管理用户</option>';
				html += '<option value="3">全局用户</option>';
				html += '<option value="9">超级用户</option>';
				html += '</seclect>';
			}else if(name == 'status')
			{
				html = '<select id="status" class="in-revisable">';
				html += '<option value="1">启用的用户</option>';
				html += '<option value="0">锁定的用户</option>';
				html += '</seclect>';
			}else if(name == 'cipher')
			{
				html = '<label class="in-revisable"><input type="checkbox" id="cipher"  />重置密码为默认值</label>';
			}else{	html = '<input class="in-revisable"  />';}
			$('#' + id + ' span').append(html);
			$('.in-revisable').click(function(e){  e.stopPropagation();  });
		}
		//移除其它的正在编辑的内容
		$('#' + id).siblings('li').children('span').children('.in-revisable').remove();
		//移除其它父节点的.in-revisable元素
		$('#' + id).parent().siblings('ul').children('li').children('span').children('.in-revisable').remove();
		$(this).parent().hide(); //隐藏编辑和保存按钮的父元素
	});

	//保存新建内容
	$('#writer').click(function(){
		var id = $('#editable').attr('_id'); 
		var field = id.split('_')[2],v = '';
		if(field == 'type'){				v = $('#type').val();
		}else if(field == 'status'){		v = $('#status').val();
		}else if(field == 'cipher'){		v = $('#cipher').is(':checked') ? 1 : 0;
		}else{							v = $('#' + id).children('span').children('input').val();	 }
		if(v.empty())
		{ 
			global.tip('没有提供修改内容！','warning');  
			return false;
		}
		//提交数据
		$.post('ask/users.save.ajx.php',{"id":id,"val":v},function(r){  
			var j = $.parseJSON(r);
			global.tip(j.err,j.type);
			if(j.status == 1){	grid(ask,{"page":1});	}
		});
	});

	//新建用户
	$('#add').click(function(){
		var clone = $('.clone');
		if(clone.length >= 2){ return false; }
		$('#ul ul:nth-child(1)').before($('#clone ul').clone());		
		$('#oper').hide(); //隐藏操作窗口
	});

	//保存用户
	$('#ul').delegate('.clone .save','click',function(){ 
		var li = $(this).parent().parent().children('li').children('span');
		var posts = {};
		li.each(function(i,obj){ 
			var _this = $(obj).children();
			if(_this.hasClass('username')){ posts.username = _this.val();	}
			if(_this.hasClass('alias')){	posts.alias = $.trim(_this.val());	}
			if(_this.hasClass('type')){ posts.type = $.trim(_this.val());	}
			if(_this.hasClass('email')){ posts.email = $.trim(_this.val());	}
			if(_this.hasClass('portrait')){ posts.portrait = $.trim(_this.val());	}
		});
		if(posts.username.empty())
		{
			global.tip('必须指定用户名称！','warning');
			return false;
		}
		if(['1','2','3','9'].indexOf(posts.type) == -1)
		{
			global.tip('提供了错误的用户类型！','warning');
			return false;
		}
		
		$.post('ask/users.save.ajx.php',posts,function(r){
			var j = $.parseJSON(r);
			global.tip(j.err,j.type);
			if(j.status == 1){	grid(ask,{"page":1}); }
		});
	});

	//取消新建用户
	$('#ul').delegate('.clone .quit','click',function(){ 
		$(this).closest('ul').remove();	
	});
	
	//删除用户
	$('#delete').click(function(){
		if(pagings.empty)
		{
			global.tip('不能删除一个空的条目！','warning') ;
		}else
		{
			var ar = [], selects = [],id = '';
			for(var p in pagings.select){ ar.push(p); }
			if(ar.length > 0)
			{
				for(var i=0;i<ar.length;i++){ selects.push(ar[i].split('_')[1]); }
				id = selects.join('|');
			}else
			{ 
				if(pagings.id)
				{
					id = pagings.id.split('_')[1];
				}else
				{ 
					global.tip('请选择要删除的条目【在要删除的条目上单击即可】！','error') ;
					return false;
				}
			} 
			if(id.empty()){  global.tip('发生错误，没有任何内容被选择！'); return false; }
			$.post('ask/users.delete.ajx.php',{"id":id},function(r){ 
				var j = $.parseJSON(r);
				if(j.status == 0){		global.tip(j.err);
				}else{					global.tip(j.err,'success'); 	grid(ask,{"page":1});	}
			});
		}
	});

	//分页事件 首页 下一页 每一页 上一页 末页
    $('#paging').delegate('#first,#last,.page,#next,#end','click',function(){
        var num = $(this).attr('name');
        //$('#pager #fpage #goto').val(num);
        grid(ask,{"page":num});
    });
    //$('#pager #fpage').delegate('#goto','keyup',function(e){
    //    var v = parseInt($(this).val());
    //    if(e.which == 13){ if(!isNaN(v)){ grid(ask,{"page":v}); }  }
    //});
    
    //搜索功能
    $('#searcher',window.top.document).keyup(function(e){
        var v = $(this).val();
        if(e.which == 13){ grid(ask,{"searcher":v,"page":1}); }
    });
    $('#ico-search',window.top.document).click(function(){
        var v = $(this).parent().find('#searcher').val();
        grid(ask,{"searcher":v,"page":1});
    });
 
});
