<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限

	$back = ['status'=>0,'err'=>'','type'=>'error']; //请求的响应
	$details = [];
	if(isset($_POST['id']) && !empty($_POST['id'])) //修改内容
	{
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['err'] = '用户权限请求'; points::jan($back); }
		$_arr = explode('_',trim($_POST['id']));
		if(empty($_arr[2]) || !isset($_POST['val']) || !ctype_digit($_arr[1]))
		{
			$back['err'] = '异常的请求！'; 
			points::jan($back);
		}
		$_POST[$_arr[2]] = $_POST['val'];
		$details['mtime'] = date('Y-m-d H:i:s');
		
	}else{	$back['err'] = '异常的请求！'; 		points::jan($back); 	}
	
	if(isset($_POST['authority'])) //检查权限
	{
		$_POST['authority'] = '1' . $_POST['authority'] . '0'; //完善权限
		if(strlen($_POST['authority']) != 10)
		{
			$back['err'] = '异常的请求';
			points::jan($back);
		}
		for($i=0;$i<10;$i++)
		{ 
			if(!ctype_digit($_POST['authority'][$i]))
			{ 
				$back['err'] = '异常的请求';
				points::jan($back);
			} 
		}
		$details['auth'] = $_POST['authority'];
	}

	if(isset($_POST['yes'])) //检查区域状态值
	{
		if(!in_array($_POST['yes'],['0','1']))
		{
			$back['err'] = '提供了一个无效的区域状态值';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['yes'] = $_POST['yes'];
	}

	//更新记录
	$SQL = 'UPDATE ' . SQL::TblPowers . ' SET  ';
	$update = []; $str = '';
	foreach($details AS $k=>$v)
	{
		$str .= $k . '=' . ':' . $k . ',';
		$update[':' . $k] = $v;
	}
	$SQL .= trim($str,',') . ' WHERE id = :id';
	$update[':id'] = $_arr[1];
	$stmt = DBC::PDO()->prepare($SQL);
	if($stmt->execute($update))
	{
		$back['err'] = '修改成功，你可能需要刷新页面！';
		$back['type'] = 'success';
	}else{ $back['err'] = '修改失败，请检查输入是否有误！'; }
	points::jan($back);
	