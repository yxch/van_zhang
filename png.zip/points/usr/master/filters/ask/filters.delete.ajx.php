<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    //当前用户是否有修改条目的权限以防止恶意写入
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    if(!points::allowed($authority,'delete')){ echo points::jen(0,'用户权限请求'); exit;}
    
    if(empty($_POST['id'])){ echo points::jen(0,'没有条目选中，异常的请求！'); exit; }
    
    $exp = explode('|',$_POST['id']);
	for($i=0,$len=count($exp);$i<$len;$i++)
	{
		if(ctype_digit($exp[$i]))
		{
			$deletes[][':id'] = (int)$exp[$i];
		}else
		{
			echo points::jen(0,'包含了异常的请求！'); exit;
		}
	}
	$counts = count($exp);
	
	//删除条目
	$back = ['status'=>0,'err'=>'未知错误'];
	$result = DBC::modified(SQL::DelFiltersInPointsFiltersById,$deletes);
	if($result == $counts)
	{
		$back['status'] = 1;
		$back['err'] = '删除成功';
	}elseif($result < $counts)
	{
		$back['err'] = '一些条目删除失败';
	}else{ $back['err'] = '删除失败，请稍候重试!'; }

	points::jan($back);
