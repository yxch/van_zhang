<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php'; 
    $item = $_SESSION['points']['item']['id'];    
    
    //返回的数据
    $back = array('page'=>$_POST['page'],'total'=>0,'size'=>6,'tbody'=>'');
    
    //校验一下$page 必须为一个整数
    if(!ctype_digit($back['page'])){ exit; /**异常的参数传入*/ }
    
    //获取数据并处理分页显示
    if(isset($_POST['searcher']) && !empty($_POST['searcher'])) //用户搜索
    { 
        $search = trim($_POST['searcher']);  
		$count = DBC::selected(SQL::CountFiltersFromPointsFilterBySearch,[':name'=> '%' . $search . '%'],['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		if($back['total'] > 0)
		{
			$filters = DBC::selected(SQL::GetFilterFromPointsFiltersBySearch,
					   [':name'=> '%' . $search . '%',':size'=>$back['size'],':page'=>($back['page'] - 1) * $back['size']]);
		}
    }else
	{ 
		$count = DBC::selected(SQL::CountFiltersFromPointsFilter,[],['one'=>TRUE]);
		$back['total'] = (int)$count['total'];
		if($back['total'] > 0)
		{
			$filters = DBC::selected(SQL::GetFiltersFromPointsFilters,
				       [':size'=>$back['size'],':page'=>($back['page'] - 1) * $back['size']]);
		}
	}

	//字段显示映射集 $set的每个单元的第一个元素表示 表的别名 第二个元素表示显示的中文 第三个元素表示是否在初始化隐藏
	$set = [ ['id','表序列ID',0],['name','过滤器名称',0],['statement','过滤器查询语句',0],['cid','类别标识符',1],['fields','字段相关信息',1],
		     ['search','过滤器搜索选项',0],['factor','过滤器条件选项',1],['rest','预留选项',1],['status','当前状态',1],
		     ['mtime','修改时间',1],['ctime','创建时间',1]];
	
    //准备显示的内容
	if($back['total'] > 0)
	{
		$ul = '';
		for($i=0,$filtersLen=count($filters);$i<$filtersLen;$i++)
		{
			$ul .= '<ul id="ul_' .$filters[$i][$set[0][0]] . '" class="page-lists">';
			for($j=0,$len=count($set);$j<$len;$j++)
			{
				//是否隐藏并确定是否有title内容
				$ul .= $set[$j][2] ? ($j == 0 ? '<li class="hide" title="点击这里选择">' : '<li class="hide">')
					               : ($j == 0 ? '<li title="点击这里选择">' : '<li>');
				$ul .= '<i>' . $set[$j][1]. '</i>';
				$ul .= '<span class="' . $set[$j][0] .  '">' . $filters[$i][$set[$j][0]] . '</span>';
				$ul .= '</li>';
			}
			$ul .= '<li class="more"><a title="查看更多">. . .</a></li>';
			$ul .= '</ul>';
		}
	}else //没有可用于显示的内容
	{
		$ul = '<ul class="page-lists empty">';
		$ul .= '<li><i></i><span></span></li>';
		$ul .= '<li><i></i><span>没有可用于显示的内容</span></li>';
		$ul .= '</ul>';
	}
	$back['tbody'] = $ul;
	points::jan($back);
    
