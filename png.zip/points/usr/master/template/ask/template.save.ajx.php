<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/points/loader.inc.php';    
    
    $authority = $_SESSION['points']['category'][$_SESSION['points']['item']['id']]['authority'];   //获取权限
    $userType = $_SESSION['points']['user']['type'];

	$back = ['status'=>0,'err'=>'','type'=>'error']; //请求的响应
	$editor = false; $details = [];
	if(isset($_POST['id']) && !empty($_POST['id'])) //修改内容
	{
		$editor = true;
		//当前用户是否有修改条目的权限
        if(!points::allowed($authority,'edit')){ $back['err'] = '用户权限请求'; points::jan($back); }
		$_arr = explode('_',trim($_POST['id']));
		if(empty($_arr[2]) || !isset($_POST['val']) || !ctype_digit($_arr[1]))
		{
			$back['err'] = '异常的请求！'; 
			points::jan($back);
		}
		$_POST[$_arr[2]] = $_POST['val'];
		$details['mtime'] = date('Y-m-d H:i:s');
		
	}else //新增内容
	{
		//当前用户是否有新建条目的权限
        if(!points::allowed($authority,'add')){ $back['err'] = '用户权限请求'; points::jan($back); }
		//必须设置的一些值
		if(!isset($_POST['title'])){  $back['err'] = '必须提供模板标题'; points::jan($back);	}
		if(!isset($_POST['path'])){  $back['err'] = '必须提供模板路径'; points::jan($back);	}
	}
	
	if(isset($_POST['title'])) //检查用户名
	{
		if(empty($_POST['title']) || mb_strlen($_POST['title'],'UTF-8') > 16)
		{
			$back['err'] = '必须提供模板名称 且长度不超过16个字符！';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['title'] = trim($_POST['title']);
	}
	
	if(isset($_POST['path'])) // 检查显示名称
	{
		if(empty($_POST['path']))
		{
			$back['err'] = '必须指定正确的模板路径';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['path'] = trim($_POST['path']);
		$details['md5'] = md5(trim($_POST['path']));
	}
	
	if(isset($_POST['tag'])) //检查用户类型
	{
		if(!in_array($_POST['tag'],['1','0']))
		{
			$back['err'] = '提供了一个无效的模板标识符！';
			$back['type'] = 'warning';
			points::jan($back);
		}
		$details['tag'] = $_POST['tag'];
	}

	if(isset($_POST['layer']))
	{
		$details['layer'] = trim($_POST['layer']);
	}
	
	if($editor) //修改记录
	{
		if(isset($details['title'])) //确认没有别的重名的模板  md5相同且title相同
		{
			$exists = DBC::selected(SQL::GetCountFromPointsTemplateByIdTitleMd5,
					  [':title'=>$details['title'],':id'=>$_arr[1]],['one'=>TRUE]);
			if($exists['total'] > 0)
			{
				$back['err'] = '在指定的路径下存在相同的模板';
				points::jan($back);
			}
		}
		//更新记录
		$SQL = 'UPDATE ' . SQL::TblTemplate . ' SET  ';
		$update = []; $str = '';
		foreach($details AS $k=>$v)
		{
			$str .= $k . '=' . ':' . $k . ',';
			$update[':' . $k] = $v;
		}
		$SQL .= trim($str,',') . ' WHERE id = :id';
		$update[':id'] = $_arr[1];
		$stmt = DBC::PDO()->prepare($SQL);
		if($stmt->execute($update))
		{
			$back['err'] = '修改成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '修改失败，请检查输入是否有误！'; }
	
	}else //新建记录
	{
		$exists = DBC::selected(SQL::GetCountFromPointsTemplateByTitleMd5,
					  [':title'=>$details['title'],':md5'=>$details['md5']],['one'=>TRUE]);
		if($exists['total'] > 0)
		{
			$back['err'] = '在指定的路径下存在相同的模板';
			points::jan($back);
		}
		
		//新建模板
		$inserts = [];
		foreach($details AS $k=>$v){ $inserts[':' . $k] = $v;	}  
		if(DBC::modified(SQL::NewTemplateInPointsTemplate,$inserts))
		{
			$back['status'] = 1;
			$back['err'] = '注册模板成功，你可能需要刷新页面！';
			$back['type'] = 'success';
		}else{ $back['err'] = '注册模板失败，检查网络和服务器'; }
	}
	points::jan($back);