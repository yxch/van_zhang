<?php
	require_once $_SERVER['DOCUMENT_ROOT'].'/points/loader.inc.php';
	
	$back = 0;
	//使用系统内置的初始化用户初始化一些条目并注册初始化用户为超级用户
	$user = new users(array('username'=>$_SESSION['points']['user']['username'],'type'=>9));
	if($user->iTotal() > 0){ echo $back; exit; }

	$pointers = parse_ini_file(SLIB . 'etc/pointer.ini',true);
	$region = new regions(array('name'=>$pointers['name'],'directory'=>$pointers['directory']));
	if($region->iTotal() > 0){ echo $back; exit; }

    $usersInfo = array('username'=>$_SESSION['points']['user']['username'],
		               'alias'=>$pointers['alias'],
		               'password'=>$pointers['password'],
		               'email'=>$pointers['email'],
		               'type'=>$pointers['type']		);
    $user = new users();
	if(!$user->set($usersInfo)){ $back += 1; }

	//创建一个区域范围
	$lastInsertedRangeId = '';
	$regionInfo = array('name'=>$pointers['name'],
						'region'=>2,
						'authority'=>$pointers['regionAuth'],
						'directory'=>$pointers['directory']	);
	$region = new regions();
	if($region->set($regionInfo))
	{
		$lastInsertedRangeId = $region->lastInsertedId();
	}else{ $back += 1; }

	//先删除存在的系统类别条目
	$systemCategories = points::sysurl('url');
	$md5SystemCategories = points::sysurl('md5');
	$deleteWhere = 'MD5 IN("' . implode('","',$md5SystemCategories) . '")' ;
	
	$category = new category($deleteWhere);
	if(!$category->delete()){ echo $back; exit; }
	
	//初始化类别
	$categories = array(array('MD5'=>$md5SystemCategories[0],                                          
							'title'=>'类别管理器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[0],
							'accessedURL'=>'/points/usr/master/category/category.php',
							'position'=>2),
		               array('MD5'=>$md5SystemCategories[1],                                          
							'title'=>'区域管理器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[1],
							'accessedURL'=>'/points/usr/master/regions/regions.php',
							'position'=>2),
		               array('MD5'=>$md5SystemCategories[2],                                          
							'title'=>'用户管理器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[2],
							'accessedURL'=>'/points/usr/master/users/users.php',
							'position'=>2),
		               array('MD5'=>$md5SystemCategories[3],                                          
							'title'=>'权限管理器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[3],
							'accessedURL'=>'/points/usr/master/users/power.php',
							'position'=>2),
		               array('MD5'=>$md5SystemCategories[4],                                          
							'title'=>'数据过滤器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[4],
							'accessedURL'=>'/points/usr/master/filters/filters.php',
							'position'=>2),
		               array('MD5'=>$md5SystemCategories[5],                                          
							'title'=>'变量管理器',
							'regionId'=>$lastInsertedRangeId,
							'managingURL'=>$systemCategories[5],
							'accessedURL'=>'/points/usr/master/variable/variable.php',
							'position'=>2)
	);
	$category = new category();
	if( !$category->set($categories)){ $back += 1; }
	echo $back > 0 ? 0 : 1; //返回结果