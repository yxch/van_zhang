<?php
class DBC
{
	private static $_instance = null;
	private static $_handle  = null;
	private static $prefix = '';
	private static $_dbKey1 = ''; //仅适用于招商信诺的数据库配置
	private static $_dbKey2 = ''; //仅适用于招商信诺的数据库配置

	private function __construct()
	{
		//包含drupal的settings.php 载入数据库配置
		require_once $_SERVER['DOCUMENT_ROOT'] . '/sites/default/settings.php';

		//重置在settings.php文件中设置的ini变量 如果将session写入数据表就没有必须重置这些参数的值了
		/*ini_set('session.gc_divisor',1000);	     ini_set('session.gc_maxlifetime',1440);	     ini_set('session.cookie_lifetime',0); */    

		//MySQL连接参数 这几个参数根据数据的具体设置更改
		$db = $databases[self::$_dbKey1][self::$_dbKey2];
		$host = $db['host'];
		$database = $db['database'];  
		$username = $db['username'];
		$password = $db['password'];  
		$driver =   $db['driver'];      
		self::$prefix = $db['prefix'];      
		$dsn = $driver . ':host=' . $host . ';dbname=' . $database . ';charset=utf8';
		try //尝试连接MySQL
		{
		  self::$_handle = new PDO($dsn,$username,$password); 
		}catch(Exception $e){ exit(self::error($e->getMessage())); }  
	}
	/*
	 *数据库连接的单一实例
	 *@param string $key1 仅适用于招商信诺的数据库配置
	 *@param string $key2 仅适用于招商信诺的数据库配置
	 */
	public static function PDO($key1='',$key2='') 
	{
		if(!empty($key1) && !empty($key2))
		{
		  self::$_dbKey1 = $key1; self::$_dbKey2 = $key2;
		}else{ self::$_dbKey1 = 'activity'; self::$_dbKey2 = 'default'; }
		if(!(self::$_instance instanceof self)){ self::$_instance = new self;}
		return self::$_handle;
	}
	//返回设定的表前缀
	public static function prefix()
	{
		if(!(self::$_instance instanceof self)){ self::$_instance = new self;}
		return self::$_prefix;
	}
	/**
	 * 执行一条查询语句 
	 * @param string $SQL  请在SQL中使用参数替代方式来尽量避免SQL注入行为
	 * @param array $arr 可以是关联数组，如array(':name'=>'ben').  也可是 索引数组，但请注意参数的顺序 
	 * @param array $opt 可选项 只能是关联数组 
	 * cursor键对指定指针移动方向	
	 * fetch键对指定返回结果的方式如关联数组 对象等  
	 * dbname键对指定使用的数据库通常使用默认值,除非是连接另外的数据库
	 * one键对指定仅获取结果集中一个
	 * @return 布尔值或者指定的返回类型如关联数组 对象等
	 */
	public static function selected($SQL,array $arr,array $opt=[])
	{
		$cursor = isset($opt['cursor']) ? $opt['cursor'] : [PDO::ATTR_CURSOR=>PDO::CURSOR_FWDONLY];
		$fetch = isset($opt['fetch']) ? $opt['fetch'] : PDO::FETCH_ASSOC;
		$stmt = self::PDO(isset($opt['dbname']) ? $opt['dbname'] : '')->prepare($SQL,$cursor);
		foreach($arr AS $k=>$v)
		{
			if(is_int($v)){  $stmt->bindParam($k , $arr[$k],PDO::PARAM_INT);
			}else{			 $stmt->bindParam($k , $arr[$k],PDO::PARAM_STR);	}
		}
		$dbc = $stmt->execute();
		if($dbc !== FALSE)
		{
			if(isset($opt['one'])){ return $stmt->fetch($fetch); }
			return $stmt->fetchAll($fetch);
		}else
		{ 
			//在测试环境输入错误消息
			if(defined('TEST') && TEST){	exit( self::error(implode(' ',$stmt->errorInfo())) );
			}else{ return FALSE; } //在生产环境返回假值
		}
	}
	/**
	 * 执行一条IN 查询语句 本类对IN查询支持较弱且结构固定，如果是复杂的IN查询请改用相关查询
	 * @param string $SQL  请在SQL中使用参数替代方式来尽量避免SQL注入行为
	 * 注意：SELECT ... IN( :limit ) .... 这是$SQL的结构，不属于此结构的SQL将可能无法执行
	 * @param array $arr 必须是 索引数组
	 * @param array $opt 可选项 只能是关联数组
	 * dbname键对指定使用的数据库通常使用默认值,除非是连接另外的数据库
	 * cursor键对指定指针移动方向
	 * fetch键对指定返回结果的方式如关联数组 对象等
	 * one键对指定仅获取结果集中一个
	 * @return 布尔值或者指定的返回类型如关联数组 对象等
	 */
	public static function limited($SQL,array $arr,array $opt=[])
	{
		$cursor = isset($opt['cursor']) ? $opt['cursor'] : [PDO::ATTR_CURSOR=>PDO::CURSOR_FWDONLY];
		$fetch = isset($opt['fetch']) ? $opt['fetch'] : PDO::FETCH_ASSOC;
		$arrLen = count($arr);
		$limited = []; 
		for($i=0;$i<$arrLen;$i++){	$limited[':limited_' . $i] = $arr[$i];	}
		$strSQL = strtr($SQL,array(':limit'=>implode(',',array_keys($limited))));
		$stmt = self::PDO(isset($opt['dbname']) ? $opt['dbname'] : '')->prepare($strSQL,$cursor);
		foreach($limited as $x=>$y){ $stmt->bindValue($x,$y); } //参数和值绑定
		$dbc = $stmt->execute();
		if($dbc !== FAlse)
		{
			if(isset($opt['one'])){ return $stmt->fetch($fetch); }
			return $stmt->fetchAll($fetch);
		}else
		{
			//在测试环境输入错误消息
			if(defined('TEST') && TEST){	exit( self::error(implode(' ',$stmt->errorInfo())) );
			}else{ return FALSE;} //在生产环境返回假值
		}
	}
	/**
	 * 多次执行一条影响行数的SQL语句
	 * @param string $SQL  请在SQL中使用参数替代方式来尽量避免SQL注入行为
	 * @param array $arr  如果是索引数组则必须是一个二维数组且每一个单元必须是关联数组，否则是一个一维的关联数组
	 * @param array $opt 可选项 只能是关联数组 
	 * dbname键对指定使用的数据库通常使用默认值,除非是连接另外的数据库
	 * LID键对指定是否获取最后插入的自动增长的序列值  INSERT操作有效
	 * @return 布尔值或者整型数据
	 */
	public static function modified($SQL,array $arr,array $opt=[])
	{
		$DBLink = self::PDO(isset($opt['dbname']) ? $opt['dbname'] : '');
		$stmt = $DBLink -> prepare($SQL);
		//$arr的每一个单元要么全是数组要么全部不是数组，否则返回假
		$len = count($arr); $isArray = 0; $isNotArray = 0;
		for($i=0;$i<$len;$i++)
		{
			if(@is_array($arr[$i])){ $isArray += 1; }else{ $isNotArray += 1; }
		}
		if($isArray == $len ) //每一个数组单元全部是数组  关联数组
		{ 
			$result = 0;
			for($j=0;$j<$len;$j++) //循环执行数组的每个单元 
			{
				$dbc = $stmt->execute($arr[$j]);
				if($dbc !== FALSE) //如果执行成功
				{
					//是否返回最后插入的序列值 注意表的设计及仅在INSERT句法下有效 否则返回影响的行数
					if(isset($opt['LID']) && $opt['LID']){$result = $DBLink -> lastInsertId( '_id_seq' );
					}else{ $result += $stmt->rowCount(); }
				}else
				{ 
					//在测试环境输入错误消息
					if(defined('TEST') && TEST){ 	exit( self::error(implode(' ',$stmt->errorInfo())) );
					}else{ return 0; } 	//在生产环境返回假值
				}
			}
			return $result;
		}elseif($isNotArray == $len) //每一个数组单元全部不是数组 关联数组
		{
			$dbc = $stmt->execute($arr);
			if($dbc !== FALSE)
			{
				if(isset($opt['LID']) && $opt['LID']){ return $DBLink -> lastInsertId( '_id_seq' );
				}else{ return $stmt->rowCount(); }
			}else
			{
				//在测试环境输入错误消息
				if(defined('TEST') && TEST){ 	exit( self::error(implode(' ',$stmt->errorInfo())) );
				}else{ return 0; } 	//在生产环境返回假值
			}
		}else{ return 0; }
	}
	//error提示
	private static function error($error)
	{
		return '<div style="width:80%;height:auto;border:2px solid red;text-align:center;margin:10% auto;">
			  <p><img src="' . IMAGE . 'error-1.png" style="vertical-align:middle;"  />
			  <label style="vertical-align:middle;font-size:22px;color:red;margin-left:2%;font-weight:bold;">ERROR</label>
			  </p><p>' . $error . '</p></div>';
	}
}
