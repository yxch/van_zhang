<?php
class SEN extends DBO
{
	protected $sessionId;
	protected $modifiedTime;
	protected $clientIp;
	protected $text;
	protected $content;
	protected $status;
	protected $createTime;
	
	protected function definedTableName(){ return 'tb_points_session'; }
    protected function definedPrimaryKey(){ return 'sid'; }
    protected function definedRelations()
    {
        return array('sid'=>'sessionId',
                     'mme'=>'modifiedTime',
                     'cip'=>'clientIp',
                     'txt'=>'text',
					 'ctt'=>'content',
					 'yes'=>'status',
                     'cme'=>'createTime'         );
    }
}
